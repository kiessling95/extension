--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Ubuntu 11.5-3.pgdg18.04+1)
-- Dumped by pg_dump version 12.0 (Ubuntu 12.0-2.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public_auditoria; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public_auditoria;


ALTER SCHEMA public_auditoria OWNER TO postgres;

--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: crosstab6; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.crosstab6 AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text,
	category_4 text,
	category_5 text,
	category_6 text
);


ALTER TYPE public.crosstab6 OWNER TO postgres;

--
-- Name: my_crosstab_float8_5_cols; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.my_crosstab_float8_5_cols AS (
	my_row_name text,
	my_category_1 double precision,
	my_category_2 double precision,
	my_category_3 double precision,
	my_category_4 double precision,
	my_category_5 double precision
);


ALTER TYPE public.my_crosstab_float8_5_cols OWNER TO postgres;

--
-- Name: tablefunc_crosstab_2; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_2 AS (
	row_name text,
	category_1 text,
	category_2 text
);


ALTER TYPE public.tablefunc_crosstab_2 OWNER TO postgres;

--
-- Name: tablefunc_crosstab_3; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_3 AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text
);


ALTER TYPE public.tablefunc_crosstab_3 OWNER TO postgres;

--
-- Name: tablefunc_crosstab_4; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_4 AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text,
	category_4 text
);


ALTER TYPE public.tablefunc_crosstab_4 OWNER TO postgres;

--
-- Name: tablefunc_crosstab_6; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_6 AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text,
	category_4 text,
	category_5 text,
	category_6 text
);


ALTER TYPE public.tablefunc_crosstab_6 OWNER TO postgres;

--
-- Name: tablefunc_crosstab_n; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_n AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text,
	category_4 text,
	category_5 text,
	category_6 text
);


ALTER TYPE public.tablefunc_crosstab_n OWNER TO postgres;

--
-- Name: anexo1(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.anexo1(integer, character) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      	character(4);
  annio		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  reg2 		record;
  detalle	text;
  segundo	integer;
  tercero	integer;
  

BEGIN
annio:=$1;
uni:=$2;


--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

CREATE LOCAL TEMP TABLE auxiliar
(
  agente		character(40),
  legajo		integer,
  id_designacion      	integer,
  id_departamento	integer,
  id_area		integer,
  id_orientacion	integer,
  cat_mapu		character(4),
  cat_estat		character(8),
  carac			character(1),
  desde			date,
  hasta			date,
  estado		character(1),
  investig		text,
  extens		text,
  gestion		text,
  postgrado		text,
  tutorias		text,
  otros			text
  
  );
CREATE LOCAL TEMP TABLE vincu(
  dato		integer
);

--primero recupero todas las designaciones que no se han dado de baja, correspondientes a la ua y anio que ingresa como argumento
insert into auxiliar

                        select distinct c.agente,c.legajo,c.id_designacion,c.id_departamento,c.id_area,c.id_orientacion,c.cat_mapuche,c.cat_estat,c.carac,c.desde,c.hasta, case when id_novedad is not null then 'L' else estado end,null,null,c.cargo_gestion,null,null,null from     
                       (select distinct t_pe.anio,t_pe.fecha_inicio,t_pe.fecha_fin,t_d.id_designacion,trim(t_d.cat_estat)||t_d.dedic as cat_estat,t_d.cargo_gestion,t_d.uni_acad,t_d.id_departamento,t_d.id_area,t_d.id_orientacion,t_do.apellido||', '||t_do.nombre as agente,t_do.legajo,t_d.carac,t_d.cat_mapuche,t_d.dedic,t_d.desde,t_d.hasta,t_d.estado   
                            from designacion t_d , docente t_do, mocovi_periodo_presupuestario t_pe
                            where t_d.id_docente=t_do.id_docente
                            and (t_d.desde <=t_pe.fecha_fin and (t_d.hasta>=t_pe.fecha_inicio or t_d.hasta is null))
                            and t_pe.anio=annio
                            and uni_acad=uni
                            and (hasta is null or (desde<hasta))
                            and not exists (select * from novedad t_n
                                            where t_d.id_designacion=t_n.id_designacion
                                            and t_n.tipo_nov in (1,4)))c
             	      LEFT OUTER JOIN novedad t_n ON (c.id_designacion=t_n.id_designacion and t_n.tipo_nov in (2,3,5)
                                             and t_n.desde <=c.fecha_fin and (t_n.hasta>=c.fecha_inicio or t_n.hasta is null))            ;
  
  	--para cada designacion veo si tiene proyectos de investigacion vigentes en el anio que ingresa
  	--toma el ultimo movimiento
  	--no importa de que facultad es el proyecto
  	FOR reg IN
 		select * from auxiliar
	LOOP
	  --nuevo busco los 3 vinculos para atras de la designacion
         	  
	     insert into vincu (dato) values(reg.id_designacion);--inserta el primero
	     select vinc into segundo from vinculo where desig=reg.id_designacion;--
	     if segundo is not null then
 		insert into vincu(dato) values(segundo); 
 		select vinc into tercero from vinculo where desig=segundo;
 		if tercero is not null then
 			insert into vincu(dato) values(tercero); 
 		end if;
             end if;
         
	  --
	     detalle:='';
	     FOR reg2 IN --por si participara de mas de un proyecto de investigacion
	        select  case when c.codigo is null then 'S/C' else c.codigo end ||'-'||b.funcion_p||'-'||b.carga_horaria||'hs' as det
 		from integrante_interno_pi b,pinvestigacion c
 		where c.id_pinv=b.pinvest 
 		and b.hasta=c.fec_hasta
 		and b.desde<=udiames and b.hasta >=pdiames
 		and c.fec_desde <=udiames and (c.fec_hasta>=pdiames or c.fec_hasta is null)
 		and b.id_designacion in(select dato from vincu) --=reg.id_designacion --
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set investig=detalle where id_designacion=reg.id_designacion;
 	     -- veo si tiene proyectos de extension vigentes en el anio que ingresa
 	     --toma el ultimo movimiento
 	     --no importa de que facultad es el proyecto
 	     detalle:='';                                                                   
             FOR reg2 IN                                                                    
                select  c.nro_resol ||' ('||b.funcion_p||') '||b.carga_horaria||'hs' as det 
                 from integrante_interno_pe b,pextension c                                     
                 where c.id_pext=b.id_pext                                                     
                 and b.hasta=c.fec_hasta                                                       
                 and b.desde<=udiames and b.hasta >=pdiames                                    
                 and c.fec_desde <=udiames and (c.fec_hasta>=pdiames or c.fec_hasta is null)   
                 and b.id_designacion in(select dato from vincu) --=reg.id_designacion                                       
             LOOP                                                                           
                 detalle:=detalle||reg2.det;                                                   
                 detalle:=detalle||chr(13);                                                    
             END  LOOP;                                                                     
             update auxiliar set extens=detalle where id_designacion=reg.id_designacion;    
	    ---postgrados
	    detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and t_a.rol='POST'
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set postgrado=detalle where id_designacion=reg.id_designacion;
 	     --tutorias la carga horaria no es obligatoria Uso el concat para no anular cuando no tiene carga horaria
 	     detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and (t_a.rol='TUTO' or t_a.rol='COOR')
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set tutorias=detalle where id_designacion=reg.id_designacion;
 	     --otros
 	      detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end  as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and (t_a.rol='OTRO')
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set otros=detalle where id_designacion=reg.id_designacion;
 	     delete from vincu;
            
	END LOOP;
	
return 1;
END; 
$_$;


ALTER FUNCTION public.anexo1(integer, character) OWNER TO postgres;

--
-- Name: anexo2(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.anexo2(integer, character) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      	character(4);
  annio		integer;
  i		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  reg2		record;
  detalle       text;  

BEGIN
annio:=$1;
uni:=$2;
--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

CREATE LOCAL TEMP TABLE auxiliar
(
  agente		character(40),
  id_docente		integer,
  legajo		integer,
  titulos		text,
  id_designacion      	integer,
  nro_540		integer,
  cat_mapu		character(4),
  cat_estat		character(8),
  carac			character(1),
  estado		character(1),
  id_departamento	integer,
  id_area		integer,
  id_orientacion	integer,
  mat0			text,
  mat1			text,
  mat2			text,
  mat3			text,
  mat4			text,
  mat5			text
  
  );

--primero recupero todas las designaciones que no se han dado de baja, correspondientes a la ua y anio que ingresa como argumento
insert into auxiliar

                        select distinct c.agente,c.id_docente,c.legajo,null,c.id_designacion,c.nro_540,c.cat_mapuche,c.cat_estat,c.carac,case when id_novedad is not null then 'L' else estado end,id_departamento,id_area,id_orientacion,null,null,null,null,null,null from     
                       (select distinct t_pe.anio,t_pe.fecha_inicio,t_pe.fecha_fin,t_d.id_docente,t_d.id_designacion,t_d.nro_540,t_d.cargo_gestion,t_d.uni_acad,t_d.id_departamento,t_d.id_area,t_d.id_orientacion,t_do.apellido||', '||t_do.nombre as agente,t_do.legajo,t_d.carac,t_d.cat_mapuche,trim(t_d.cat_estat)||t_d.dedic as cat_estat,t_d.desde,t_d.hasta,t_d.estado   
                            from designacion t_d , docente t_do, mocovi_periodo_presupuestario t_pe
                            where t_d.id_docente=t_do.id_docente
                            and (t_d.desde <=t_pe.fecha_fin and (t_d.hasta>=t_pe.fecha_inicio or t_d.hasta is null))
                            and t_pe.anio=annio
                            and uni_acad=uni
                            and (hasta is null or (desde<hasta))
                            and not exists (select * from novedad t_n
                                            where t_d.id_designacion=t_n.id_designacion
                                            and t_n.tipo_nov in (1,4)))c
             	      LEFT OUTER JOIN novedad t_n ON (c.id_designacion=t_n.id_designacion and t_n.tipo_nov in (2,3,5)
                                             and t_n.desde <=c.fecha_fin and (t_n.hasta>=c.fecha_inicio or t_n.hasta is null))            ;
  

  	FOR reg IN--para cada designacion
 		select * from auxiliar
	LOOP
	     i:=1;
	     
	     FOR reg2 IN --busco todas las materias que tenga en ese anio
	        select  d.cod_carrera||'-'||trim(c.desc_materia)||'-'||e.descripcion||'-'||case when b.rol='EC' then 'Res' else 'Aux' end ||'-'||case when b.modulo in (1,2,3,4,5,6) then 'mod'||b.modulo else case when b.modulo=7 then 'c1m1'else case when b.modulo=8 then 'c1m2' else case when b.modulo=9 then 'c2m1' else 'c2m2' end end end end as det
 		from asignacion_materia b,materia c,plan_estudio d,periodo e
 		where b.id_materia=c.id_materia
 		and c.id_plan=d.id_plan
 		and b.id_periodo=e.id_periodo
 		and b.id_designacion=reg.id_designacion
 		and b.anio=annio
 		order by e.descripcion,b.modulo
 		
 	     LOOP
 	       if i<=6 then --solo muestra las 6 primeras
 		CASE i
 			WHEN 1 THEN update auxiliar set mat0=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 2 THEN update auxiliar set mat1=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 3 THEN update auxiliar set mat2=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 4 THEN update auxiliar set mat3=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 5 THEN update auxiliar set mat4=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 6 THEN update auxiliar set mat5=reg2.det where id_designacion=reg.id_designacion;
 			
 		END CASE;
 		end if;
 		i:=i+1;
 	     END LOOP;
 	     
	END LOOP;
	
  	FOR reg IN--para cada designacion veo que titulos tiene
 		select * from auxiliar
	LOOP
	 detalle:='';
	   FOR reg2 IN --busco todos los titulos
	       select desc_titul 
	       from titulos_docente t_d, titulo t_t 
                 where t_d.id_docente=reg.id_docente
                 and t_d.codc_titul=t_t.codc_titul
 		
 	     LOOP
 	     detalle:=detalle||reg2.desc_titul;
 	     detalle=detalle||'/';
 	    END LOOP;
 	    update auxiliar set titulos=detalle where id_designacion=reg.id_designacion;
	END LOOP;

return 1;
END; 
$_$;


ALTER FUNCTION public.anexo2(integer, character) OWNER TO postgres;

--
-- Name: arma_link(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.arma_link(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	iddesig		integer;
  	salida		text;
  	pdia		date;
  	udia		date;

BEGIN
iddesig=$1;


salida='';

select into salida case when a.id_norma is null then '' else case when b.link is not null or b.link <>'' then '<a href='||chr(39)||b.link||chr(39)|| ' target='||chr(39)||'_blank'||chr(39)||'>'||b.nro_norma||'</a>' else cast(nro_norma as text) end end
from designacion a
LEFT OUTER JOIN norma b ON (a.id_norma=b.id_norma)
where a.id_designacion=iddesig;



return salida;
END; 
$_$;


ALTER FUNCTION public.arma_link(integer) OWNER TO postgres;

--
-- Name: busca_norma(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.busca_norma(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	idnove		integer;
  	cadena		text;
  	subcadena	text;
  	subcadena_anio	text;
  	pdia		date;
  	udia		date;
  	i		integer;
  	long		integer;
  	band 		boolean;
  	num_norma	integer;
  	tipo		character(5);
	emite		character(4);  	
	uni		character(4);
	anio		integer;
	enlace		text;
	enlace2		text;
	prueba		integer;
	

BEGIN
idnove=$1;
i=1;
enlace='';
cadena='';
subcadena='';
subcadena_anio='';
band=true;


select into cadena,tipo,emite,uni trim(norma_legal), tipo_norma,tipo_emite,b.uni_acad
from novedad a
left outer join designacion b on (a.id_designacion=b.id_designacion)
where a.id_novedad=idnove;

long=length(cadena);


--corta cuando encuentra un caracter que no es digito, extrae los primero 4 que son el numero de norma
WHILE i<=long and band LOOP--cuando encuentra un caracter que no es digito entonces corta
  if textregexeq(substring(cadena,i,1),'^[[:digit:]]+?$') then--si el caracter es un digito
    subcadena=subcadena||substring(cadena,i,1);                      
  else                              
     band=false;                    
  end if;                           
  i=i+1;       
END LOOP;	                    

--prueba=length(subcadena);
if band then 
end if;

--si la band es true es porque no encontro caracteres (solo encontro digitos)
if(length(subcadena)=4 and not band)then
        band=true;
 	num_norma=cast(subcadena as integer);                                    --esto le saca los ceros de adelante
        band=true;
 	WHILE i<=long and band LOOP --recupera el anio de la norma
 		if textregexeq(substring(cadena,i,1),'^[[:digit:]]+?$') then--si el caracter es un digito
    			subcadena_anio=subcadena_anio||substring(cadena,i,1);
  		else                              
     			band=false;                    
  		end if;                           
 		i=i+1;
 	END LOOP;
 	if (band) then
    		anio=cast(subcadena_anio as integer);                                    --esto le saca los ceros de adelante
    		select into enlace2 case when link is not null then link else '' end  from norma t_n--si el select no trae nada entonces enlace2 es nulo
    		where nro_norma=num_norma 
    		and tipo_norma =tipo
    		and emite_norma=emite 
    		and extract(year from fecha)=anio 
    		and uni_acad=uni;
        	if enlace2 is not null then
        		enlace=enlace2;
        	end if;
	
        end if;	     


end if;


return enlace;                        

END;                                
$_$;


ALTER FUNCTION public.busca_norma(integer) OWNER TO postgres;

--
-- Name: calculo_conjunto(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculo_conjunto(integer, integer, integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  
  mat		integer;
  per		integer;
  annio		integer;
  reg		record;
  conj		integer;
  salida          text;
  

BEGIN

  mat=$1;
  per=$2;
  annio=$3;
  conj=0;
  salida='';
  
    --si esa materia para ese anio y ese periodo esta en un conjunto entonces muestro todo lo que tiene
    --FOR reg IN  
	select  a.id_conjunto into conj from en_conjunto a, conjunto b, mocovi_periodo_presupuestario c
	where a.id_materia=mat
	and a.id_conjunto=b.id_conjunto
	and b.id_periodo=per
	and b.id_periodo_pres=c.id_periodo
	and c.anio=annio;
	if(conj is not null) then
		FOR reg IN select t_p.cod_carrera||'-'||t_m.desc_materia||'('||cod_siu||')' as desc 
			from en_conjunto t_e, materia t_m, plan_estudio t_p
			where t_e.id_conjunto=conj
			and t_e.id_materia=t_m.id_materia
			and t_m.id_plan=t_p.id_plan
			LOOP
			salida=salida||reg.desc;
			salida=salida||chr(13);
		END LOOP;		
	end if;


  return salida;
  
END;
$_$;


ALTER FUNCTION public.calculo_conjunto(integer, integer, integer) OWNER TO postgres;

--
-- Name: calculo_cuil(character, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculo_cuil(character, integer) RETURNS character
    LANGUAGE plpgsql
    AS $_$
DECLARE
  str           character(11);
  doc2          character(11);
  i             integer;
  len           integer;
  z             integer;
  m             integer;
  sexo          character(1);
  sum           integer;
  xy            integer;
  k             integer;
  doc 		integer;
  arreglo       integer[10];
  

BEGIN

  sexo=$1;
  doc=$2;
  arreglo=array[5,4,3,2,7,6,5,4,3,2];
  
  if sexo='M' then --masculino
     xy:=20;
  else 
     xy=27;
  end if;
     
  
  
  doc2:=doc;
  
  if length(doc::text)<8 then  --si el docum tiene menos de 8 digitos entonces lo rellena con ceros
     i := 1;
     WHILE i <= (8-length(doc::text)) LOOP
     	doc2:='0'||doc2;
     	i := i + 1;
     END LOOP;
	
  end if;  
    
  str:= cast(xy as text)||cast(doc2 as text);
 
  len := length(str);
  
  sum:=0;
  i := 1;
   
  WHILE i <= len LOOP
  	--select into m a from auxi where indic=i;
  	--sum:=sum+ (cast (substr(str, i, 1) as numeric (1,0)) * m);
  	sum:=sum+ (cast (substr(str, i, 1) as numeric (1,0)) * arreglo[i]);
  	i := i + 1;
  END LOOP;
	
  select into k mod (sum,11);
  
  if k =0 then
    z:=0;
  else
    if k<>1 then
      z:=11-k;
    else 
        if sexo='M' then 
           z:=9;
           xy:=23;
        else 
          z:=4;
          xy:=23;  
        end if;
    end if; 
  end if;  
  
  
  return xy||'-'||doc2||'-'||z;
  
END;
$_$;


ALTER FUNCTION public.calculo_cuil(character, integer) OWNER TO postgres;

--
-- Name: control_actividad(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.control_actividad(integer, integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
DECLARE
  annio		integer;
  pdiames	date;      
  udiames	date;
  id_desig	integer;
  tipo		integer;
  band		boolean;
  baja		integer;
  mate		integer;
  otro		integer;
  inv		integer;
  ext		integer;
  segundo	integer;
  tercero	integer;
  id_doc	integer;
  dire		integer;

BEGIN
band:=true;
id_desig:=$1;
annio:=$2;
mate:=0;
otro:=0;
dire:=0;

CREATE LOCAL TEMP TABLE vincu(
  dato		integer
);

--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

select into tipo,baja,id_doc d.tipo_desig,case when id_novedad is null then 0 else 1 end as b,d.id_docente 
 from designacion d
 left outer join novedad n on (d.id_designacion=n.id_designacion and n.tipo_nov in (1,4) and n.desde<=udiames and n.desde>=pdiames) 
 where d.id_designacion=id_desig; 
if tipo=1 then--es una designacion 
   if baja=0 then --no tiene baja
   	select into mate case when a.id_materia is not null then 1 else 0 end as mat from asignacion_materia a where a.id_designacion=id_desig and anio=annio ;
   	if mate=0 or mate is null then --sino tiene materia se fija si tiene otras actividades. Se hace null cuando no encuentra ningun registro en el select anterior
   	
   		select into otro case when a.id_tutoria is not null then 1 else 0 end as ot from asignacion_tutoria a where a.id_designacion=id_desig and anio=annio ;
   		if otro=0 or otro is null then--sino tiene otras actividades se fija si es director departamento
   		     select into dire iddepto from director_dpto a where a.id_docente=id_doc and desde<=udiames and hasta>=pdiames ;
   		     if dire=0 or dire is null then--sino es director de departamento dentro del periodo
   		     
   			--busco los vinculos de la designacion 
   		     	insert into vincu (dato) values(id_desig);--inserta el primero
	     	     	select vinc into segundo from vinculo where desig=id_desig;--
	     	     	if segundo is not null then
 		     		insert into vincu(dato) values(segundo); 
 		     		select vinc into tercero from vinculo where desig=segundo;
 		     		if tercero is not null then 
 		   			insert into vincu(dato) values(tercero); 
 		     		end if;
             	     	end if;
   		     	select into inv c.id_pinv
 				from integrante_interno_pi b,pinvestigacion c
 				where c.id_pinv=b.pinvest 
 				--and b.hasta=c.fec_hasta --si esta hasta el fin del proyecto lo coloco y sino no
 				and b.desde<=udiames and b.hasta >=pdiames --la participacion en el proyecto entra en el periodo
 				and b.id_designacion in(select dato from vincu) ;
   		    	if inv=0 or inv is null then--sino tiene investigacion me fijo en extension
   		        	select into ext c.id_pext
 				from integrante_interno_pe b,pextension c
 				where c.id_pext=b.id_pext 
 				--and b.hasta=c.fec_hasta --si esta hasta el fin del proyecto lo coloco y sino no
 				and b.desde<=udiames and b.hasta >=pdiames --la participacion en el proyecto entra en el periodo
 				and b.id_designacion in(select dato from vincu) ;
 				if ext=0 or ext is null then
 			  		band=false;
 				end if;
   		    	
   		    	end if;
   		   end if;--director    
   		end if;--otras
   	end if;--materias
   	
   end if;--tiene baja
end if;--tipo<>1

return band;
END; 
$_$;


ALTER FUNCTION public.control_actividad(integer, integer) OWNER TO postgres;

--
-- Name: costo_reserva(integer, numeric, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.costo_reserva(integer, numeric, integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	costo		numeric;
  	costoreserva	numeric;
  	salida		numeric;
  	idreserva	integer;
  	annio		integer;
  	pdia		date;
  	udia		date;
  	
BEGIN
idreserva=$1;
costoreserva=$2;
annio=$3;
salida=0;

--primer dia del periodo correspondiente al año que ingresa
pdia:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udia:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

--hay que enviarle el año para que calcule el costo en ese año

select into costo sum(case when (dias_des-dias_lic)>=0 then (dias_des-dias_lic)*costo_diario*porc/100 else 0 end )  from 
(SELECT distinct t_d.id_designacion,porc, costo_diario,
                         sum(case when t_no.id_novedad is null then 0 else (case when (t_no.desde>udia or (t_no.hasta is not null and t_no.hasta<pdia)) then 0 else (case when t_no.desde<=pdia then ( case when (t_no.hasta is null or t_no.hasta>=udia ) then (((cast(udia as date)-cast(udia as date))+1)) else ((t_no.hasta-pdia)+1) end ) else (case when (t_no.hasta is null or t_no.hasta>=udia ) then (((udia)-t_no.desde+1)) else ((t_no.hasta-t_no.desde+1)) end ) end )end)*t_no.porcen end) as dias_lic,
                        case when t_d.desde<=pdia then ( case when (t_d.hasta>=udia or t_d.hasta is null ) then (((cast(udia as date)-cast(pdia as date))+1)) else ((t_d.hasta-pdia)+1) end ) else (case when (t_d.hasta>=udia or t_d.hasta is null) then (((udia)-t_d.desde+1)) else ((t_d.hasta-t_d.desde+1)) end ) end as dias_des 
                            FROM designacion as t_d 
                            LEFT OUTER JOIN novedad t_no ON (t_d.id_designacion=t_no.id_designacion and t_no.tipo_nov in (2,5) and t_no.tipo_norma is not null 
                           					and t_no.tipo_emite is not null 
                           					and t_no.norma_legal is not null 
                           					and t_no.desde<=udia and t_no.hasta>=pdia)
                            LEFT OUTER JOIN mocovi_periodo_presupuestario m_e ON (m_e.anio=annio)
 			    LEFT OUTER JOIN mocovi_costo_categoria as m_c ON (t_d.cat_mapuche = m_c.codigo_siu and m_c.id_periodo=m_e.id_periodo) 
 			    LEFT OUTER JOIN imputacion as t_t ON (t_d.id_designacion = t_t.id_designacion) 
 			    LEFT OUTER JOIN mocovi_programa as m_p ON (t_t.id_programa = m_p.id_programa)                        					
                            
                        WHERE  t_d.tipo_desig=1
                        and t_d.id_designacion in (select id_designacion from reserva_ocupada_por 
                                                   where id_reserva=idreserva) 
                                                  
                        GROUP BY t_d.id_designacion,t_d.desde,t_d.hasta,costo_diario,porc) sub;
 if costo is null then--la reserva no tiene designaciones asociadas 
    salida=costoreserva;
 else
   if costoreserva>=costo then
    	salida=costoreserva-costo;   
   else
   	salida=0;
   end if; 
 end if;

return salida;
END; 
$_$;


ALTER FUNCTION public.costo_reserva(integer, numeric, integer) OWNER TO postgres;

--
-- Name: dedicacion_horas(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dedicacion_horas(integer, character) RETURNS date
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      character(4);
  annio		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  segundo	integer;
  tercero	integer;
  canti		integer;
  semanas_desig integer;

BEGIN
annio:=$1;
uni:=$2;


--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);



CREATE LOCAL TEMP TABLE auxiliar
(
  id_docente		integer,
  agente		character(40),
  legajo		integer,
  id_designacion      	integer,
  desde			date,
  hasta			date,
  dias_trab		integer,--dias trabajados
  hs_mat 		integer,
  hs_desig		integer,--cantidad de hs correspondiente a la dedicacion
  hs_pe			integer,
  hs_pi			integer,
  hs_post		integer,
  hs_tut		integer,
  hs_otros		integer
  
  );
  
CREATE LOCAL TEMP TABLE vincu(
  dato		integer
);
insert into auxiliar

                        --select a.agente,a.legajo,a.id_designacion,desde,hasta,sum(t_a.carga_horaria*case when (t_a.id_periodo=1 or t_a.id_periodo=2) then 16 else case when (t_a.id_periodo=3 or t_a.id_periodo=4) then 32 else case when (t_a.id_periodo=5) then 8 else case when (t_a.id_periodo=6) then 4 else case when (t_a.id_periodo=8 or t_a.id_periodo=9) then 24 end end end end end )/case when (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365)=0 then 1 else (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365) end as hs_mat, case when dedic=1 then 40 else case when dedic=2 then 20 else case when dedic=3 then 10 else 0 end end end  as hs_desig
                        select a.id_docente,a.agente,a.legajo,a.id_designacion,desde,hasta,case when (dias_des-dias_lic)<0 then 0 else dias_des-dias_lic end as dias_trab,sum(t_a.carga_horaria*case when (t_a.id_periodo=1 or t_a.id_periodo=2) then 16 else case when (t_a.id_periodo=3 or t_a.id_periodo=4) then 32 else case when (t_a.id_periodo=10 or t_a.id_periodo=11 or t_a.id_periodo=12 or t_a.id_periodo=13) then 5 else case when (t_a.id_periodo=6) then 2 else case when (t_a.id_periodo=8 or t_a.id_periodo=9) then 16 end end end end end )/case when (((case when hasta is null then fecha_fin else case when hasta>fecha_fin then fecha_fin else hasta end end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365)=0 then 1 else (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365) end as hs_mat
                        , (case when dedic=1 then 40 else case when dedic=2 then 20 else case when dedic=3 then 10 else 0 end end end)*(dias_des-dias_lic)/365  as hs_desig
                        from
                        (   select b.*,(case when b.hasta is null then fecha_fin else case when b.hasta>fecha_fin then fecha_fin else b.hasta end end) -(case when b.desde<fecha_inicio then fecha_inicio else b.desde end )+1 as dias_des 
                            ,case when sum((n.hasta-n.desde)+1) is null then 0 else sum((n.hasta-n.desde)+1) end as dias_lic
                            from (
                            select t_pe.anio,t_pe.fecha_inicio,t_pe.fecha_fin,t_d.id_designacion,t_d.uni_acad,t_d.id_departamento,t_d.id_area,t_d.id_orientacion,t_do.id_docente,t_do.apellido||', '||t_do.nombre as agente,t_do.legajo,t_d.carac,t_d.cat_mapuche,t_d.dedic,t_d.desde,t_d.hasta  
                            from designacion t_d , docente t_do, mocovi_periodo_presupuestario t_pe
                            where t_d.id_docente=t_do.id_docente
                            and (t_d.desde <=t_pe.fecha_fin and (t_d.hasta>=t_pe.fecha_inicio or t_d.hasta is null))
                            and t_d.tipo_desig=1
                            and not(t_d.hasta is not null and t_d.desde>t_d.hasta)--descarto si la anularon
                            )b 
                            LEFT OUTER JOIN novedad n ON (b.id_designacion=n.id_designacion and n.tipo_nov in(2,3,5) and n.desde <=udiames and n.hasta>=pdiames)
                            where b.uni_acad=uni and b.anio=annio
                          group by anio,fecha_inicio,fecha_fin,b.id_designacion,uni_acad,id_departamento,id_area,id_orientacion,id_docente,agente,legajo,carac,cat_mapuche,dedic,b.desde,b.hasta
                        )a 
                        LEFT OUTER JOIN asignacion_materia t_a ON (a.id_designacion=t_a.id_designacion and t_a.anio=a.anio)
                        group by a.id_docente,a.agente,a.legajo,a.id_designacion,hasta,desde,fecha_fin,fecha_inicio,dedic,dias_des,dias_lic;
                         
--proyectos de investigacion                        
FOR reg IN
    select * from auxiliar --para cada designacion calculo la cantidad de horas en investigacion dentro de ese periodo
    LOOP
   insert into vincu (dato) values(reg.id_designacion);--inserta el primero
   select vinc into segundo from vinculo where desig=reg.id_designacion;--
   if segundo is not null then
	insert into vincu(dato) values(segundo); 
	select vinc into tercero from vinculo where desig=segundo;
	if tercero is not null then
		insert into vincu(dato) values(tercero); 
	end if;
   end if;

--saca un promedio cuando tiene periodos entrecortados con cantidad de horas distintas 
 --calcula las semanas correspondientes a los dias trabajados
 --semanas_desig=reg.dias_trab*32/365;
 --if semanas_desig=0 then
   --  semanas_desig=1;
 --end if; 
 --cantidad de dias de la designacion pasado a semanas (no considero aqui los dias de licencia porque en investigacion no importaria)
 if reg.desde<pdiames then
    if reg.hasta is null or reg.hasta>udiames then 
       semanas_desig=(udiames-pdiames)*32/365;                                 
    else
       semanas_desig=(reg.hasta-pdiames)*32/365;
    end if;
 else    
    if reg.hasta is null or reg.hasta>udiames then 
       semanas_desig=(udiames-reg.desde)*32/365;
    else
       semanas_desig=(reg.hasta-reg.desde)*32/365;
    end if;
 end if;
 
 select sum((((case when b.hasta is null then udiames else case when b.hasta>udiames then udiames else hasta end end )-(case when b.desde<pdiames then pdiames else b.desde end))*32/365)*carga_horaria)/semanas_desig into canti 
 from  integrante_interno_pi b 
 where b.id_designacion in(select dato from vincu) 
 and b.desde<=udiames and b.hasta >=pdiames
  ;
 
 update auxiliar set hs_pi=canti where id_designacion=reg.id_designacion;	
 delete from vincu;
END LOOP;

----proyectos de extension
FOR reg IN
 select a.id_designacion,(sum((b.hasta-b.desde)/7*carga_horaria))/sum((b.hasta-b.desde)/7) as cant 
 from auxiliar a, integrante_interno_pe b 
 where a.id_designacion=b.id_designacion 
 and b.desde<=udiames and b.hasta >=pdiames 
 group by a.id_designacion
LOOP
update auxiliar set hs_pe=reg.cant where id_designacion=reg.id_designacion;	
END LOOP;
--postgrados
FOR reg IN
  select a.id_designacion,sum(t_a.carga_horaria*case when (t_a.periodo=1 or t_a.periodo=2) then 16 else case when (t_a.periodo=3 or t_a.periodo=4) then 32 else case when (t_a.periodo=5) then 8 else case when (t_a.periodo=6) then 4 else case when (t_a.periodo=8 or t_a.periodo=9) then 24 end end end end end )
/case when (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365)=0 then 1 else (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365) end as cant
 from auxiliar a, asignacion_tutoria t_a, mocovi_periodo_presupuestario t_pe where 
  a.id_designacion=t_a.id_designacion and t_a.anio=annio and t_a.rol='POST' and (a.desde <=t_pe.fecha_fin and (a.hasta>=t_pe.fecha_inicio or a.hasta is null))
  and t_pe.anio=annio
group by a.id_designacion ,hasta,desde,fecha_fin,fecha_inicio
LOOP
update auxiliar set hs_post=reg.cant where id_designacion=reg.id_designacion;	
END LOOP;
         
----tutorias
FOR reg IN
  select a.id_designacion,sum(t_a.carga_horaria*case when (t_a.periodo=1 or t_a.periodo=2) then 16 else case when (t_a.periodo=3 or t_a.periodo=4) then 32 else case when (t_a.periodo=10 or t_a.periodo=11 or t_a.periodo=12 or t_a.periodo=13) then 5 else case when (t_a.periodo=6) then 2 else case when (t_a.periodo=8 or t_a.periodo=9) then 16 end end end end end )
/case when (a.dias_trab*32/365)=0 then 1 else a.dias_trab*32/365 end  as cant
 from auxiliar a, asignacion_tutoria t_a
 where 
  a.id_designacion=t_a.id_designacion and t_a.anio=annio and (t_a.rol='COOR' or t_a.rol='TUTO')
  
group by a.id_designacion, a.dias_trab
LOOP
update auxiliar set hs_tut=reg.cant where id_designacion=reg.id_designacion;	
END LOOP;
         
----otros
FOR reg IN
   
  select a.id_designacion,
    sum(t_a.carga_horaria*case when (t_a.periodo=1 or t_a.periodo=2) then 16 else case when (t_a.periodo=3 or t_a.periodo=4) then 32 else case when (t_a.periodo=10 or t_a.periodo=11 or t_a.periodo=12 or t_a.periodo=13) then 5 else case when (t_a.periodo=6) then 2 else case when (t_a.periodo=8 or t_a.periodo=9) then 16 end end end end end  )
     /case when (a.dias_trab*32/365)=0 then 1 else a.dias_trab*32/365 end as cant
   from auxiliar a, asignacion_tutoria t_a 
   where  a.id_designacion=t_a.id_designacion and t_a.anio=annio and t_a.rol='OTRO' 
  group by a.id_designacion, a.dias_trab
LOOP
update auxiliar set hs_otros=reg.cant where id_designacion=reg.id_designacion;	
END LOOP;                        
return udiames;
END; 
$_$;


ALTER FUNCTION public.dedicacion_horas(integer, character) OWNER TO postgres;

--
-- Name: estado_desig(integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.estado_desig(integer, date, date) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	iddesig		integer;
  	salida		text;
  	pdia		date;
  	udia		date;

BEGIN
iddesig=$1;
pdia=$2;
udia=$3;

salida='';

select into salida case when b.id_novedad is not null then 'B' else case when c.id_novedad is not null then 'L' else a.estado end end 
from designacion a
LEFT OUTER JOIN novedad b ON (a.id_designacion=b.id_designacion and b.tipo_nov in (1,4))
LEFT OUTER JOIN novedad c ON (a.id_designacion=c.id_designacion and c.tipo_nov in (2,5) and c.desde <= udia and (c.hasta >= pdia or c.hasta is null))
where a.id_designacion=iddesig;



return salida;
END; 
$_$;


ALTER FUNCTION public.estado_desig(integer, date, date) OWNER TO postgres;

--
-- Name: excepcion_area(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.excepcion_area(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  id_desig	integer;
  reg		record;
  primera	boolean;
  areaa		text;
  textoa	text;
 

BEGIN
id_desig=$1;
textoa='';
primera=true;


FOR reg IN select distinct * from
	(select de.descripcion as dpto,ar.descripcion as are,ori.descripcion as orient from designacion d
           left outer join departamento de on (d.id_departamento=de.iddepto)
           left outer join area ar on (d.id_area=ar.idarea  ) 
           left outer join orientacion ori on ( ori.idorient=d.id_orientacion and ori.idarea=ar.idarea) 
           where d.id_designacion=id_desig   
            UNION
           select d.descripcion as dpto,ar.descripcion as are,ori.descripcion as orient from dao_designa a 
	   left outer join departamento d on (a.id_departamento=d.iddepto )
	   left outer join area ar on (a.id_area=ar.idarea  ) 
	   left outer join orientacion ori on ( ori.idorient=a.id_orientacion and ori.idarea=a.id_area) 
	   where a.id_designacion=id_desig
	   )sub
	   order by dpto,are,orient
	
 	LOOP
 	if primera then 
 		areaa=reg.are;
 		textoa=reg.are;
 		primera=false;
 	end if;
 	if not primera then
 		if reg.are<>areaa then 
 		        areaa=reg.are;
 			textoa=textoa||'/'||reg.are;
 		end if;
 	end if;
END LOOP;


return textoa;
END; 
$_$;


ALTER FUNCTION public.excepcion_area(integer) OWNER TO postgres;

--
-- Name: excepcion_departamento(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.excepcion_departamento(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  id_desig	integer;
  reg		record;
  primera	boolean;
--  arr 		text[];
  
  dep		text;
  textod	text;
  
BEGIN
id_desig:=$1;
textod:='';
primera:=true;


FOR reg IN select distinct * from
	(select de.descripcion as dpto,ar.descripcion as desc_are,ori.descripcion as desc_orien from designacion d
           left outer join departamento de on (d.id_departamento=de.iddepto)
           left outer join area ar on (d.id_area=ar.idarea  ) 
           left outer join orientacion ori on ( ori.idorient=d.id_orientacion and ori.idarea=d.id_area) 
           where d.id_designacion=id_desig   
            UNION
           select d.descripcion as dpto,ar.descripcion as are,ori.descripcion as orienta from dao_designa a 
	   left outer join departamento d on (a.id_departamento=d.iddepto )
	   left outer join area ar on (a.id_area=ar.idarea ) 
	   left outer join orientacion ori on ( ori.idorient=a.id_orientacion and ori.idarea=a.id_area) 
	   where a.id_designacion=id_desig
	   )sub
	   order by dpto,desc_are,desc_orien
	LOOP
 	if primera then 
 		dep=reg.dpto;
 		textod=reg.dpto;
 		primera=false;
 	end if;
 	if not primera then
 		if reg.dpto<>dep then 
 			textod=textod||'/'||reg.dpto;
 		end if;
 	end if;
END LOOP;

--arr[0]=textod;
--arr[1]=textoa;
--arr[2]=textoo;
return textod;
END; 
$_$;


ALTER FUNCTION public.excepcion_departamento(integer) OWNER TO postgres;

--
-- Name: excepcion_orientacion(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.excepcion_orientacion(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  id_desig	integer;
  reg		record;
  primera	boolean;
  orienta	text;
  textoo	text;
 

BEGIN
id_desig=$1;
textoo='';
primera=true;


FOR reg IN select distinct * from
	(select de.descripcion as dpto,ar.descripcion as are,ori.descripcion as orient from designacion d
           left outer join departamento de on (d.id_departamento=de.iddepto)
           left outer join area ar on (ar.idarea=d.id_area ) 
           left outer join orientacion ori on ( ori.idorient=d.id_orientacion and ori.idarea=d.id_area) 
           where d.id_designacion=id_desig   
            UNION
           select d.descripcion as dpto,ar.descripcion as are,ori.descripcion as orient from dao_designa a 
	   left outer join departamento d on (a.id_departamento=d.iddepto )
	   left outer join area ar on (ar.idarea=a.id_area  ) 
	   left outer join orientacion ori on ( ori.idorient=a.id_orientacion and ori.idarea=a.id_area) 
	   where a.id_designacion=id_desig
	   )sub
	   order by dpto,are,orient
	
 	LOOP
 	if primera then 
 		orienta=reg.orient;
 		textoo=reg.orient;
 		primera=false;
 	end if;
 	if not primera then
 		if reg.orient<>orienta then 
 		        orienta=reg.orient;
 			textoo=textoo||'/'||reg.orient;
 		end if;
 	end if;
END LOOP;


return textoo;
END; 
$_$;


ALTER FUNCTION public.excepcion_orientacion(integer) OWNER TO postgres;

--
-- Name: informe_actividad(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.informe_actividad(integer, character) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      	character(4);
  annio		integer;
  i		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  reg2		record;
  detalle       text;  
  segundo	integer;
  tercero	integer;
  auxi		text;

BEGIN
annio:=$1;
uni:=$2;
--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

CREATE LOCAL TEMP TABLE auxiliar
(
  agente		character(40),
  id_docente		integer,
  legajo		integer,
  id_designacion      	integer,
  desde			date,
  hasta			date,
  nro_540		integer,
  cat_mapu		character(4),
  cat_estat		character(8),
  carac			character(1),
  id_departamento	integer,
  id_area		integer,
  id_orientacion	integer,
  estado		character(1),
  desc_estado		text,--esto para colocar el periodo de la licencia/cese
  mat0			text,
  mat1			text,
  mat2			text,
  mat3			text,
  mat4			text,
  mat5			text,
  gestion		text,
  investig		text,
  extens		text,
  postgrado		text,
  tutorias		text,
  otros			text
  
  );

CREATE LOCAL TEMP TABLE vincu(
  dato		integer
);


--primero recupero todas las designaciones correspondientes a la ua y anio que ingresa como argumento
insert into auxiliar
			select d.agente,d.id_docente,d.legajo,d.id_designacion,d.desde,d.hasta,d.nro_540,cat_mapuche,cat_estat,carac,id_departamento,id_area,id_orientacion, case when t_nov.tipo_nov in (1,4) then 'B' else case when t_nov.tipo_nov in (2,5) then 'L' else d.estado end end as estado,null,null,null,null,null,null,null,gest,null,null,null,null,null from 
                        (select distinct anio,fecha_inicio,fecha_fin,id_docente,c.id_designacion,nro_540,cargo_gestion,uni_acad,id_departamento,id_area,id_orientacion,agente,legajo,carac,cat_mapuche, cat_estat,c.desde,c.hasta,estado,gest,max(t_no.id_novedad) as id_novedad from    
                       (select distinct t_pe.anio,t_pe.fecha_inicio,t_pe.fecha_fin,t_d.id_docente,t_d.id_designacion,t_d.nro_540,t_d.cargo_gestion,t_d.uni_acad,t_d.id_departamento,t_d.id_area,t_d.id_orientacion,t_do.apellido||', '||t_do.nombre as agente,t_do.legajo,t_d.carac,t_d.cat_mapuche,trim(t_d.cat_estat)||t_d.dedic as cat_estat,t_d.desde,t_d.hasta,t_d.estado,cargo_gestion||'('||emite_cargo_gestion||case when ord_gestion is not null then ord_gestion else '' end||')' as gest
                            from designacion t_d 
                            LEFT OUTER JOIN docente t_do ON (t_d.id_docente=t_do.id_docente)
                            LEFT OUTER JOIN  mocovi_periodo_presupuestario t_pe ON (t_pe.anio=annio )
                            where  (t_d.desde <=t_pe.fecha_fin and (t_d.hasta>=t_pe.fecha_inicio or t_d.hasta is null))
                            and t_d.tipo_desig=1
                            and t_pe.anio=annio
                            and uni_acad=uni
                            and (t_d.hasta is null or (t_d.desde<t_d.hasta))--no esta anulada
                            )c
                             LEFT OUTER JOIN novedad t_no ON (c.id_designacion=t_no.id_designacion and t_no.desde<=udiames and t_no.desde>=pdiames)--solo fecha desde porque las bajas no tienen hasta
                             group by anio,fecha_inicio,fecha_fin,id_docente,c.id_designacion,nro_540,cargo_gestion,uni_acad,id_departamento,id_area,id_orientacion,agente,legajo,carac,cat_mapuche, cat_estat,c.desde,c.hasta,estado,gest
                             )d
                              LEFT OUTER JOIN novedad t_nov ON (t_nov.id_novedad=d.id_novedad)
             	        order by agente           ;
  

  	FOR reg IN--para cada designacion
 		select * from auxiliar
	LOOP
	     if reg.estado='L' then 
	        auxi=' Licencia ';
	     	FOR reg2 IN select to_char(desde, 'DD/MM/YYYY') as desde,to_char(hasta, 'DD/MM/YYYY') as hasta from novedad 
	     		    where id_designacion=reg.id_designacion
	     		    and tipo_nov in (2,3,5) and desde <=udiames and hasta>=pdiames
	     	LOOP
	          auxi:=auxi||' desde:'||reg2.desde||' hasta:'||reg2.hasta||' ' ;
	     
	     	END LOOP;
	     	update auxiliar set desc_estado=auxi where id_designacion=reg.id_designacion;
	     end if;
	     
	     i:=1;
	     
	     FOR reg2 IN --busco todas las materias que tenga en ese anio
	        --select  trim(c.desc_materia)||'-'||d.cod_carrera||'-'||case when b.rol='EC' then 'Res' else 'Aux' end ||'-'||e.descripcion||'('||case when b.carga_horaria is not null then b.carga_horaria else 0 end||'hs)'||case when b.modulo in (1,2,3,4,5,6) then 'mod'||b.modulo else case when b.modulo=7 then 'c1m1'else case when b.modulo=8 then 'c1m2' else case when b.modulo=9 then 'c2m1' else 'c2m2' end end end end as det
	        select  materias_conjunto(b.anio,b.id_periodo,uni,b.id_materia)||'-'||case when b.rol='EC' then 'Res' else 'Aux' end ||'-'||e.descripcion||'('||case when b.carga_horaria is not null then b.carga_horaria else 0 end||'hs)'||case when b.modulo in (1,2,3,4,5,6) then 'mod'||b.modulo else case when b.modulo=7 then 'c1m1'else case when b.modulo=8 then 'c1m2' else case when b.modulo=9 then 'c2m1' else 'c2m2' end end end end as det
 		from asignacion_materia b,materia c,plan_estudio d,periodo e
 		where b.id_materia=c.id_materia
 		and c.id_plan=d.id_plan
 		and b.id_periodo=e.id_periodo
 		and b.id_designacion=reg.id_designacion
 		and b.anio=annio
 		order by e.descripcion,b.modulo
 		
 	     LOOP
 	       if i<=6 then --solo muestra las 6 primeras
 		CASE i
 			WHEN 1 THEN update auxiliar set mat0=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 2 THEN update auxiliar set mat1=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 3 THEN update auxiliar set mat2=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 4 THEN update auxiliar set mat3=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 5 THEN update auxiliar set mat4=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 6 THEN update auxiliar set mat5=reg2.det where id_designacion=reg.id_designacion;
 			
 		END CASE;
 		end if;
 		i:=i+1;
 	     END LOOP;
 	     
	END LOOP;
	
  	--para cada designacion veo si tiene proyectos de investigacion vigentes en el anio que ingresa
  	--toma el ultimo movimiento
  	--no importa de que facultad es el proyecto
  	FOR reg IN
 		select * from auxiliar
	LOOP
	  --nuevo busco los 3 vinculos para atras de la designacion
         	  
	     insert into vincu (dato) values(reg.id_designacion);--inserta el primero
	     select vinc into segundo from vinculo where desig=reg.id_designacion;--
	     if segundo is not null then
 		insert into vincu(dato) values(segundo); 
 		select vinc into tercero from vinculo where desig=segundo;
 		if tercero is not null then 
 		   insert into vincu(dato) values(tercero); 
 		end if;
             end if;
         
	  --
	     detalle:='';
	     FOR reg2 IN --por si participara de mas de un proyecto de investigacion
	        select case when c.codigo is null then 'S/C' else c.codigo end||'-'||b.funcion_p||'-'||b.carga_horaria||'hs' as det
 		from integrante_interno_pi b,pinvestigacion c
 		where c.id_pinv=b.pinvest 
 		and b.hasta=c.fec_hasta --si esta hasta el fin del proyecto lo coloco y sino no
 		and b.desde<=udiames and b.hasta >=pdiames --la participacion en el proyecto entra en el periodo
 		and b.id_designacion in(select dato from vincu) 
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set investig=detalle where id_designacion=reg.id_designacion;
 	     -- veo si tiene proyectos de extension vigentes en el anio que ingresa
 	     --toma el ultimo movimiento
 	     --no importa de que facultad es el proyecto
 	     detalle:='';                                                                   
             FOR reg2 IN                                                                    
                select  c.nro_resol ||' ('||b.funcion_p||') '||b.carga_horaria||'hs' as det 
                 from integrante_interno_pe b,pextension c                                     
                 where c.id_pext=b.id_pext                                                     
                 and b.hasta=c.fec_hasta                                                       
                 and b.desde<=udiames and b.hasta >=pdiames                                    
                 and c.fec_desde <=udiames and (c.fec_hasta>=pdiames or c.fec_hasta is null)   
                 and b.id_designacion in(select dato from vincu) --=reg.id_designacion                                       
             LOOP                                                                           
                 detalle:=detalle||reg2.det;                                                   
                 detalle:=detalle||chr(13);                                                    
             END  LOOP;                                                                     
             update auxiliar set extens=detalle where id_designacion=reg.id_designacion;    
	    ---postgrados
	    detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)
                and t_a.id_tutoria=t_t.id_tutoria
                and t_a.rol='POST'
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set postgrado=detalle where id_designacion=reg.id_designacion;
 	     --tutorias la carga horaria no es obligatoria Uso el concat para no anular cuando no tiene carga horaria
 	     detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and (t_a.rol='TUTO' or t_a.rol='COOR')
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set tutorias=detalle where id_designacion=reg.id_designacion;
 	     --otros
 	     detalle:='';
	     FOR reg2 IN
	     	select 'DIRECTOR DEPARTAMENTO: '||trim(c.descripcion) as det from director_dpto a, departamento c
		where a.id_docente=reg.id_docente
		and a.iddepto=c.iddepto 
    		and a.hasta >= pdiames and a.desde <=udiames  
    		UNION
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end  as det 
	        from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and (t_a.rol='OTRO')
                and t_a.anio=annio
                
		
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set otros=detalle where id_designacion=reg.id_designacion;
 	     delete from vincu;
            
	END LOOP;

return 1;
END; 
$_$;


ALTER FUNCTION public.informe_actividad(integer, character) OWNER TO postgres;

--
-- Name: inscriptos_designa(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.inscriptos_designa(integer, character) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      character(4);
  annio		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  

BEGIN
annio:=$1;
uni:=$2;

CREATE LOCAL TEMP TABLE auxiliar
(
  id_materia		integer,
  anio		      	integer,
  id_periodo		integer,
  id_comision		integer,
  id_conjunto		integer,
  cant_inscriptos	integer,
  cant_desig		integer
  
  
  );
insert into auxiliar
select id_materia,anio_acad,id_periodo,id_comision,null,inscriptos,0 from inscriptos
where anio_acad = annio;

FOR reg IN
--a las materias que estan en algun conjunto para ese año y ese periodo
--les coloco el id_conjunto
 select a.id_materia,a.anio,a.id_periodo,t_o.id_conjunto from auxiliar a
  	   LEFT OUTER JOIN en_conjunto t_co ON (t_co.id_materia=a.id_materia)
           LEFT OUTER JOIN conjunto t_o ON (t_o.id_conjunto=t_co.id_conjunto and t_o.id_periodo=a.id_periodo)
           LEFT OUTER JOIN mocovi_periodo_presupuestario t_an ON (t_an.id_periodo=t_o.id_periodo_pres and t_an.anio=a.anio)
           where t_o.id_conjunto is not null
 
LOOP
update auxiliar b set id_conjunto=reg.id_conjunto where b.id_materia=reg.id_materia and b.anio=reg.anio and b.id_periodo=reg.id_periodo  ;	
END LOOP;

FOR reg IN
--para las materias que no estan dentro de un conjunto
--cuantas designaciones estan asociadas a esa materia, periodo y ano
 select a.id_materia,a.anio,a.id_periodo,count(distinct id_designacion)as cant 
           from auxiliar a
  	   LEFT OUTER JOIN asignacion_materia t_a ON (t_a.id_materia=a.id_materia and t_a.id_periodo=a.id_periodo and t_a.anio=a.anio)       
  	   where a.id_conjunto is null
  	   group by a.id_materia,a.anio,a.id_periodo
 
LOOP
update auxiliar b set cant_desig=reg.cant where b.id_materia=reg.id_materia and b.anio=reg.anio and b.id_periodo=reg.id_periodo  ;	
END LOOP;

FOR reg IN
--para las materias que estan dentro de un conjunto
--cuantas designaciones estan a materias que estan dentro de ese conjunto
 select a.id_conjunto,a.anio,a.id_periodo,count(distinct id_designacion)as cant 
           from auxiliar a
           LEFT OUTER JOIN en_conjunto t_e ON ( t_e.id_conjunto=a.id_conjunto)
           LEFT OUTER JOIN asignacion_materia t_a ON (t_a.id_materia=t_e.id_materia and t_a.id_periodo=a.id_periodo and a.anio=t_a.anio)
  	   
  	   where a.id_conjunto is not null
  	   group by a.id_conjunto,a.anio,a.id_periodo
 
LOOP
update auxiliar b set cant_desig=reg.cant where b.id_conjunto=reg.id_conjunto and b.anio=reg.anio and b.id_periodo=reg.id_periodo  ;	
END LOOP;
  
return 1;
END; 
$_$;


ALTER FUNCTION public.inscriptos_designa(integer, character) OWNER TO postgres;

--
-- Name: materias_conjunto(integer, integer, character, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.materias_conjunto(integer, integer, character, integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  annio		integer;
  periodo	integer;
  uacad		text;
  mat		integer;
  conj		integer;
  detalle	text;
  nombre	text;
  reg		record;
  band		boolean;
  primera	text;
  mater	text;
  carrera	text;

BEGIN
annio:=$1;
periodo:=$2;
uacad:=$3;
mat:=$4;
detalle:='';
band:=true;
 select into nombre trim(m.desc_materia)||'('||p.cod_carrera||')' from materia m, plan_estudio p where m.id_plan=p.id_plan and m.id_materia=mat;
--si la materia esta dentro de un conjunto para ese periodo, anio y ua entonces recorro el conjunto
 select into conj c.id_conjunto from conjunto c, en_conjunto e,mocovi_periodo_presupuestario p
 where c.id_conjunto=e.id_conjunto
	and p.anio=annio
	and p.id_periodo=c.id_periodo_pres
	and c.ua=trim(uacad)
	and c.id_periodo=periodo
	and e.id_materia=mat;
 if conj is not null then--si encuentra el conjunto
 	FOR reg IN select trim(regexp_replace(regexp_replace( regexp_replace(regexp_replace(regexp_replace(m.desc_materia, 'Á', 'A','g'),'É', 'E','g'),'Í', 'I','g'),'Ó', 'O','g'),'Ú', 'U','g')) as desc_materia,trim(p.cod_carrera) as cod_carrera 
 	           from en_conjunto e, materia m, plan_estudio p 
 	           where e.id_conjunto=conj 
 	           and e.id_materia=m.id_materia 
 	           and m.id_plan=p.id_plan 
 	           order by m.desc_materia
 	LOOP
 	  if band then--solo la primera vez recupera el 1er nombre
 	  	mater:=trim(regexp_replace(regexp_replace( regexp_replace(regexp_replace(regexp_replace(reg.desc_materia, 'Á', 'A','g'),'É', 'E','g'),'Í', 'I','g'),'Ó', 'O','g'),'Ú', 'U','g'));
 	  	carrera:=reg.cod_carrera;
 	  	detalle:=reg.desc_materia||'(';
 	  	band:=false;
 	  else
 	  	if trim(reg.desc_materia)=trim(mater) then 
 	  		detalle:=detalle||''||carrera||',' ;
 	  		carrera:=reg.cod_carrera;
 	  	else
 	        	detalle:=detalle||carrera||')'||reg.desc_materia||'(';
 	        	carrera:=reg.cod_carrera;
 	        	mater:=reg.desc_materia;
 	  	end if;		
 	  end if;
 	  
 	  
   
 	END LOOP;
 	detalle=detalle||carrera||')';
 else--la materia no esta en ningun conjunto
 	detalle:=nombre;
 end if;
 

return detalle;
END; 
$_$;


ALTER FUNCTION public.materias_conjunto(integer, integer, character, integer) OWNER TO postgres;

--
-- Name: minimo_docentes(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.minimo_docentes(integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	idproy		integer;
  	salida		text;
  	pdia		date;
  	udia		date;
  	cantidad	integer;
  	cantidadi	integer;
  	reg		record;
  	reg1		record;
  	band		boolean;
  	fh		date;
  	fin		date;
  	
BEGIN
idproy=$1;
cantidad=0;
cantidadi=0;

CREATE LOCAL TEMP TABLE auxiliar
(
  codigo		character varying,
  uni_acad		character(4),
  denominacion		character varying
  
);
--solo controlo proyectos que aun no han terminado
--FOR reg1 IN select * from pinvestigacion
            -- where fec_hasta>current_date 
     --LOOP
      --  cantidad=0;
	--cantidadi=0;
	select into fin case when fec_hasta>current_date then current_date else fec_hasta end  from pinvestigacion where id_pinv=idproy;
--separo porque a los regulares los cuento sin tener que analizar nada
      --cantidad de docentes regulares que estan en el proyecto o que se asocio al proyecto como interino pero lo regularizo
	select into cantidad count(id_docente) as cant from integrante_interno_pi i, pinvestigacion p, designacion d
	where pinvest=idproy
	and i.pinvest=p.id_pinv
	and i.id_designacion=d.id_designacion
	and i.hasta=p.fec_hasta --busco la cantidad de docentes que estan hasta el final
	and ((d.carac='R' and d.hasta is null) or (d.carac='I' and exists(select * from designacion dd where dd.id_docente=d.id_docente and dd.cat_estat=d.cat_estat and dd.dedic=d.dedic and dd.carac='R' and dd.hasta is null and dd.desde=d.hasta+1 )))
	and i.funcion_p<>'AS' and i.funcion_p<>'CO' and i.funcion_p<>'IA' and i.funcion_p<>'IAp' and i.funcion_p<>'AT';
--los regulares con fecha de fin no los cuento
--designaciones interinas que no estan dentro del grupo anterior
	FOR reg IN --analizo cada designacion interina para ver sino se cayo
	     select d.id_designacion,d.id_docente,d.desde,d.hasta,p.fec_hasta,d.cat_estat ,d.dedic from integrante_interno_pi i, designacion d ,pinvestigacion p
	     where pinvest=idproy
	     and i.pinvest=p.id_pinv
	     and i.id_designacion=d.id_designacion
	     and i.hasta=p.fec_hasta
	     and d.carac='I' 
	     and d.hasta is not null and d.desde<d.hasta 
	     and i.funcion_p<>'AS' and i.funcion_p<>'CO' and i.funcion_p<>'IA' and i.funcion_p<>'IAp' and i.funcion_p<>'AT'
	     and not exists (select * from designacion dd 
	     			where dd.id_docente=d.id_docente 
	     			and dd.cat_estat=d.cat_estat and dd.dedic=d.dedic and dd.carac='R' and dd.hasta is null and dd.desde=d.hasta+1 )--interino que no regularizo
 	     LOOP
 	   
 	     band=true;
 	     fh=reg.hasta;  
 	    
 	     WHILE (fh<fin and band) LOOP
 	       
 	        
 	     	if not exists(select * from designacion
 	     		where id_docente=reg.id_docente
 	     		and cat_estat=reg.cat_estat
 	     		and dedic=reg.dedic
 	     		and carac='I'
 	     		and hasta is not null and desde<hasta 
 	     		and desde=fh+1) then 
			band=false;
 	     	 else
 	     	 	select into fh hasta from designacion
 	     		where id_docente=reg.id_docente
 	     		and cat_estat=reg.cat_estat
 	     		and dedic=reg.dedic
 	     		and hasta is not null and desde<hasta 
 	     		and carac='I'
 	     		and desde=fh+1;  
 	     	  end if;
 	     --	--if fh is null then --no existe una designacion interina continua
 	     --	  --band=false;
 	     --	--end if;--si encuentra fh tendra la fecha hasta de la proxima designacion interina y asi repite hasta
 	     END LOOP;
 	     if band then--si sale true entonces la cuento
 	     	cantidadi=cantidadi+1;
 	     end if;
 	       
	END LOOP;
	--if (cantidad + cantidadi)<3 then
	--	insert into auxiliar(codigo,uni_acad,denominacion) values(reg1.codigo,reg1.uni_acad,reg1.denominacion) ;
	--end if;

--END LOOP;

return cantidad+cantidadi;
END; 
$_$;


ALTER FUNCTION public.minimo_docentes(integer) OWNER TO postgres;

--
-- Name: norma_baja(integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.norma_baja(integer, date, date) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	iddesig		integer;
  	salida		text;
  	pdia		date;
  	udia		date;

BEGIN
iddesig=$1;
pdia=$2;
udia=$3;

salida='';

select into salida case when b.id_novedad is not null then 'B('||b.tipo_norma||':'||b.norma_legal||')' else case when c.id_novedad is not null then 'L ('||c.tipo_norma||':'||c.norma_legal||')' else a.estado end end 
from designacion a
LEFT OUTER JOIN novedad b ON (a.id_designacion=b.id_designacion and b.tipo_nov in (1,4))
LEFT OUTER JOIN novedad c ON (a.id_designacion=c.id_designacion and c.tipo_nov in (2,5) and c.desde <= udia and (c.hasta >= pdia or c.hasta is null))
where a.id_designacion=iddesig;



return salida;
END; 
$_$;


ALTER FUNCTION public.norma_baja(integer, date, date) OWNER TO postgres;

--
-- Name: norma_baja_bl(integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.norma_baja_bl(integer, date, date) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	iddesig		integer;
  	salida		text;
  	pdia		date;
  	udia		date;
  	enlace_baja	text;
  	enlace_lic	text;

BEGIN
iddesig=$1;
pdia=$2;
udia=$3;

salida='';
--recupero el id de la novedad si es Baja o Lic
select into enlace_baja,enlace_lic case when b.id_novedad is not null then busca_norma(b.id_novedad) else '' end ,case when c.id_novedad is not null then busca_norma(c.id_novedad) else '' end
from designacion a
LEFT OUTER JOIN novedad b ON (a.id_designacion=b.id_designacion and b.tipo_nov in (1,4))
LEFT OUTER JOIN novedad c ON (a.id_designacion=c.id_designacion and c.tipo_nov in (2,5) and c.desde <= udia and (c.hasta >= pdia or c.hasta is null))
where a.id_designacion=iddesig;



select into salida case when b.id_novedad is not null then case when enlace_baja='' then 'B('||b.tipo_norma||':'||b.norma_legal||')' else '<a href='||chr(39)||enlace_baja||chr(39)|| ' target='||chr(39)||'_blank'||chr(39)||'>'||'B('||b.tipo_norma||':'||b.norma_legal||')'||'</a>' end else case when c.id_novedad is not null then case when enlace_lic='' then 'L ('||c.tipo_norma||':'||c.norma_legal||')' else   '<a href='||chr(39)||enlace_lic||chr(39)|| ' target='||chr(39)||'_blank'||chr(39)||'>'||'L ('||c.tipo_norma||':'||c.norma_legal||')'||'</a>' end else a.estado end end 
from designacion a
LEFT OUTER JOIN novedad b ON (a.id_designacion=b.id_designacion and b.tipo_nov in (1,4))
LEFT OUTER JOIN novedad c ON (a.id_designacion=c.id_designacion and c.tipo_nov in (2,5) and c.desde <= udia and (c.hasta >= pdia or c.hasta is null))
where a.id_designacion=iddesig;



return salida;
END; 
$_$;


ALTER FUNCTION public.norma_baja_bl(integer, date, date) OWNER TO postgres;

--
-- Name: pre_liquidacion_incentivos(integer, integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.pre_liquidacion_incentivos(integer, integer, character) RETURNS date
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      character(4);
  anio		integer;
  m		integer;
  mesdesde	integer;
  meshasta	integer;
  arreglo       integer[10];
  pdiames	date;
  pdiames2	date;
  pdiames3	date;
  pdiames4	date;
      
  udiames	date;
  udiames2	date;
  udiames3	date;
  udiames4	date;
  reg		record;

BEGIN
anio:=$1;
mesdesde:=$2;
meshasta:=$2+3;--siempre calculo por 4 meses
uni:=$3;


--primer dia de mes
pdiames:=  CAST ('01'  || '/' || mesdesde || '/' ||anio AS DATE);
pdiames2:=  CAST ('01'  || '/' || mesdesde+1 || '/' ||anio AS DATE);
pdiames3:=  CAST ('01'  || '/' || mesdesde+2 || '/' ||anio AS DATE);
pdiames4:=  CAST ('01'  || '/' || mesdesde+3 || '/' ||anio AS DATE);
--ultimo dia del primer mes que ingresa como parametro
  IF mesdesde=1 or mesdesde=3 or mesdesde=5 or mesdesde=7 or mesdesde=8 or mesdesde=10 or mesdesde=12  THEN
	udiames:=  CAST ( '31' || '/' || mesdesde || '/' ||anio AS DATE);		
   ELSE   IF mesdesde=4 or mesdesde=6 or mesdesde=9 or mesdesde=11  THEN
		udiames:=  CAST ( '30' || '/' || mesdesde || '/' ||anio AS DATE);
	  ELSE   udiames:=  CAST ( '28' || '/' || mesdesde || '/' ||anio AS DATE);
          END IF; 
   END IF; 
m=mesdesde+1;
  IF m=1 or m=3 or m=5 or m=7 or m=8 or m=10 or m=12  THEN
	udiames2:=  CAST ( '31' || '/' || m || '/' ||anio AS DATE);		
   ELSE   IF m=4 or m=6 or m=9 or m=11  THEN
		udiames2:=  CAST ( '30' || '/' || m || '/' ||anio AS DATE);
	  ELSE   udiames2:=  CAST ( '28' || '/' || m || '/' ||anio AS DATE);
          END IF; 
   END IF; 

m=mesdesde+1;
  IF m=1 or m=3 or m=5 or m=7 or m=8 or m=10 or m=12  THEN
	udiames3:=  CAST ( '31' || '/' || m || '/' ||anio AS DATE);		
   ELSE   IF m=4 or m=6 or m=9 or m=11  THEN
		udiames3:=  CAST ( '30' || '/' || m || '/' ||anio AS DATE);
	  ELSE   udiames3:=  CAST ( '28' || '/' || m || '/' ||anio AS DATE);
          END IF; 
   END IF; 
m=mesdesde+1;
  IF m=1 or m=3 or m=5 or m=7 or m=8 or m=10 or m=12  THEN
	udiames4:=  CAST ( '31' || '/' || m || '/' ||anio AS DATE);		
   ELSE   IF m=4 or m=6 or m=9 or m=11  THEN
		udiames4:=  CAST ( '30' || '/' || m || '/' ||anio AS DATE);
	  ELSE   udiames4:=  CAST ( '28' || '/' || m || '/' ||anio AS DATE);
          END IF; 
   END IF; 

CREATE LOCAL TEMP TABLE auxiliar
(
  id_docente      	integer,
  id_proy 		integer,
  categoria		integer,
  dedic_doc1		integer,
  dedic_inv1		integer,
  dedic_doc2		integer,
  dedic_inv2		integer,
  dedic_doc3		integer,
  dedic_inv3		integer,
  dedic_doc4		integer,
  dedic_inv4		integer
    
  );
  
--ingreso todos los docentes que son integrantes de proyectos de investigacion de la ua que ingresa como argumento
--calculo la dedicacion docente del primer mes 
insert into auxiliar
select a.id_docente,a.pinvest,a.cat_investigador,a.dedic_doc1,0,b.dedic_doc2,0,c.dedic_doc3,0,d.dedic_doc4,0 from
(select d.id_docente,pinvest,i.cat_investigador,min(case when t_d.dedic is not null then t_d.dedic else d.dedic end ) as dedic_doc1 
from 
	integrante_interno_pi i
 		LEFT OUTER JOIN designacion d ON (d.id_designacion=i.id_designacion)
 		LEFT OUTER JOIN designacion t_d ON (d.id_docente=t_d.id_docente and t_d.uni_acad=uni and t_d.desde <= udiames and (t_d.hasta >= pdiames or t_d.hasta is null))
 		where ua=uni
 		and cat_investigador<>6
 		and exists(select * from pinvestigacion p_i where p_i.id_pinv=i.pinvest and p_i.uni_acad=ua)--el proyecto es de la facultad
 		and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 		and i.hasta>=pdiames and i.desde<=udiames
 group by d.id_docente,pinvest,i.cat_investigador)a
 LEFT OUTER JOIN (
 		select d.id_docente,pinvest,cat_investigador,min(case when t_d.dedic is not null then t_d.dedic else d.dedic end )as dedic_doc2
 		from integrante_interno_pi i
 		LEFT OUTER JOIN designacion d ON (d.id_designacion=i.id_designacion)
 		LEFT OUTER JOIN designacion t_d ON (d.id_docente=t_d.id_docente and t_d.uni_acad=uni and t_d.desde <= udiames2 and (t_d.hasta >= pdiames2 or t_d.hasta is null))
 		where ua=uni
 		and cat_investigador<>6
 		and exists(select * from pinvestigacion p_i where p_i.id_pinv=i.pinvest and p_i.uni_acad=ua)--el proyecto es de la facultad
 		and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 		and i.hasta>=pdiames2 and i.desde<=udiames2
 		group by d.id_docente,pinvest,cat_investigador)b ON (a.id_docente=b.id_docente and a.pinvest=b.pinvest and a.cat_investigador=b.cat_investigador)
LEFT OUTER JOIN (
 		select d.id_docente,pinvest,cat_investigador,min(case when t_d.dedic is not null then t_d.dedic else d.dedic end )as dedic_doc3
 		from integrante_interno_pi i
 		LEFT OUTER JOIN designacion d ON (d.id_designacion=i.id_designacion)
 		LEFT OUTER JOIN designacion t_d ON (d.id_docente=t_d.id_docente and t_d.uni_acad=uni and t_d.desde <= udiames3 and (t_d.hasta >= pdiames3 or t_d.hasta is null))
 		where ua=uni
 		and cat_investigador<>6
 		and exists(select * from pinvestigacion p_i where p_i.id_pinv=i.pinvest and p_i.uni_acad=ua)--el proyecto es de la facultad
 		and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 		and i.hasta>=pdiames3 and i.desde<=udiames3
 		group by d.id_docente,pinvest,cat_investigador)c ON (c.id_docente=b.id_docente and c.pinvest=b.pinvest and c.cat_investigador=b.cat_investigador)
LEFT OUTER JOIN (
 		select d.id_docente,pinvest,cat_investigador,min(case when t_d.dedic is not null then t_d.dedic else d.dedic end )as dedic_doc4
 		from integrante_interno_pi i
 		LEFT OUTER JOIN designacion d ON (d.id_designacion=i.id_designacion)
 		LEFT OUTER JOIN designacion t_d ON (d.id_docente=t_d.id_docente and t_d.uni_acad=uni and t_d.desde <= udiames4 and (t_d.hasta >= pdiames4 or t_d.hasta is null))
 		where ua=uni
 		and cat_investigador<>6
 		and exists(select * from pinvestigacion p_i where p_i.id_pinv=i.pinvest and p_i.uni_acad=ua)--el proyecto es de la facultad
 		and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 		and i.hasta>=pdiames4 and i.desde<=udiames4
 		group by d.id_docente,pinvest,cat_investigador)d ON (c.id_docente=d.id_docente and c.pinvest=d.pinvest and c.cat_investigador=d.cat_investigador);
 
--calculo dedicacion en la investigacion del primer mes
FOR reg IN
--busco la carga horaria y la funcion en el primer mes para ese docente en ese proyecto y en ese periodo
 select b.carga_horaria,b.funcion_p,b.cat_invest_conicet,a.id_docente,a.id_proy,a.categoria,a.dedic_doc1 from auxiliar a, integrante_interno_pi b, designacion c 
 where a.id_proy=b.pinvest and a.categoria=b.cat_investigador and b.id_designacion=c.id_designacion and c.id_docente=a.id_docente
 and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 and b.hasta>=pdiames and b.desde<=udiames
LOOP

IF (reg.funcion_p='BC' or reg.cat_invest_conicet is not null) THEN --si es becario conicet o tiene categ conicet entonces corresponde 1
   update auxiliar set dedic_inv1=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
ELSE 
   IF reg.dedic_doc1=1 THEN --si tiene una dedicacion docente 1 (exclusiva)
     IF reg.carga_horaria>=20 THEN --y >=20 hs
         update auxiliar set dedic_inv1=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     		update auxiliar set dedic_inv1=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     	  ELSE --tiene menos de 10 hs	
     	  	update auxiliar set dedic_inv1=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
          END IF;    
     END IF;
   ELSE IF reg.dedic_doc1=2 THEN--si tiene una parcial 
   		IF reg.carga_horaria>=20 THEN --y >=20 hs
         		update auxiliar set dedic_inv1=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     		ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     			update auxiliar set dedic_inv1=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     	  	     ELSE --tiene menos de 10 hs	
     	  		update auxiliar set dedic_inv1=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
          	     END IF;    
     		END IF;
     	ELSE --es simple en docente	
     	  IF reg.carga_horaria<10 THEN
     	  	update auxiliar set dedic_inv1=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     	  ELSE	
     	  	update auxiliar set dedic_inv1=0 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     	  END IF;	
        END IF;  
   END IF;
END IF;

END LOOP ;
 ---recorrido para calcular la dedicacion en investigacion en el segundo mes
 FOR reg IN
--busco la carga horaria y la funcion que ese docente tuvo en ese proyecto y en ese periodo
 select b.carga_horaria,b.funcion_p,b.cat_invest_conicet,a.id_docente,a.id_proy,a.categoria,a.dedic_doc2 from auxiliar a, integrante_interno_pi b, designacion c 
 where a.id_proy=b.pinvest and a.categoria=b.cat_investigador and b.id_designacion=c.id_designacion and c.id_docente=a.id_docente
 and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 and b.hasta>=pdiames2 and b.desde<=udiames2
LOOP

IF (reg.funcion_p='BC' or reg.cat_invest_conicet is not null) THEN --si es becario conicet o tiene categ conicet entonces corresponde 1
   update auxiliar set dedic_inv2=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
ELSE 
   IF reg.dedic_doc2=1 THEN --si tiene una dedicacion docente 1 (exclusiva)
     IF reg.carga_horaria>=20 THEN --y >=20 hs
         update auxiliar set dedic_inv2=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     		update auxiliar set dedic_inv2=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     	  ELSE --tiene menos de 10 hs	
     	  	update auxiliar set dedic_inv2=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
          END IF;    
     END IF;
   ELSE IF reg.dedic_doc2=2 THEN--si tiene una parcial 
   		IF reg.carga_horaria>=20 THEN --y >=20 hs
         		update auxiliar set dedic_inv2=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     		ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     			update auxiliar set dedic_inv2=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     	  	     ELSE --tiene menos de 10 hs	
     	  		update auxiliar set dedic_inv2=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
          	     END IF;    
     		END IF;
     	ELSE --es simple en docente	
     	  IF reg.carga_horaria<10 THEN
     	  	update auxiliar set dedic_inv2=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     	  ELSE
     	  	update auxiliar set dedic_inv2=0 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     	  END IF;	
        END IF;  
   END IF;
END IF;

END LOOP ;

--3er recorrido
FOR reg IN
--busco la carga horaria y la funcion que ese docente tuvo en ese proyecto y en ese periodo
 select b.carga_horaria,b.funcion_p,b.cat_invest_conicet,a.id_docente,a.id_proy,a.categoria,a.dedic_doc3 from auxiliar a, integrante_interno_pi b, designacion c 
 where a.id_proy=b.pinvest and a.categoria=b.cat_investigador and b.id_designacion=c.id_designacion and c.id_docente=a.id_docente
 and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 and b.hasta>=pdiames3 and b.desde<=udiames3
LOOP

IF (reg.funcion_p='BC' or reg.cat_invest_conicet is not null) THEN --si es becario conicet o tiene categ conicet entonces corresponde 1
   update auxiliar set dedic_inv3=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
ELSE 
   IF reg.dedic_doc3=1 THEN --si tiene una dedicacion docente 1 (exclusiva)
     IF reg.carga_horaria>=20 THEN --y >=20 hs
         update auxiliar set dedic_inv3=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     		update auxiliar set dedic_inv3=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     	  ELSE --tiene menos de 10 hs	
     	  	update auxiliar set dedic_inv3=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
          END IF;    
     END IF;
   ELSE IF reg.dedic_doc3=2 THEN--si tiene una parcial 
   		IF reg.carga_horaria>=20 THEN --y >=20 hs
         		update auxiliar set dedic_inv3=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     		ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     			update auxiliar set dedic_inv3=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     	  	     ELSE --tiene menos de 10 hs	
     	  		update auxiliar set dedic_inv3=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
          	     END IF;    
     		END IF;
     	ELSE --es simple en docente	
     	  IF reg.carga_horaria<10 THEN
     	  	update auxiliar set dedic_inv3=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     	  ELSE	
     	  	update auxiliar set dedic_inv3=0 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     	  END IF;	
        END IF;  
   END IF;
END IF;

END LOOP ;

--4to recorrido
FOR reg IN
--busco la carga horaria y la funcion en el primer mes para ese docente en ese proyecto y en ese periodo
 select b.carga_horaria,b.funcion_p,b.cat_invest_conicet,a.id_docente,a.id_proy,a.categoria,a.dedic_doc4 from auxiliar a, integrante_interno_pi b, designacion c 
 where a.id_proy=b.pinvest and a.categoria=b.cat_investigador and b.id_designacion=c.id_designacion and c.id_docente=a.id_docente
 and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 and b.hasta>=pdiames4 and b.desde<=udiames4
LOOP

IF (reg.funcion_p='BC' or reg.cat_invest_conicet is not null) THEN --si es becario conicet o tiene categ conicet entonces corresponde 1
   update auxiliar set dedic_inv4=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
ELSE 
   IF reg.dedic_doc4=1 THEN --si tiene una dedicacion docente 1 (exclusiva)
     IF reg.carga_horaria>=20 THEN --y >=20 hs
         update auxiliar set dedic_inv4=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     		update auxiliar set dedic_inv4=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     	  ELSE --tiene menos de 10 hs	
     	  	update auxiliar set dedic_inv4=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
          END IF;    
     END IF;
   ELSE IF reg.dedic_doc4=2 THEN--si tiene una parcial 
   		IF reg.carga_horaria>=20 THEN --y >=20 hs
         		update auxiliar set dedic_inv4=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     		ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     			update auxiliar set dedic_inv4=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     	  	     ELSE --tiene menos de 10 hs	
     	  		update auxiliar set dedic_inv4=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
          	     END IF;    
     		END IF;
     	ELSE --es simple en docente	
     	  IF reg.carga_horaria<10 THEN
     	  	update auxiliar set dedic_inv4=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     	  ELSE
     	  	update auxiliar set dedic_inv4=0 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;	
     	  END IF;	
        END IF;  
   END IF;
END IF;

END LOOP ;
 return udiames;
  
END;
$_$;


ALTER FUNCTION public.pre_liquidacion_incentivos(integer, integer, character) OWNER TO postgres;

--
-- Name: recuperar_schema_temp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.recuperar_schema_temp() RETURNS character varying
    LANGUAGE plpgsql
    AS $$
			DECLARE
			   schemas varchar;
			   pos_inicial int4;
			   pos_final int4;
			   schema_temp varchar;
			BEGIN
			   schema_temp := '';
			   SELECT INTO schemas current_schemas(true);
			   SELECT INTO pos_inicial strpos(schemas, 'pg_temp');
			   IF (pos_inicial > 0) THEN
			      SELECT INTO pos_final strpos(schemas, ',');
			      SELECT INTO schema_temp substr(schemas, pos_inicial, pos_final - pos_inicial);
			   END IF;
			   RETURN schema_temp;
			END;
			$$;


ALTER FUNCTION public.recuperar_schema_temp() OWNER TO postgres;

--
-- Name: sp_area(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_area() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_area (idarea, iddepto, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.idarea, NEW.iddepto, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_area (idarea, iddepto, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.idarea, OLD.iddepto, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_area() OWNER TO postgres;

--
-- Name: sp_articulo_73(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_articulo_73() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_articulo_73 (id_designacion, antiguedad, nro_tab11, modo_ingreso, nro_tab12, continuidad, observacion, nro_resolucion, check_academica, observacion_acad, pase_superior, cat_est_reg, dedic_reg, id_departamento, id_area, id_orientacion, check_presup, observacion_presup, expediente, etapa, articulo, cat_que_reg, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.antiguedad, NEW.nro_tab11, NEW.modo_ingreso, NEW.nro_tab12, NEW.continuidad, NEW.observacion, NEW.nro_resolucion, NEW.check_academica, NEW.observacion_acad, NEW.pase_superior, NEW.cat_est_reg, NEW.dedic_reg, NEW.id_departamento, NEW.id_area, NEW.id_orientacion, NEW.check_presup, NEW.observacion_presup, NEW.expediente, NEW.etapa, NEW.articulo, NEW.cat_que_reg, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_articulo_73 (id_designacion, antiguedad, nro_tab11, modo_ingreso, nro_tab12, continuidad, observacion, nro_resolucion, check_academica, observacion_acad, pase_superior, cat_est_reg, dedic_reg, id_departamento, id_area, id_orientacion, check_presup, observacion_presup, expediente, etapa, articulo, cat_que_reg, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.antiguedad, OLD.nro_tab11, OLD.modo_ingreso, OLD.nro_tab12, OLD.continuidad, OLD.observacion, OLD.nro_resolucion, OLD.check_academica, OLD.observacion_acad, OLD.pase_superior, OLD.cat_est_reg, OLD.dedic_reg, OLD.id_departamento, OLD.id_area, OLD.id_orientacion, OLD.check_presup, OLD.observacion_presup, OLD.expediente, OLD.etapa, OLD.articulo, OLD.cat_que_reg, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_articulo_73() OWNER TO postgres;

--
-- Name: sp_asignacion_materia(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_asignacion_materia() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_asignacion_materia (id_designacion, id_materia, nro_tab8, rol, id_periodo, modulo, carga_horaria, anio, externa, observacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.id_materia, NEW.nro_tab8, NEW.rol, NEW.id_periodo, NEW.modulo, NEW.carga_horaria, NEW.anio, NEW.externa, NEW.observacion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_asignacion_materia (id_designacion, id_materia, nro_tab8, rol, id_periodo, modulo, carga_horaria, anio, externa, observacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.id_materia, OLD.nro_tab8, OLD.rol, OLD.id_periodo, OLD.modulo, OLD.carga_horaria, OLD.anio, OLD.externa, OLD.observacion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_asignacion_materia() OWNER TO postgres;

--
-- Name: sp_asignacion_tutoria(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_asignacion_tutoria() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_asignacion_tutoria (id_designacion, id_tutoria, anio, carga_horaria, nro_tab9, rol, periodo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.id_tutoria, NEW.anio, NEW.carga_horaria, NEW.nro_tab9, NEW.rol, NEW.periodo, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_asignacion_tutoria (id_designacion, id_tutoria, anio, carga_horaria, nro_tab9, rol, periodo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.id_tutoria, OLD.anio, OLD.carga_horaria, OLD.nro_tab9, OLD.rol, OLD.periodo, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_asignacion_tutoria() OWNER TO postgres;

--
-- Name: sp_auxi_docente(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_auxi_docente() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_auxi_docente (id_docente, legajo, apellido, nombre, nro_tabla, tipo_docum, nro_docum, fec_nacim, nro_cuil1, nro_cuil, nro_cuil2, tipo_sexo, pais_nacim, porcdedicdocente, porcdedicinvestig, porcdedicagestion, porcdedicaextens, pcia_nacim, fec_ingreso, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_docente, NEW.legajo, NEW.apellido, NEW.nombre, NEW.nro_tabla, NEW.tipo_docum, NEW.nro_docum, NEW.fec_nacim, NEW.nro_cuil1, NEW.nro_cuil, NEW.nro_cuil2, NEW.tipo_sexo, NEW.pais_nacim, NEW.porcdedicdocente, NEW.porcdedicinvestig, NEW.porcdedicagestion, NEW.porcdedicaextens, NEW.pcia_nacim, NEW.fec_ingreso, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_auxi_docente (id_docente, legajo, apellido, nombre, nro_tabla, tipo_docum, nro_docum, fec_nacim, nro_cuil1, nro_cuil, nro_cuil2, tipo_sexo, pais_nacim, porcdedicdocente, porcdedicinvestig, porcdedicagestion, porcdedicaextens, pcia_nacim, fec_ingreso, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_docente, OLD.legajo, OLD.apellido, OLD.nombre, OLD.nro_tabla, OLD.tipo_docum, OLD.nro_docum, OLD.fec_nacim, OLD.nro_cuil1, OLD.nro_cuil, OLD.nro_cuil2, OLD.tipo_sexo, OLD.pais_nacim, OLD.porcdedicdocente, OLD.porcdedicinvestig, OLD.porcdedicagestion, OLD.porcdedicaextens, OLD.pcia_nacim, OLD.fec_ingreso, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_auxi_docente() OWNER TO postgres;

--
-- Name: sp_caracter(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_caracter() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_caracter (id_car, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_car, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_caracter (id_car, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_car, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_caracter() OWNER TO postgres;

--
-- Name: sp_categ_estatuto(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_categ_estatuto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_categ_estatuto (codigo_est, descripcion, orden, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.codigo_est, NEW.descripcion, NEW.orden, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_categ_estatuto (codigo_est, descripcion, orden, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.codigo_est, OLD.descripcion, OLD.orden, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_categ_estatuto() OWNER TO postgres;

--
-- Name: sp_categ_siu(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_categ_siu() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_categ_siu (codigo_siu, descripcion, escalafon, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.codigo_siu, NEW.descripcion, NEW.escalafon, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_categ_siu (codigo_siu, descripcion, escalafon, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.codigo_siu, OLD.descripcion, OLD.escalafon, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_categ_siu() OWNER TO postgres;

--
-- Name: sp_categoria_invest(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_categoria_invest() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_categoria_invest (cod_cati, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.cod_cati, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_categoria_invest (cod_cati, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.cod_cati, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_categoria_invest() OWNER TO postgres;

--
-- Name: sp_categorizacion(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_categorizacion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_categorizacion (id, id_docente, id_cat, anio_categ, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id, NEW.id_docente, NEW.id_cat, NEW.anio_categ, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_categorizacion (id, id_docente, id_cat, anio_categ, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id, OLD.id_docente, OLD.id_cat, OLD.anio_categ, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_categorizacion() OWNER TO postgres;

--
-- Name: sp_cic_conicef(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_cic_conicef() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_cic_conicef (id, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_cic_conicef (id, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_cic_conicef() OWNER TO postgres;

--
-- Name: sp_cobro_incentivo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_cobro_incentivo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_cobro_incentivo (id_docente, id_proyecto, cuota, fecha, monto, anio, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_docente, NEW.id_proyecto, NEW.cuota, NEW.fecha, NEW.monto, NEW.anio, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_cobro_incentivo (id_docente, id_proyecto, cuota, fecha, monto, anio, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_docente, OLD.id_proyecto, OLD.cuota, OLD.fecha, OLD.monto, OLD.anio, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_cobro_incentivo() OWNER TO postgres;

--
-- Name: sp_comision(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_comision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_comision (id_comision, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_comision, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_comision (id_comision, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_comision, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_comision() OWNER TO postgres;

--
-- Name: sp_conjunto(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_conjunto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_conjunto (id_conjunto, descripcion, ua, id_periodo, id_periodo_pres, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_conjunto, NEW.descripcion, NEW.ua, NEW.id_periodo, NEW.id_periodo_pres, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_conjunto (id_conjunto, descripcion, ua, id_periodo, id_periodo_pres, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_conjunto, OLD.descripcion, OLD.ua, OLD.id_periodo, OLD.id_periodo_pres, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_conjunto() OWNER TO postgres;

--
-- Name: sp_dao_designa(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_dao_designa() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_dao_designa (id_designacion, id_departamento, id_area, id_orientacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.id_departamento, NEW.id_area, NEW.id_orientacion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_dao_designa (id_designacion, id_departamento, id_area, id_orientacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.id_departamento, OLD.id_area, OLD.id_orientacion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_dao_designa() OWNER TO postgres;

--
-- Name: sp_dedicacion(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_dedicacion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_dedicacion (id_ded, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_ded, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_dedicacion (id_ded, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_ded, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_dedicacion() OWNER TO postgres;

--
-- Name: sp_dedicacion_incentivo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_dedicacion_incentivo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_dedicacion_incentivo (id_di, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_di, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_dedicacion_incentivo (id_di, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_di, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_dedicacion_incentivo() OWNER TO postgres;

--
-- Name: sp_departamento(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_departamento() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_departamento (iddepto, idunidad_academica, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.iddepto, NEW.idunidad_academica, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_departamento (iddepto, idunidad_academica, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.iddepto, OLD.idunidad_academica, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_departamento() OWNER TO postgres;

--
-- Name: sp_designacion(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_designacion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_designacion (id_designacion, id_docente, nro_cargo, anio_acad, desde, hasta, cat_mapuche, cat_estat, dedic, carac, uni_acad, id_departamento, id_area, id_orientacion, id_norma, id_expediente, tipo_incentivo, dedi_incen, cic_con, cargo_gestion, ord_gestion, emite_cargo_gestion, nro_gestion, observaciones, check_presup, nro_540, concursado, check_academica, tipo_desig, id_reserva, estado, id_norma_cs, por_permuta, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.id_docente, NEW.nro_cargo, NEW.anio_acad, NEW.desde, NEW.hasta, NEW.cat_mapuche, NEW.cat_estat, NEW.dedic, NEW.carac, NEW.uni_acad, NEW.id_departamento, NEW.id_area, NEW.id_orientacion, NEW.id_norma, NEW.id_expediente, NEW.tipo_incentivo, NEW.dedi_incen, NEW.cic_con, NEW.cargo_gestion, NEW.ord_gestion, NEW.emite_cargo_gestion, NEW.nro_gestion, NEW.observaciones, NEW.check_presup, NEW.nro_540, NEW.concursado, NEW.check_academica, NEW.tipo_desig, NEW.id_reserva, NEW.estado, NEW.id_norma_cs, NEW.por_permuta, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_designacion (id_designacion, id_docente, nro_cargo, anio_acad, desde, hasta, cat_mapuche, cat_estat, dedic, carac, uni_acad, id_departamento, id_area, id_orientacion, id_norma, id_expediente, tipo_incentivo, dedi_incen, cic_con, cargo_gestion, ord_gestion, emite_cargo_gestion, nro_gestion, observaciones, check_presup, nro_540, concursado, check_academica, tipo_desig, id_reserva, estado, id_norma_cs, por_permuta, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.id_docente, OLD.nro_cargo, OLD.anio_acad, OLD.desde, OLD.hasta, OLD.cat_mapuche, OLD.cat_estat, OLD.dedic, OLD.carac, OLD.uni_acad, OLD.id_departamento, OLD.id_area, OLD.id_orientacion, OLD.id_norma, OLD.id_expediente, OLD.tipo_incentivo, OLD.dedi_incen, OLD.cic_con, OLD.cargo_gestion, OLD.ord_gestion, OLD.emite_cargo_gestion, OLD.nro_gestion, OLD.observaciones, OLD.check_presup, OLD.nro_540, OLD.concursado, OLD.check_academica, OLD.tipo_desig, OLD.id_reserva, OLD.estado, OLD.id_norma_cs, OLD.por_permuta, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_designacion() OWNER TO postgres;

--
-- Name: sp_designacionh(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_designacionh() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_designacionh (id_designacion, id_docente, nro_cargo, anio_acad, desde, hasta, cat_mapuche, cat_estat, dedic, carac, uni_acad, id_departamento, id_area, id_orientacion, id_norma, id_expediente, tipo_incentivo, dedi_incen, cic_con, cargo_gestion, ord_gestion, emite_cargo_gestion, nro_gestion, observaciones, check_presup, nro_540, concursado, check_academica, tipo_desig, id_reserva, estado, id_norma_cs, por_permuta, id, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.id_docente, NEW.nro_cargo, NEW.anio_acad, NEW.desde, NEW.hasta, NEW.cat_mapuche, NEW.cat_estat, NEW.dedic, NEW.carac, NEW.uni_acad, NEW.id_departamento, NEW.id_area, NEW.id_orientacion, NEW.id_norma, NEW.id_expediente, NEW.tipo_incentivo, NEW.dedi_incen, NEW.cic_con, NEW.cargo_gestion, NEW.ord_gestion, NEW.emite_cargo_gestion, NEW.nro_gestion, NEW.observaciones, NEW.check_presup, NEW.nro_540, NEW.concursado, NEW.check_academica, NEW.tipo_desig, NEW.id_reserva, NEW.estado, NEW.id_norma_cs, NEW.por_permuta, NEW.id, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_designacionh (id_designacion, id_docente, nro_cargo, anio_acad, desde, hasta, cat_mapuche, cat_estat, dedic, carac, uni_acad, id_departamento, id_area, id_orientacion, id_norma, id_expediente, tipo_incentivo, dedi_incen, cic_con, cargo_gestion, ord_gestion, emite_cargo_gestion, nro_gestion, observaciones, check_presup, nro_540, concursado, check_academica, tipo_desig, id_reserva, estado, id_norma_cs, por_permuta, id, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.id_docente, OLD.nro_cargo, OLD.anio_acad, OLD.desde, OLD.hasta, OLD.cat_mapuche, OLD.cat_estat, OLD.dedic, OLD.carac, OLD.uni_acad, OLD.id_departamento, OLD.id_area, OLD.id_orientacion, OLD.id_norma, OLD.id_expediente, OLD.tipo_incentivo, OLD.dedi_incen, OLD.cic_con, OLD.cargo_gestion, OLD.ord_gestion, OLD.emite_cargo_gestion, OLD.nro_gestion, OLD.observaciones, OLD.check_presup, OLD.nro_540, OLD.concursado, OLD.check_academica, OLD.tipo_desig, OLD.id_reserva, OLD.estado, OLD.id_norma_cs, OLD.por_permuta, OLD.id, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_designacionh() OWNER TO postgres;

--
-- Name: sp_director_dpto(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_director_dpto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_director_dpto (id_docente, iddepto, desde, hasta, resol, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_docente, NEW.iddepto, NEW.desde, NEW.hasta, NEW.resol, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_director_dpto (id_docente, iddepto, desde, hasta, resol, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_docente, OLD.iddepto, OLD.desde, OLD.hasta, OLD.resol, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_director_dpto() OWNER TO postgres;

--
-- Name: sp_disciplina(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_disciplina() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_disciplina (id_disc, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_disc, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_disciplina (id_disc, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_disc, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_disciplina() OWNER TO postgres;

--
-- Name: sp_docente(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_docente() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_docente (id_docente, legajo, apellido, nombre, nro_tabla, tipo_docum, nro_docum, fec_nacim, nro_cuil1, nro_cuil, nro_cuil2, tipo_sexo, pais_nacim, porcdedicdocente, porcdedicinvestig, porcdedicagestion, porcdedicaextens, pcia_nacim, fec_ingreso, correo_institucional, correo_personal, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_docente, NEW.legajo, NEW.apellido, NEW.nombre, NEW.nro_tabla, NEW.tipo_docum, NEW.nro_docum, NEW.fec_nacim, NEW.nro_cuil1, NEW.nro_cuil, NEW.nro_cuil2, NEW.tipo_sexo, NEW.pais_nacim, NEW.porcdedicdocente, NEW.porcdedicinvestig, NEW.porcdedicagestion, NEW.porcdedicaextens, NEW.pcia_nacim, NEW.fec_ingreso, NEW.correo_institucional, NEW.correo_personal, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_docente (id_docente, legajo, apellido, nombre, nro_tabla, tipo_docum, nro_docum, fec_nacim, nro_cuil1, nro_cuil, nro_cuil2, tipo_sexo, pais_nacim, porcdedicdocente, porcdedicinvestig, porcdedicagestion, porcdedicaextens, pcia_nacim, fec_ingreso, correo_institucional, correo_personal, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_docente, OLD.legajo, OLD.apellido, OLD.nombre, OLD.nro_tabla, OLD.tipo_docum, OLD.nro_docum, OLD.fec_nacim, OLD.nro_cuil1, OLD.nro_cuil, OLD.nro_cuil2, OLD.tipo_sexo, OLD.pais_nacim, OLD.porcdedicdocente, OLD.porcdedicinvestig, OLD.porcdedicagestion, OLD.porcdedicaextens, OLD.pcia_nacim, OLD.fec_ingreso, OLD.correo_institucional, OLD.correo_personal, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_docente() OWNER TO postgres;

--
-- Name: sp_en_conjunto(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_en_conjunto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_en_conjunto (id_conjunto, id_materia, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_conjunto, NEW.id_materia, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_en_conjunto (id_conjunto, id_materia, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_conjunto, OLD.id_materia, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_en_conjunto() OWNER TO postgres;

--
-- Name: sp_entidad_otorgante(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_entidad_otorgante() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_entidad_otorgante (cod_entidad, nombre, cod_ciudad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.cod_entidad, NEW.nombre, NEW.cod_ciudad, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_entidad_otorgante (cod_entidad, nombre, cod_ciudad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.cod_entidad, OLD.nombre, OLD.cod_ciudad, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_entidad_otorgante() OWNER TO postgres;

--
-- Name: sp_escalafon(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_escalafon() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_escalafon (id_escalafon, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_escalafon, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_escalafon (id_escalafon, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_escalafon, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_escalafon() OWNER TO postgres;

--
-- Name: sp_estado_pi(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_estado_pi() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_estado_pi (id_estado, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_estado, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_estado_pi (id_estado, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_estado, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_estado_pi() OWNER TO postgres;

--
-- Name: sp_estado_pr(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_estado_pr() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_estado_pr (id_estado, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_estado, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_estado_pr (id_estado, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_estado, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_estado_pr() OWNER TO postgres;

--
-- Name: sp_estado_solicitud(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_estado_solicitud() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_estado_solicitud (id_estado_solicitud, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_estado_solicitud, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_estado_solicitud (id_estado_solicitud, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_estado_solicitud, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_estado_solicitud() OWNER TO postgres;

--
-- Name: sp_estado_vi(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_estado_vi() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_estado_vi (id_estado, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_estado, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_estado_vi (id_estado, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_estado, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_estado_vi() OWNER TO postgres;

--
-- Name: sp_estimulo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_estimulo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_estimulo (resolucion, expediente, fecha_pagado, anio, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.resolucion, NEW.expediente, NEW.fecha_pagado, NEW.anio, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_estimulo (resolucion, expediente, fecha_pagado, anio, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.resolucion, OLD.expediente, OLD.fecha_pagado, OLD.anio, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_estimulo() OWNER TO postgres;

--
-- Name: sp_expediente(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_expediente() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_expediente (id_exp, nro_exp, tipo_exp, emite_tipo, fecha, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_exp, NEW.nro_exp, NEW.tipo_exp, NEW.emite_tipo, NEW.fecha, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_expediente (id_exp, nro_exp, tipo_exp, emite_tipo, fecha, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_exp, OLD.nro_exp, OLD.tipo_exp, OLD.emite_tipo, OLD.fecha, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_expediente() OWNER TO postgres;

--
-- Name: sp_funcion_extension(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_funcion_extension() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_funcion_extension (id_extension, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_extension, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_funcion_extension (id_extension, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_extension, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_funcion_extension() OWNER TO postgres;

--
-- Name: sp_funcion_investigador(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_funcion_investigador() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_funcion_investigador (id_funcion, descripcion, orden, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_funcion, NEW.descripcion, NEW.orden, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_funcion_investigador (id_funcion, descripcion, orden, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_funcion, OLD.descripcion, OLD.orden, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_funcion_investigador() OWNER TO postgres;

--
-- Name: sp_historial(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_historial() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_historial (id_historial, fecha, id_estado, id_solicitud, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_historial, NEW.fecha, NEW.id_estado, NEW.id_solicitud, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_historial (id_historial, fecha, id_estado, id_solicitud, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_historial, OLD.fecha, OLD.id_estado, OLD.id_solicitud, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_historial() OWNER TO postgres;

--
-- Name: sp_impresion_540(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_impresion_540() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_impresion_540 (id, fecha_impresion, expediente, estado, anio, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id, NEW.fecha_impresion, NEW.expediente, NEW.estado, NEW.anio, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_impresion_540 (id, fecha_impresion, expediente, estado, anio, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id, OLD.fecha_impresion, OLD.expediente, OLD.estado, OLD.anio, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_impresion_540() OWNER TO postgres;

--
-- Name: sp_imputacion(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_imputacion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_imputacion (id_designacion, porc, id_programa, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.porc, NEW.id_programa, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_imputacion (id_designacion, porc, id_programa, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.porc, OLD.id_programa, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_imputacion() OWNER TO postgres;

--
-- Name: sp_incentivo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_incentivo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_incentivo (id_inc, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_inc, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_incentivo (id_inc, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_inc, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_incentivo() OWNER TO postgres;

--
-- Name: sp_inscriptos(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_inscriptos() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_inscriptos (inscriptos, anio_acad, id_materia, id_periodo, id_comision, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.inscriptos, NEW.anio_acad, NEW.id_materia, NEW.id_periodo, NEW.id_comision, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_inscriptos (inscriptos, anio_acad, id_materia, id_periodo, id_comision, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.inscriptos, OLD.anio_acad, OLD.id_materia, OLD.id_periodo, OLD.id_comision, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_inscriptos() OWNER TO postgres;

--
-- Name: sp_institucion(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_institucion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_institucion (id_institucion, nombre_institucion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_institucion, NEW.nombre_institucion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_institucion (id_institucion, nombre_institucion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_institucion, OLD.nombre_institucion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_institucion() OWNER TO postgres;

--
-- Name: sp_integrante_externo_pe(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_integrante_externo_pe() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_integrante_externo_pe (tipo_docum, nro_docum, id_pext, funcion_p, carga_horaria, desde, hasta, rescd, ad_honorem, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.tipo_docum, NEW.nro_docum, NEW.id_pext, NEW.funcion_p, NEW.carga_horaria, NEW.desde, NEW.hasta, NEW.rescd, NEW.ad_honorem, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_integrante_externo_pe (tipo_docum, nro_docum, id_pext, funcion_p, carga_horaria, desde, hasta, rescd, ad_honorem, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.tipo_docum, OLD.nro_docum, OLD.id_pext, OLD.funcion_p, OLD.carga_horaria, OLD.desde, OLD.hasta, OLD.rescd, OLD.ad_honorem, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_integrante_externo_pe() OWNER TO postgres;

--
-- Name: sp_integrante_externo_pi(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_integrante_externo_pi() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_integrante_externo_pi (tipo_docum, nro_docum, pinvest, cat_invest, identificador_personal, funcion_p, carga_horaria, desde, hasta, rescd, ad_honorem, cat_invest_conicet, id_institucion, check_inv, rescd_bm, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.tipo_docum, NEW.nro_docum, NEW.pinvest, NEW.cat_invest, NEW.identificador_personal, NEW.funcion_p, NEW.carga_horaria, NEW.desde, NEW.hasta, NEW.rescd, NEW.ad_honorem, NEW.cat_invest_conicet, NEW.id_institucion, NEW.check_inv, NEW.rescd_bm, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_integrante_externo_pi (tipo_docum, nro_docum, pinvest, cat_invest, identificador_personal, funcion_p, carga_horaria, desde, hasta, rescd, ad_honorem, cat_invest_conicet, id_institucion, check_inv, rescd_bm, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.tipo_docum, OLD.nro_docum, OLD.pinvest, OLD.cat_invest, OLD.identificador_personal, OLD.funcion_p, OLD.carga_horaria, OLD.desde, OLD.hasta, OLD.rescd, OLD.ad_honorem, OLD.cat_invest_conicet, OLD.id_institucion, OLD.check_inv, OLD.rescd_bm, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_integrante_externo_pi() OWNER TO postgres;

--
-- Name: sp_integrante_interno_pe(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_integrante_interno_pe() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_integrante_interno_pe (id_designacion, id_pext, funcion_p, carga_horaria, ua, desde, hasta, rescd, ad_honorem, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.id_pext, NEW.funcion_p, NEW.carga_horaria, NEW.ua, NEW.desde, NEW.hasta, NEW.rescd, NEW.ad_honorem, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_integrante_interno_pe (id_designacion, id_pext, funcion_p, carga_horaria, ua, desde, hasta, rescd, ad_honorem, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.id_pext, OLD.funcion_p, OLD.carga_horaria, OLD.ua, OLD.desde, OLD.hasta, OLD.rescd, OLD.ad_honorem, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_integrante_interno_pe() OWNER TO postgres;

--
-- Name: sp_integrante_interno_pi(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_integrante_interno_pi() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_integrante_interno_pi (id_designacion, pinvest, funcion_p, cat_investigador, identificador_personal, carga_horaria, ua, desde, hasta, rescd, ad_honorem, cat_invest_conicet, check_inv, resaval, hs_finan_otrafuente, rescd_bm, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.pinvest, NEW.funcion_p, NEW.cat_investigador, NEW.identificador_personal, NEW.carga_horaria, NEW.ua, NEW.desde, NEW.hasta, NEW.rescd, NEW.ad_honorem, NEW.cat_invest_conicet, NEW.check_inv, NEW.resaval, NEW.hs_finan_otrafuente, NEW.rescd_bm, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_integrante_interno_pi (id_designacion, pinvest, funcion_p, cat_investigador, identificador_personal, carga_horaria, ua, desde, hasta, rescd, ad_honorem, cat_invest_conicet, check_inv, resaval, hs_finan_otrafuente, rescd_bm, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.pinvest, OLD.funcion_p, OLD.cat_investigador, OLD.identificador_personal, OLD.carga_horaria, OLD.ua, OLD.desde, OLD.hasta, OLD.rescd, OLD.ad_honorem, OLD.cat_invest_conicet, OLD.check_inv, OLD.resaval, OLD.hs_finan_otrafuente, OLD.rescd_bm, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_integrante_interno_pi() OWNER TO postgres;

--
-- Name: sp_localidad(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_localidad() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_localidad (id, id_provincia, localidad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id, NEW.id_provincia, NEW.localidad, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_localidad (id, id_provincia, localidad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id, OLD.id_provincia, OLD.localidad, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_localidad() OWNER TO postgres;

--
-- Name: sp_macheo_categ(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_macheo_categ() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_macheo_categ (catsiu, catest, id_ded, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.catsiu, NEW.catest, NEW.id_ded, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_macheo_categ (catsiu, catest, id_ded, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.catsiu, OLD.catest, OLD.id_ded, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_macheo_categ() OWNER TO postgres;

--
-- Name: sp_materia(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_materia() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_materia (id_materia, id_plan, desc_materia, orden_materia, anio_segunplan, horas_semanales, periodo_dictado, periodo_dictado_real, id_departamento, id_area, id_orientacion, cod_siu, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_materia, NEW.id_plan, NEW.desc_materia, NEW.orden_materia, NEW.anio_segunplan, NEW.horas_semanales, NEW.periodo_dictado, NEW.periodo_dictado_real, NEW.id_departamento, NEW.id_area, NEW.id_orientacion, NEW.cod_siu, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_materia (id_materia, id_plan, desc_materia, orden_materia, anio_segunplan, horas_semanales, periodo_dictado, periodo_dictado_real, id_departamento, id_area, id_orientacion, cod_siu, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_materia, OLD.id_plan, OLD.desc_materia, OLD.orden_materia, OLD.anio_segunplan, OLD.horas_semanales, OLD.periodo_dictado, OLD.periodo_dictado_real, OLD.id_departamento, OLD.id_area, OLD.id_orientacion, OLD.cod_siu, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_materia() OWNER TO postgres;

--
-- Name: sp_mocovi_costo_categoria(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_mocovi_costo_categoria() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_mocovi_costo_categoria (id_costo_categoria, id_periodo, codigo_siu, costo_basico, costo_diario, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_costo_categoria, NEW.id_periodo, NEW.codigo_siu, NEW.costo_basico, NEW.costo_diario, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_mocovi_costo_categoria (id_costo_categoria, id_periodo, codigo_siu, costo_basico, costo_diario, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_costo_categoria, OLD.id_periodo, OLD.codigo_siu, OLD.costo_basico, OLD.costo_diario, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_mocovi_costo_categoria() OWNER TO postgres;

--
-- Name: sp_mocovi_credito(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_mocovi_credito() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_mocovi_credito (id_credito, id_periodo, id_unidad, id_escalafon, id_tipo_credito, descripcion, credito, id_programa, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_credito, NEW.id_periodo, NEW.id_unidad, NEW.id_escalafon, NEW.id_tipo_credito, NEW.descripcion, NEW.credito, NEW.id_programa, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_mocovi_credito (id_credito, id_periodo, id_unidad, id_escalafon, id_tipo_credito, descripcion, credito, id_programa, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_credito, OLD.id_periodo, OLD.id_unidad, OLD.id_escalafon, OLD.id_tipo_credito, OLD.descripcion, OLD.credito, OLD.id_programa, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_mocovi_credito() OWNER TO postgres;

--
-- Name: sp_mocovi_periodo_presupuestario(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_mocovi_periodo_presupuestario() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_mocovi_periodo_presupuestario (id_periodo, anio, fecha_inicio, fecha_fin, fecha_ultima_liquidacion, actual, id_liqui_ini, id_liqui_fin, id_liqui_1sac, id_liqui_2sac, presupuestando, activo_para_carga_presupuestando, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_periodo, NEW.anio, NEW.fecha_inicio, NEW.fecha_fin, NEW.fecha_ultima_liquidacion, NEW.actual, NEW.id_liqui_ini, NEW.id_liqui_fin, NEW.id_liqui_1sac, NEW.id_liqui_2sac, NEW.presupuestando, NEW.activo_para_carga_presupuestando, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_mocovi_periodo_presupuestario (id_periodo, anio, fecha_inicio, fecha_fin, fecha_ultima_liquidacion, actual, id_liqui_ini, id_liqui_fin, id_liqui_1sac, id_liqui_2sac, presupuestando, activo_para_carga_presupuestando, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_periodo, OLD.anio, OLD.fecha_inicio, OLD.fecha_fin, OLD.fecha_ultima_liquidacion, OLD.actual, OLD.id_liqui_ini, OLD.id_liqui_fin, OLD.id_liqui_1sac, OLD.id_liqui_2sac, OLD.presupuestando, OLD.activo_para_carga_presupuestando, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_mocovi_periodo_presupuestario() OWNER TO postgres;

--
-- Name: sp_mocovi_programa(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_mocovi_programa() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_mocovi_programa (id_programa, id_unidad, id_tipo_programa, nombre, area, sub_area, sub_sub_area, fuente, imputacion, programa, sub_programa, actividad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_programa, NEW.id_unidad, NEW.id_tipo_programa, NEW.nombre, NEW.area, NEW.sub_area, NEW.sub_sub_area, NEW.fuente, NEW.imputacion, NEW.programa, NEW.sub_programa, NEW.actividad, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_mocovi_programa (id_programa, id_unidad, id_tipo_programa, nombre, area, sub_area, sub_sub_area, fuente, imputacion, programa, sub_programa, actividad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_programa, OLD.id_unidad, OLD.id_tipo_programa, OLD.nombre, OLD.area, OLD.sub_area, OLD.sub_sub_area, OLD.fuente, OLD.imputacion, OLD.programa, OLD.sub_programa, OLD.actividad, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_mocovi_programa() OWNER TO postgres;

--
-- Name: sp_mocovi_tipo_credito(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_mocovi_tipo_credito() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_mocovi_tipo_credito (id_tipo_credito, tipo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_tipo_credito, NEW.tipo, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_mocovi_tipo_credito (id_tipo_credito, tipo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_tipo_credito, OLD.tipo, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_mocovi_tipo_credito() OWNER TO postgres;

--
-- Name: sp_mocovi_tipo_dependencia(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_mocovi_tipo_dependencia() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_mocovi_tipo_dependencia (id_tipo_dependencia, tipo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_tipo_dependencia, NEW.tipo, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_mocovi_tipo_dependencia (id_tipo_dependencia, tipo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_tipo_dependencia, OLD.tipo, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_mocovi_tipo_dependencia() OWNER TO postgres;

--
-- Name: sp_mocovi_tipo_programa(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_mocovi_tipo_programa() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_mocovi_tipo_programa (id_tipo_programa, tipo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_tipo_programa, NEW.tipo, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_mocovi_tipo_programa (id_tipo_programa, tipo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_tipo_programa, OLD.tipo, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_mocovi_tipo_programa() OWNER TO postgres;

--
-- Name: sp_modulo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_modulo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_modulo (id_modulo, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_modulo, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_modulo (id_modulo, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_modulo, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_modulo() OWNER TO postgres;

--
-- Name: sp_montos_viatico(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_montos_viatico() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_montos_viatico (fecha, monto, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.fecha, NEW.monto, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_montos_viatico (fecha, monto, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.fecha, OLD.monto, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_montos_viatico() OWNER TO postgres;

--
-- Name: sp_norma(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_norma() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_norma (id_norma, nro_norma, tipo_norma, emite_norma, fecha, link, palabras_clave, uni_acad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_norma, NEW.nro_norma, NEW.tipo_norma, NEW.emite_norma, NEW.fecha, NEW.link, NEW.palabras_clave, NEW.uni_acad, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_norma (id_norma, nro_norma, tipo_norma, emite_norma, fecha, link, palabras_clave, uni_acad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_norma, OLD.nro_norma, OLD.tipo_norma, OLD.emite_norma, OLD.fecha, OLD.link, OLD.palabras_clave, OLD.uni_acad, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_norma() OWNER TO postgres;

--
-- Name: sp_norma_desig(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_norma_desig() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_norma_desig (id_norma, id_designacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_norma, NEW.id_designacion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_norma_desig (id_norma, id_designacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_norma, OLD.id_designacion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_norma_desig() OWNER TO postgres;

--
-- Name: sp_novedad(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_novedad() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_novedad (id_novedad, tipo_nov, desde, hasta, id_designacion, tipo_norma, tipo_emite, norma_legal, observaciones, nro_tab10, sub_tipo, porcen, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_novedad, NEW.tipo_nov, NEW.desde, NEW.hasta, NEW.id_designacion, NEW.tipo_norma, NEW.tipo_emite, NEW.norma_legal, NEW.observaciones, NEW.nro_tab10, NEW.sub_tipo, NEW.porcen, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_novedad (id_novedad, tipo_nov, desde, hasta, id_designacion, tipo_norma, tipo_emite, norma_legal, observaciones, nro_tab10, sub_tipo, porcen, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_novedad, OLD.tipo_nov, OLD.desde, OLD.hasta, OLD.id_designacion, OLD.tipo_norma, OLD.tipo_emite, OLD.norma_legal, OLD.observaciones, OLD.nro_tab10, OLD.sub_tipo, OLD.porcen, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_novedad() OWNER TO postgres;

--
-- Name: sp_objetivo_se(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_objetivo_se() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_objetivo_se (id_obj, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_obj, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_objetivo_se (id_obj, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_obj, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_objetivo_se() OWNER TO postgres;

--
-- Name: sp_orientacion(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_orientacion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_orientacion (idorient, idarea, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.idorient, NEW.idarea, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_orientacion (idorient, idarea, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.idorient, OLD.idarea, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_orientacion() OWNER TO postgres;

--
-- Name: sp_pais(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_pais() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_pais (codigo_pais, nombre, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.codigo_pais, NEW.nombre, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_pais (codigo_pais, nombre, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.codigo_pais, OLD.nombre, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_pais() OWNER TO postgres;

--
-- Name: sp_periodo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_periodo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_periodo (id_periodo, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_periodo, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_periodo (id_periodo, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_periodo, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_periodo() OWNER TO postgres;

--
-- Name: sp_persona(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_persona() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_persona (apellido, nombre, nro_tabla, tipo_docum, nro_docum, tipo_sexo, pais_nacim, pcia_nacim, fec_nacim, titulog, titulop, docum_extran, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.apellido, NEW.nombre, NEW.nro_tabla, NEW.tipo_docum, NEW.nro_docum, NEW.tipo_sexo, NEW.pais_nacim, NEW.pcia_nacim, NEW.fec_nacim, NEW.titulog, NEW.titulop, NEW.docum_extran, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_persona (apellido, nombre, nro_tabla, tipo_docum, nro_docum, tipo_sexo, pais_nacim, pcia_nacim, fec_nacim, titulog, titulop, docum_extran, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.apellido, OLD.nombre, OLD.nro_tabla, OLD.tipo_docum, OLD.nro_docum, OLD.tipo_sexo, OLD.pais_nacim, OLD.pcia_nacim, OLD.fec_nacim, OLD.titulog, OLD.titulop, OLD.docum_extran, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_persona() OWNER TO postgres;

--
-- Name: sp_pextension(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_pextension() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_pextension (id_pext, codigo, denominacion, nro_resol, fecha_resol, uni_acad, fec_desde, fec_hasta, nro_ord_cs, res_rect, expediente, duracion, palabras_clave, objetivo, estado, financiacion, monto, fecha_rendicion, rendicion_monto, fecha_prorroga1, fecha_prorroga2, observacion, estado_informe_a, estado_informe_f, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_pext, NEW.codigo, NEW.denominacion, NEW.nro_resol, NEW.fecha_resol, NEW.uni_acad, NEW.fec_desde, NEW.fec_hasta, NEW.nro_ord_cs, NEW.res_rect, NEW.expediente, NEW.duracion, NEW.palabras_clave, NEW.objetivo, NEW.estado, NEW.financiacion, NEW.monto, NEW.fecha_rendicion, NEW.rendicion_monto, NEW.fecha_prorroga1, NEW.fecha_prorroga2, NEW.observacion, NEW.estado_informe_a, NEW.estado_informe_f, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_pextension (id_pext, codigo, denominacion, nro_resol, fecha_resol, uni_acad, fec_desde, fec_hasta, nro_ord_cs, res_rect, expediente, duracion, palabras_clave, objetivo, estado, financiacion, monto, fecha_rendicion, rendicion_monto, fecha_prorroga1, fecha_prorroga2, observacion, estado_informe_a, estado_informe_f, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_pext, OLD.codigo, OLD.denominacion, OLD.nro_resol, OLD.fecha_resol, OLD.uni_acad, OLD.fec_desde, OLD.fec_hasta, OLD.nro_ord_cs, OLD.res_rect, OLD.expediente, OLD.duracion, OLD.palabras_clave, OLD.objetivo, OLD.estado, OLD.financiacion, OLD.monto, OLD.fecha_rendicion, OLD.rendicion_monto, OLD.fecha_prorroga1, OLD.fecha_prorroga2, OLD.observacion, OLD.estado_informe_a, OLD.estado_informe_f, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_pextension() OWNER TO postgres;

--
-- Name: sp_pinvestigacion(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_pinvestigacion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_pinvestigacion (id_pinv, codigo, denominacion, nro_resol, fec_resol, uni_acad, fec_desde, fec_hasta, duracion, objetivo, nro_ord_cs, fecha_ord_cs, es_programa, tipo, observacion, estado, disp_asent, id_respon_sub, palabras_clave, resumen, nro_resol_baja, fec_baja, observacionscyt, id_disciplina, id_obj, tdi, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_pinv, NEW.codigo, NEW.denominacion, NEW.nro_resol, NEW.fec_resol, NEW.uni_acad, NEW.fec_desde, NEW.fec_hasta, NEW.duracion, NEW.objetivo, NEW.nro_ord_cs, NEW.fecha_ord_cs, NEW.es_programa, NEW.tipo, NEW.observacion, NEW.estado, NEW.disp_asent, NEW.id_respon_sub, NEW.palabras_clave, NEW.resumen, NEW.nro_resol_baja, NEW.fec_baja, NEW.observacionscyt, NEW.id_disciplina, NEW.id_obj, NEW.tdi, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_pinvestigacion (id_pinv, codigo, denominacion, nro_resol, fec_resol, uni_acad, fec_desde, fec_hasta, duracion, objetivo, nro_ord_cs, fecha_ord_cs, es_programa, tipo, observacion, estado, disp_asent, id_respon_sub, palabras_clave, resumen, nro_resol_baja, fec_baja, observacionscyt, id_disciplina, id_obj, tdi, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_pinv, OLD.codigo, OLD.denominacion, OLD.nro_resol, OLD.fec_resol, OLD.uni_acad, OLD.fec_desde, OLD.fec_hasta, OLD.duracion, OLD.objetivo, OLD.nro_ord_cs, OLD.fecha_ord_cs, OLD.es_programa, OLD.tipo, OLD.observacion, OLD.estado, OLD.disp_asent, OLD.id_respon_sub, OLD.palabras_clave, OLD.resumen, OLD.nro_resol_baja, OLD.fec_baja, OLD.observacionscyt, OLD.id_disciplina, OLD.id_obj, OLD.tdi, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_pinvestigacion() OWNER TO postgres;

--
-- Name: sp_plan_estudio(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_plan_estudio() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_plan_estudio (id_plan, cod_carrera, desc_carrera, titulo, uni_acad, ordenanza, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_plan, NEW.cod_carrera, NEW.desc_carrera, NEW.titulo, NEW.uni_acad, NEW.ordenanza, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_plan_estudio (id_plan, cod_carrera, desc_carrera, titulo, uni_acad, ordenanza, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_plan, OLD.cod_carrera, OLD.desc_carrera, OLD.titulo, OLD.uni_acad, OLD.ordenanza, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_plan_estudio() OWNER TO postgres;

--
-- Name: sp_porcentaje_lsgh(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_porcentaje_lsgh() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_porcentaje_lsgh (porcen, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.porcen, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_porcentaje_lsgh (porcen, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.porcen, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_porcentaje_lsgh() OWNER TO postgres;

--
-- Name: sp_programa(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_programa() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_programa (id_designacion, id_materia, modulo, anio, id_estado, fecha, link, observacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.id_materia, NEW.modulo, NEW.anio, NEW.id_estado, NEW.fecha, NEW.link, NEW.observacion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_programa (id_designacion, id_materia, modulo, anio, id_estado, fecha, link, observacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.id_materia, OLD.modulo, OLD.anio, OLD.id_estado, OLD.fecha, OLD.link, OLD.observacion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_programa() OWNER TO postgres;

--
-- Name: sp_provincia(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_provincia() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_provincia (descripcion_pcia, cod_pais, codigo_pcia, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.descripcion_pcia, NEW.cod_pais, NEW.codigo_pcia, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_provincia (descripcion_pcia, cod_pais, codigo_pcia, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.descripcion_pcia, OLD.cod_pais, OLD.codigo_pcia, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_provincia() OWNER TO postgres;

--
-- Name: sp_reserva(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_reserva() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_reserva (id_reserva, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_reserva, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_reserva (id_reserva, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_reserva, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_reserva() OWNER TO postgres;

--
-- Name: sp_reserva_ocupada_por(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_reserva_ocupada_por() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_reserva_ocupada_por (id_designacion, id_reserva, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_designacion, NEW.id_reserva, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_reserva_ocupada_por (id_designacion, id_reserva, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_designacion, OLD.id_reserva, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_reserva_ocupada_por() OWNER TO postgres;

--
-- Name: sp_solicitud(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_solicitud() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_solicitud (observaciones, id_orientacion, id_area, id_departamento, uni_acad, carac, dedic, cat_estat, cat_mapuche, hasta, desde, anio_acad, nro_cargo, id_docente, materias, justificacion_depto, justificacion_academica, codigo_area, codigo_orientacion, id_solicitud, periodo, docente_nuevo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.observaciones, NEW.id_orientacion, NEW.id_area, NEW.id_departamento, NEW.uni_acad, NEW.carac, NEW.dedic, NEW.cat_estat, NEW.cat_mapuche, NEW.hasta, NEW.desde, NEW.anio_acad, NEW.nro_cargo, NEW.id_docente, NEW.materias, NEW.justificacion_depto, NEW.justificacion_academica, NEW.codigo_area, NEW.codigo_orientacion, NEW.id_solicitud, NEW.periodo, NEW.docente_nuevo, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_solicitud (observaciones, id_orientacion, id_area, id_departamento, uni_acad, carac, dedic, cat_estat, cat_mapuche, hasta, desde, anio_acad, nro_cargo, id_docente, materias, justificacion_depto, justificacion_academica, codigo_area, codigo_orientacion, id_solicitud, periodo, docente_nuevo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.observaciones, OLD.id_orientacion, OLD.id_area, OLD.id_departamento, OLD.uni_acad, OLD.carac, OLD.dedic, OLD.cat_estat, OLD.cat_mapuche, OLD.hasta, OLD.desde, OLD.anio_acad, OLD.nro_cargo, OLD.id_docente, OLD.materias, OLD.justificacion_depto, OLD.justificacion_academica, OLD.codigo_area, OLD.codigo_orientacion, OLD.id_solicitud, OLD.periodo, OLD.docente_nuevo, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_solicitud() OWNER TO postgres;

--
-- Name: sp_subproyecto(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_subproyecto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_subproyecto (id_programa, id_proyecto, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_programa, NEW.id_proyecto, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_subproyecto (id_programa, id_proyecto, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_programa, OLD.id_proyecto, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_subproyecto() OWNER TO postgres;

--
-- Name: sp_subsidio(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_subsidio() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_subsidio (numero, id_proyecto, fecha_pago, observaciones, monto, resolucion, expediente, fecha_rendicion, estado, nota, memo, id_respon_sub, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.numero, NEW.id_proyecto, NEW.fecha_pago, NEW.observaciones, NEW.monto, NEW.resolucion, NEW.expediente, NEW.fecha_rendicion, NEW.estado, NEW.nota, NEW.memo, NEW.id_respon_sub, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_subsidio (numero, id_proyecto, fecha_pago, observaciones, monto, resolucion, expediente, fecha_rendicion, estado, nota, memo, id_respon_sub, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.numero, OLD.id_proyecto, OLD.fecha_pago, OLD.observaciones, OLD.monto, OLD.resolucion, OLD.expediente, OLD.fecha_rendicion, OLD.estado, OLD.nota, OLD.memo, OLD.id_respon_sub, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_subsidio() OWNER TO postgres;

--
-- Name: sp_suplente(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_suplente() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_suplente (id_desig_suplente, id_desig, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_desig_suplente, NEW.id_desig, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_suplente (id_desig_suplente, id_desig, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_desig_suplente, OLD.id_desig, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_suplente() OWNER TO postgres;

--
-- Name: sp_tiene_estimulo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_tiene_estimulo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_tiene_estimulo (id_proyecto, resolucion, expediente, monto, estado, fecha_rendicion, memo, nota, id_respon, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_proyecto, NEW.resolucion, NEW.expediente, NEW.monto, NEW.estado, NEW.fecha_rendicion, NEW.memo, NEW.nota, NEW.id_respon, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_tiene_estimulo (id_proyecto, resolucion, expediente, monto, estado, fecha_rendicion, memo, nota, id_respon, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_proyecto, OLD.resolucion, OLD.expediente, OLD.monto, OLD.estado, OLD.fecha_rendicion, OLD.memo, OLD.nota, OLD.id_respon, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_tiene_estimulo() OWNER TO postgres;

--
-- Name: sp_tipo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_tipo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_tipo (nro_tabla, desc_abrev, desc_item, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.nro_tabla, NEW.desc_abrev, NEW.desc_item, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_tipo (nro_tabla, desc_abrev, desc_item, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.nro_tabla, OLD.desc_abrev, OLD.desc_item, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_tipo() OWNER TO postgres;

--
-- Name: sp_tipo_de_inv(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_tipo_de_inv() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_tipo_de_inv (id, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_tipo_de_inv (id, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_tipo_de_inv() OWNER TO postgres;

--
-- Name: sp_tipo_designacion(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_tipo_designacion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_tipo_designacion (id, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_tipo_designacion (id, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_tipo_designacion() OWNER TO postgres;

--
-- Name: sp_tipo_emite(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_tipo_emite() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_tipo_emite (cod_emite, quien_emite_norma, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.cod_emite, NEW.quien_emite_norma, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_tipo_emite (cod_emite, quien_emite_norma, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.cod_emite, OLD.quien_emite_norma, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_tipo_emite() OWNER TO postgres;

--
-- Name: sp_tipo_norma_exp(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_tipo_norma_exp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_tipo_norma_exp (cod_tipo, nombre_tipo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.cod_tipo, NEW.nombre_tipo, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_tipo_norma_exp (cod_tipo, nombre_tipo, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.cod_tipo, OLD.nombre_tipo, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_tipo_norma_exp() OWNER TO postgres;

--
-- Name: sp_tipo_novedad(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_tipo_novedad() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_tipo_novedad (id_tipo, desc_corta, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_tipo, NEW.desc_corta, NEW.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_tipo_novedad (id_tipo, desc_corta, descripcion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_tipo, OLD.desc_corta, OLD.descripcion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_tipo_novedad() OWNER TO postgres;

--
-- Name: sp_titulo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_titulo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_titulo (codc_titul, nro_tab3, codc_nivel, desc_titul, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.codc_titul, NEW.nro_tab3, NEW.codc_nivel, NEW.desc_titul, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_titulo (codc_titul, nro_tab3, codc_nivel, desc_titul, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.codc_titul, OLD.nro_tab3, OLD.codc_nivel, OLD.desc_titul, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_titulo() OWNER TO postgres;

--
-- Name: sp_titulos_docente(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_titulos_docente() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_titulos_docente (id_docente, codc_titul, fec_emisi, fec_finalizacion, codc_entot, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_docente, NEW.codc_titul, NEW.fec_emisi, NEW.fec_finalizacion, NEW.codc_entot, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_titulos_docente (id_docente, codc_titul, fec_emisi, fec_finalizacion, codc_entot, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_docente, OLD.codc_titul, OLD.fec_emisi, OLD.fec_finalizacion, OLD.codc_entot, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_titulos_docente() OWNER TO postgres;

--
-- Name: sp_tutoria(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_tutoria() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_tutoria (id_tutoria, descripcion, uni_acad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_tutoria, NEW.descripcion, NEW.uni_acad, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_tutoria (id_tutoria, descripcion, uni_acad, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_tutoria, OLD.descripcion, OLD.uni_acad, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_tutoria() OWNER TO postgres;

--
-- Name: sp_unidad_acad(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_unidad_acad() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_unidad_acad (sigla, descripcion, nro_tab6, cod_regional, id_tipo_dependencia, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.sigla, NEW.descripcion, NEW.nro_tab6, NEW.cod_regional, NEW.id_tipo_dependencia, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_unidad_acad (sigla, descripcion, nro_tab6, cod_regional, id_tipo_dependencia, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.sigla, OLD.descripcion, OLD.nro_tab6, OLD.cod_regional, OLD.id_tipo_dependencia, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_unidad_acad() OWNER TO postgres;

--
-- Name: sp_viatico(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_viatico() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_viatico (id_viatico, id_proyecto, nro_tab, tipo, fecha_solicitud, fecha_pago, expediente_pago, memo_solicitud, memo_certificados, es_nacional, cant_dias, fecha_present_certif, observaciones, estado, origen, destino, fecha_salida, fecha_regreso, nombre_actividad, nro_tab2, medio_transporte, nro_docum_desti, monto, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.id_viatico, NEW.id_proyecto, NEW.nro_tab, NEW.tipo, NEW.fecha_solicitud, NEW.fecha_pago, NEW.expediente_pago, NEW.memo_solicitud, NEW.memo_certificados, NEW.es_nacional, NEW.cant_dias, NEW.fecha_present_certif, NEW.observaciones, NEW.estado, NEW.origen, NEW.destino, NEW.fecha_salida, NEW.fecha_regreso, NEW.nombre_actividad, NEW.nro_tab2, NEW.medio_transporte, NEW.nro_docum_desti, NEW.monto, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_viatico (id_viatico, id_proyecto, nro_tab, tipo, fecha_solicitud, fecha_pago, expediente_pago, memo_solicitud, memo_certificados, es_nacional, cant_dias, fecha_present_certif, observaciones, estado, origen, destino, fecha_salida, fecha_regreso, nombre_actividad, nro_tab2, medio_transporte, nro_docum_desti, monto, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.id_viatico, OLD.id_proyecto, OLD.nro_tab, OLD.tipo, OLD.fecha_solicitud, OLD.fecha_pago, OLD.expediente_pago, OLD.memo_solicitud, OLD.memo_certificados, OLD.es_nacional, OLD.cant_dias, OLD.fecha_present_certif, OLD.observaciones, OLD.estado, OLD.origen, OLD.destino, OLD.fecha_salida, OLD.fecha_regreso, OLD.nombre_actividad, OLD.nro_tab2, OLD.medio_transporte, OLD.nro_docum_desti, OLD.monto, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_viatico() OWNER TO postgres;

--
-- Name: sp_vigentes(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_vigentes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_vigentes (apellido, nombre, legajo, fuente, ua, cargo, categoria, desde, hasta, continuidad, marcado, dias, categoria_max, dias_cat_max, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.apellido, NEW.nombre, NEW.legajo, NEW.fuente, NEW.ua, NEW.cargo, NEW.categoria, NEW.desde, NEW.hasta, NEW.continuidad, NEW.marcado, NEW.dias, NEW.categoria_max, NEW.dias_cat_max, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_vigentes (apellido, nombre, legajo, fuente, ua, cargo, categoria, desde, hasta, continuidad, marcado, dias, categoria_max, dias_cat_max, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.apellido, OLD.nombre, OLD.legajo, OLD.fuente, OLD.ua, OLD.cargo, OLD.categoria, OLD.desde, OLD.hasta, OLD.continuidad, OLD.marcado, OLD.dias, OLD.categoria_max, OLD.dias_cat_max, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_vigentes() OWNER TO postgres;

--
-- Name: sp_vinculo(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_vinculo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_vinculo (desig, vinc, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.desig, NEW.vinc, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_vinculo (desig, vinc, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.desig, OLD.vinc, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_vinculo() OWNER TO postgres;

--
-- Name: sp_winsip(); Type: FUNCTION; Schema: public_auditoria; Owner: postgres
--

CREATE FUNCTION public_auditoria.sp_winsip() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
				DECLARE
					schema_temp varchar;
					rtabla_usr RECORD;
					rusuario RECORD;
					vusuario VARCHAR(60);
					voperacion varchar;
					vid_solicitud integer;
					vestampilla timestamp;
				BEGIN
					vestampilla := current_timestamp;
					SELECT INTO schema_temp public.recuperar_schema_temp();
					SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
					IF FOUND THEN
						SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
						IF FOUND THEN
							vusuario := rusuario.usuario;
							vid_solicitud := rusuario.id_solicitud;
						ELSE
							vusuario := user;
							vid_solicitud := 0;
						END IF;
					ELSE
						vusuario := user;
					END IF;
					IF (TG_OP = 'INSERT') OR (TG_OP = 'UPDATE') THEN
						IF (TG_OP = 'INSERT') THEN
							voperacion := 'I';  
						ELSE
							voperacion := 'U';
						END IF;
				INSERT INTO public_auditoria.logs_winsip (periodo, id_proyecto, fecha_presentacion, resultado, fecha_aprobacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (NEW.periodo, NEW.id_proyecto, NEW.fecha_presentacion, NEW.resultado, NEW.fecha_aprobacion, vusuario, vestampilla, voperacion, vid_solicitud);
					ELSIF TG_OP = 'DELETE' THEN
						voperacion := 'D';
						INSERT INTO public_auditoria.logs_winsip (periodo, id_proyecto, fecha_presentacion, resultado, fecha_aprobacion, auditoria_usuario, auditoria_fecha, auditoria_operacion, auditoria_id_solicitud) VALUES (OLD.periodo, OLD.id_proyecto, OLD.fecha_presentacion, OLD.resultado, OLD.fecha_aprobacion, vusuario, vestampilla, voperacion, vid_solicitud);
					END IF;
					RETURN NULL;
				END;
			$$;


ALTER FUNCTION public_auditoria.sp_winsip() OWNER TO postgres;

--
-- Name: dbrnd; Type: FOREIGN DATA WRAPPER; Schema: -; Owner: postgres
--

CREATE FOREIGN DATA WRAPPER dbrnd VALIDATOR postgresql_fdw_validator;


ALTER FOREIGN DATA WRAPPER dbrnd OWNER TO postgres;

--
-- Name: postgres; Type: FOREIGN DATA WRAPPER; Schema: -; Owner: postgres
--

CREATE FOREIGN DATA WRAPPER postgres VALIDATOR postgresql_fdw_validator;


ALTER FOREIGN DATA WRAPPER postgres OWNER TO postgres;

--
-- Name: demodbrnd; Type: SERVER; Schema: -; Owner: postgres
--

CREATE SERVER demodbrnd FOREIGN DATA WRAPPER dbrnd OPTIONS (
    dbname 'designa',
    hostaddr 'localhost'
);


ALTER SERVER demodbrnd OWNER TO postgres;

--
-- Name: demopostgres; Type: SERVER; Schema: -; Owner: postgres
--

CREATE SERVER demopostgres FOREIGN DATA WRAPPER postgres OPTIONS (
    dbname 'designa',
    hostaddr 'localhost'
);


ALTER SERVER demopostgres OWNER TO postgres;

--
-- Name: USER MAPPING postgres SERVER demopostgres; Type: USER MAPPING; Schema: -; Owner: postgres
--

CREATE USER MAPPING FOR postgres SERVER demopostgres OPTIONS (
    password 'postgres',
    "user" 'postgres'
);


--
-- Name: area_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.area_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.area_id_seq OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: area; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.area (
    idarea integer DEFAULT nextval('public.area_id_seq'::regclass) NOT NULL,
    iddepto integer NOT NULL,
    descripcion character varying DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.area OWNER TO postgres;

--
-- Name: bases_convocatoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bases_convocatoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bases_convocatoria_seq OWNER TO postgres;

--
-- Name: bases_convocatoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bases_convocatoria (
    id_bases integer DEFAULT nextval('public.bases_convocatoria_seq'::regclass) NOT NULL,
    convocatoria character varying NOT NULL,
    objetivo character varying NOT NULL,
    eje_tematico character varying NOT NULL,
    destinatarios character varying NOT NULL,
    integrantes character varying NOT NULL,
    monto character varying NOT NULL,
    duracion character varying NOT NULL,
    fecha character varying NOT NULL,
    evaluacion character varying NOT NULL,
    adjudicacion character varying NOT NULL,
    consulta character varying NOT NULL,
    bases_titulo character varying NOT NULL,
    ordenanza character varying NOT NULL,
    tipo_convocatoria character(1)
);


ALTER TABLE public.bases_convocatoria OWNER TO postgres;

--
-- Name: caracter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.caracter (
    id_car character(1) NOT NULL,
    descripcion character(20) DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.caracter OWNER TO postgres;

--
-- Name: dedicacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dedicacion (
    id_ded integer NOT NULL,
    descripcion character(20) DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.dedicacion OWNER TO postgres;

--
-- Name: dedicacion_incentivo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dedicacion_incentivo (
    id_di integer NOT NULL,
    descripcion character(30) DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.dedicacion_incentivo OWNER TO postgres;

--
-- Name: dedicacion_incentivo_id_di_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dedicacion_incentivo_id_di_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dedicacion_incentivo_id_di_seq OWNER TO postgres;

--
-- Name: dedicacion_incentivo_id_di_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dedicacion_incentivo_id_di_seq OWNED BY public.dedicacion_incentivo.id_di;


--
-- Name: departamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departamento_id_seq OWNER TO postgres;

--
-- Name: departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamento (
    iddepto integer DEFAULT nextval('public.departamento_id_seq'::regclass) NOT NULL,
    idunidad_academica character(5) NOT NULL,
    descripcion character varying DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.departamento OWNER TO postgres;

--
-- Name: designacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.designacion (
    id_designacion integer NOT NULL,
    id_docente integer,
    nro_cargo integer,
    anio_acad integer,
    desde date NOT NULL,
    hasta date,
    cat_mapuche character(4),
    cat_estat character(6),
    dedic integer NOT NULL,
    carac character(1) NOT NULL,
    uni_acad character(5) NOT NULL,
    id_departamento integer,
    id_area integer,
    id_orientacion integer,
    id_norma integer,
    id_expediente integer,
    tipo_incentivo integer,
    dedi_incen integer,
    cic_con character(3),
    cargo_gestion character(4),
    ord_gestion character(10),
    emite_cargo_gestion character(4),
    nro_gestion character(10),
    observaciones character varying,
    check_presup integer,
    nro_540 integer,
    concursado integer,
    check_academica integer,
    tipo_desig integer,
    id_reserva integer,
    estado character(1),
    id_norma_cs integer,
    por_permuta integer
);


ALTER TABLE public.designacion OWNER TO postgres;

--
-- Name: COLUMN designacion.id_norma; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.id_norma IS 'Norma del Consejo Directivo';


--
-- Name: COLUMN designacion.tipo_incentivo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.tipo_incentivo IS 'Tipo de incentivo';


--
-- Name: COLUMN designacion.dedi_incen; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.dedi_incen IS 'Dedicación de incentivo';


--
-- Name: COLUMN designacion.cic_con; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.cic_con IS 'CIC / CONICET';


--
-- Name: COLUMN designacion.id_norma_cs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.id_norma_cs IS 'Norma del Consejo Superior';


--
-- Name: designacion_id_designacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.designacion_id_designacion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.designacion_id_designacion_seq OWNER TO postgres;

--
-- Name: designacion_id_designacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.designacion_id_designacion_seq OWNED BY public.designacion.id_designacion;


--
-- Name: director_dpto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.director_dpto (
    id_docente integer NOT NULL,
    iddepto integer NOT NULL,
    desde date NOT NULL,
    hasta date,
    resol character(9)
);


ALTER TABLE public.director_dpto OWNER TO postgres;

--
-- Name: docente_id_docente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.docente_id_docente_seq
    START WITH 295
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.docente_id_docente_seq OWNER TO postgres;

--
-- Name: docente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.docente (
    id_docente integer DEFAULT nextval('public.docente_id_docente_seq'::regclass) NOT NULL,
    legajo integer,
    apellido character varying,
    nombre character varying,
    nro_tabla integer,
    tipo_docum character(4),
    nro_docum integer,
    fec_nacim date,
    nro_cuil1 integer,
    nro_cuil integer,
    nro_cuil2 integer,
    tipo_sexo character(1),
    pais_nacim character(2),
    porcdedicdocente double precision,
    porcdedicinvestig double precision,
    porcdedicagestion double precision,
    porcdedicaextens double precision,
    pcia_nacim integer,
    fec_ingreso date,
    correo_institucional character(60),
    correo_personal character(60),
    situacion_docente character varying,
    telefono integer
);


ALTER TABLE public.docente OWNER TO postgres;

--
-- Name: estado_pe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado_pe (
    id_estado character(1) NOT NULL,
    descripcion character(30)
);


ALTER TABLE public.estado_pe OWNER TO postgres;

--
-- Name: estado_pe_descripcion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_pe_descripcion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estado_pe_descripcion_seq OWNER TO postgres;

--
-- Name: estado_pe_descripcion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_pe_descripcion_seq OWNED BY public.estado_pe.descripcion;


--
-- Name: funcion_extension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcion_extension (
    id_extension character(5) NOT NULL,
    descripcion character varying(70)
);


ALTER TABLE public.funcion_extension OWNER TO postgres;

--
-- Name: incentivo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incentivo (
    id_inc integer NOT NULL,
    descripcion character(20) DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.incentivo OWNER TO postgres;

--
-- Name: incentivo_id_inc_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.incentivo_id_inc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.incentivo_id_inc_seq OWNER TO postgres;

--
-- Name: incentivo_id_inc_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.incentivo_id_inc_seq OWNED BY public.incentivo.id_inc;


--
-- Name: integrante_externo_pe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrante_externo_pe (
    tipo_docum character(4) NOT NULL,
    nro_docum integer NOT NULL,
    id_pext integer NOT NULL,
    funcion_p character(5),
    carga_horaria integer,
    desde date NOT NULL,
    hasta date,
    rescd character(10),
    ad_honorem integer,
    tipo character varying
);


ALTER TABLE public.integrante_externo_pe OWNER TO postgres;

--
-- Name: integrante_interno_pe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrante_interno_pe (
    id_designacion integer NOT NULL,
    id_pext integer NOT NULL,
    funcion_p character(5),
    carga_horaria integer,
    ua character(5),
    desde date NOT NULL,
    hasta date,
    rescd character(10),
    ad_honorem integer,
    tipo character varying
);


ALTER TABLE public.integrante_interno_pe OWNER TO postgres;

--
-- Name: localidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.localidad (
    id integer NOT NULL,
    id_provincia integer NOT NULL,
    localidad character varying(255) NOT NULL
);


ALTER TABLE public.localidad OWNER TO postgres;

--
-- Name: norma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.norma (
    id_norma integer NOT NULL,
    nro_norma integer,
    tipo_norma character(5),
    emite_norma character(4),
    fecha date,
    pdf bytea,
    link character varying,
    palabras_clave text,
    uni_acad character(4)
);


ALTER TABLE public.norma OWNER TO postgres;

--
-- Name: norma_desig; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.norma_desig (
    id_norma integer NOT NULL,
    id_designacion integer NOT NULL
);


ALTER TABLE public.norma_desig OWNER TO postgres;

--
-- Name: norma_id_norma_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.norma_id_norma_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.norma_id_norma_seq OWNER TO postgres;

--
-- Name: norma_id_norma_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.norma_id_norma_seq OWNED BY public.norma.id_norma;


--
-- Name: novedad_id_norma_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.novedad_id_norma_seq
    START WITH 234
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.novedad_id_norma_seq OWNER TO postgres;

--
-- Name: organizaciones_participantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizaciones_participantes (
    nombre character varying,
    telefono integer,
    email character varying,
    referencia_vinculacion_inst character varying,
    id_pext integer NOT NULL,
    id_tipo_organizacion integer NOT NULL,
    id_organizacion integer NOT NULL,
    id_localidad integer
);


ALTER TABLE public.organizaciones_participantes OWNER TO postgres;

--
-- Name: organizaciones_participantes_email_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizaciones_participantes_email_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizaciones_participantes_email_seq OWNER TO postgres;

--
-- Name: organizaciones_participantes_email_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizaciones_participantes_email_seq OWNED BY public.organizaciones_participantes.email;


--
-- Name: organizaciones_participantes_id_organizacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizaciones_participantes_id_organizacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizaciones_participantes_id_organizacion_seq OWNER TO postgres;

--
-- Name: organizaciones_participantes_id_organizacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizaciones_participantes_id_organizacion_seq OWNED BY public.organizaciones_participantes.id_organizacion;


--
-- Name: organizaciones_participantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizaciones_participantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizaciones_participantes_id_seq OWNER TO postgres;

--
-- Name: organizaciones_participantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizaciones_participantes_id_seq OWNED BY public.organizaciones_participantes.id_pext;


--
-- Name: orientacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orientacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orientacion_id_seq OWNER TO postgres;

--
-- Name: orientacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orientacion (
    idorient integer DEFAULT nextval('public.orientacion_id_seq'::regclass) NOT NULL,
    idarea integer NOT NULL,
    descripcion character varying DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.orientacion OWNER TO postgres;

--
-- Name: pais; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pais (
    codigo_pais character(2) NOT NULL,
    nombre character varying(40)
);


ALTER TABLE public.pais OWNER TO postgres;

--
-- Name: persona; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persona (
    apellido character varying,
    nombre character varying,
    nro_tabla integer,
    tipo_docum character(4) NOT NULL,
    nro_docum integer NOT NULL,
    tipo_sexo character(1),
    pais_nacim character(2),
    pcia_nacim integer,
    fec_nacim date,
    titulog character(4),
    titulop character(4),
    docum_extran character(15),
    telefono integer,
    mail character varying
);


ALTER TABLE public.persona OWNER TO postgres;

--
-- Name: pextension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pextension (
    id_pext integer NOT NULL,
    codigo character varying,
    denominacion character varying,
    nro_resol character(20),
    fecha_resol date,
    uni_acad character(5),
    fec_desde date,
    fec_hasta date,
    nro_ord_cs character(20),
    res_rect character(20),
    expediente character(12),
    duracion integer,
    palabras_clave character(120),
    objetivo character varying,
    estado character(1),
    financiacion boolean,
    monto numeric,
    fecha_rendicion date,
    rendicion_monto double precision,
    fecha_prorroga1 date,
    fecha_prorroga2 date,
    observacion character varying,
    estado_informe_a character(1),
    estado_informe_f character(1),
    eje_tematico character(20),
    descripcion_situacion character(200),
    caracterizacion_poblacion character(150),
    localizacion_geo character(20),
    antecedente_participacion character(200),
    importancia_necesidad character(200),
    id_bases integer,
    responsable_carga character varying(30)
);


ALTER TABLE public.pextension OWNER TO postgres;

--
-- Name: pextension_id_pext_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pextension_id_pext_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pextension_id_pext_seq OWNER TO postgres;

--
-- Name: pextension_id_pext_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pextension_id_pext_seq OWNED BY public.pextension.id_pext;


--
-- Name: presupuesto_extension_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_extension_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_extension_seq OWNER TO postgres;

--
-- Name: presupuesto_extension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presupuesto_extension (
    id_presupuesto integer DEFAULT nextval('public.presupuesto_extension_seq'::regclass) NOT NULL,
    id_pext integer NOT NULL,
    id_rubro_extension integer NOT NULL,
    concepto character varying,
    cantidad integer,
    monto real
);


ALTER TABLE public.presupuesto_extension OWNER TO postgres;

--
-- Name: presupuesto_extension_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_extension_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_extension_id_seq OWNER TO postgres;

--
-- Name: presupuesto_extension_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presupuesto_extension_id_seq OWNED BY public.presupuesto_extension.id_pext;


--
-- Name: provincia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provincia (
    descripcion_pcia character(40),
    cod_pais character(2),
    codigo_pcia integer NOT NULL
);


ALTER TABLE public.provincia OWNER TO postgres;

--
-- Name: rubro_presup_extension_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rubro_presup_extension_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rubro_presup_extension_seq OWNER TO postgres;

--
-- Name: rubro_presup_extension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rubro_presup_extension (
    id_rubro_extension integer DEFAULT nextval('public.rubro_presup_extension_seq'::regclass) NOT NULL,
    tipo character varying NOT NULL
);


ALTER TABLE public.rubro_presup_extension OWNER TO postgres;

--
-- Name: tipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo (
    nro_tabla integer NOT NULL,
    desc_abrev character(4) NOT NULL,
    desc_item character(30)
);


ALTER TABLE public.tipo OWNER TO postgres;

--
-- Name: tipo_convocatoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_convocatoria (
    id_conv character(1) NOT NULL,
    descripcion character(30)
);


ALTER TABLE public.tipo_convocatoria OWNER TO postgres;

--
-- Name: tipo_convocatoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_convocatoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_convocatoria_seq OWNER TO postgres;

--
-- Name: tipo_designacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_designacion (
    id integer NOT NULL,
    descripcion character varying
);


ALTER TABLE public.tipo_designacion OWNER TO postgres;

--
-- Name: tipo_designacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_designacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_designacion_id_seq OWNER TO postgres;

--
-- Name: tipo_designacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_designacion_id_seq OWNED BY public.tipo_designacion.id;


--
-- Name: tipo_organizacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_organizacion (
    descripcion character varying,
    id_tipo_organizacion integer NOT NULL
);


ALTER TABLE public.tipo_organizacion OWNER TO postgres;

--
-- Name: tipo_organizacion_id_organizacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_organizacion_id_organizacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_organizacion_id_organizacion_seq OWNER TO postgres;

--
-- Name: tipo_organizacion_id_organizacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_organizacion_id_organizacion_seq OWNED BY public.tipo_organizacion.id_tipo_organizacion;


--
-- Name: titulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.titulo (
    codc_titul character(4) NOT NULL,
    nro_tab3 integer,
    codc_nivel character(4),
    desc_titul character varying
);


ALTER TABLE public.titulo OWNER TO postgres;

--
-- Name: titulos_docente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.titulos_docente (
    id_docente integer NOT NULL,
    codc_titul character(4) NOT NULL,
    fec_emisi date,
    fec_finalizacion date,
    codc_entot character(4)
);


ALTER TABLE public.titulos_docente OWNER TO postgres;

--
-- Name: unidad_acad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unidad_acad (
    sigla character(5) NOT NULL,
    descripcion character(60) NOT NULL,
    nro_tab6 integer,
    cod_regional character(4),
    id_tipo_dependencia integer
);


ALTER TABLE public.unidad_acad OWNER TO postgres;

--
-- Name: logs_area; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_area (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    idarea integer,
    iddepto integer,
    descripcion character(80)
);


ALTER TABLE public_auditoria.logs_area OWNER TO postgres;

--
-- Name: logs_articulo_73; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_articulo_73 (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    antiguedad integer,
    nro_tab11 integer,
    modo_ingreso character(4),
    nro_tab12 integer,
    continuidad character(4),
    observacion character varying,
    nro_resolucion character(10),
    check_academica boolean,
    observacion_acad character varying,
    pase_superior boolean,
    cat_est_reg character(6),
    dedic_reg integer,
    id_departamento integer,
    id_area integer,
    id_orientacion integer,
    check_presup boolean,
    observacion_presup character varying,
    expediente character(10),
    etapa integer,
    articulo character(2),
    cat_que_reg character(4)
);


ALTER TABLE public_auditoria.logs_articulo_73 OWNER TO postgres;

--
-- Name: logs_asignacion_materia; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_asignacion_materia (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    id_materia integer,
    nro_tab8 integer,
    rol character(4),
    id_periodo integer,
    modulo integer,
    carga_horaria integer,
    anio integer,
    externa integer,
    observacion character(50)
);


ALTER TABLE public_auditoria.logs_asignacion_materia OWNER TO postgres;

--
-- Name: logs_asignacion_tutoria; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_asignacion_tutoria (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    id_tutoria integer,
    anio integer,
    carga_horaria integer,
    nro_tab9 integer,
    rol character(4),
    periodo integer
);


ALTER TABLE public_auditoria.logs_asignacion_tutoria OWNER TO postgres;

--
-- Name: logs_auxi_docente; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_auxi_docente (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_docente integer,
    legajo integer,
    apellido character(30),
    nombre character(30),
    nro_tabla integer,
    tipo_docum character(4),
    nro_docum integer,
    fec_nacim date,
    nro_cuil1 integer,
    nro_cuil integer,
    nro_cuil2 integer,
    tipo_sexo character(1),
    pais_nacim character(2),
    porcdedicdocente double precision,
    porcdedicinvestig double precision,
    porcdedicagestion double precision,
    porcdedicaextens double precision,
    pcia_nacim integer,
    fec_ingreso date
);


ALTER TABLE public_auditoria.logs_auxi_docente OWNER TO postgres;

--
-- Name: logs_caracter; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_caracter (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_car character(1),
    descripcion character(20)
);


ALTER TABLE public_auditoria.logs_caracter OWNER TO postgres;

--
-- Name: logs_categ_estatuto; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_categ_estatuto (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    codigo_est character(10),
    descripcion character(50),
    orden integer
);


ALTER TABLE public_auditoria.logs_categ_estatuto OWNER TO postgres;

--
-- Name: logs_categ_siu; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_categ_siu (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    codigo_siu character(4),
    descripcion character(45),
    escalafon character(1)
);


ALTER TABLE public_auditoria.logs_categ_siu OWNER TO postgres;

--
-- Name: logs_categoria_invest; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_categoria_invest (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    cod_cati integer,
    descripcion character(10)
);


ALTER TABLE public_auditoria.logs_categoria_invest OWNER TO postgres;

--
-- Name: logs_categorizacion; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_categorizacion (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id integer,
    id_docente integer,
    id_cat integer,
    anio_categ integer
);


ALTER TABLE public_auditoria.logs_categorizacion OWNER TO postgres;

--
-- Name: logs_cic_conicef; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_cic_conicef (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id character(3),
    descripcion character(50)
);


ALTER TABLE public_auditoria.logs_cic_conicef OWNER TO postgres;

--
-- Name: logs_cobro_incentivo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_cobro_incentivo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_docente integer,
    id_proyecto integer,
    cuota integer,
    fecha date,
    monto numeric,
    anio integer
);


ALTER TABLE public_auditoria.logs_cobro_incentivo OWNER TO postgres;

--
-- Name: logs_comision; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_comision (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_comision integer,
    descripcion character varying
);


ALTER TABLE public_auditoria.logs_comision OWNER TO postgres;

--
-- Name: logs_conjunto; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_conjunto (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_conjunto integer,
    descripcion character varying,
    ua character(5),
    id_periodo integer,
    id_periodo_pres integer
);


ALTER TABLE public_auditoria.logs_conjunto OWNER TO postgres;

--
-- Name: logs_dao_designa; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_dao_designa (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    id_departamento integer,
    id_area integer,
    id_orientacion integer
);


ALTER TABLE public_auditoria.logs_dao_designa OWNER TO postgres;

--
-- Name: logs_dedicacion; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_dedicacion (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_ded integer,
    descripcion character(20)
);


ALTER TABLE public_auditoria.logs_dedicacion OWNER TO postgres;

--
-- Name: logs_dedicacion_incentivo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_dedicacion_incentivo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_di integer,
    descripcion character(30)
);


ALTER TABLE public_auditoria.logs_dedicacion_incentivo OWNER TO postgres;

--
-- Name: logs_departamento; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_departamento (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    iddepto integer,
    idunidad_academica character(5),
    descripcion character(60)
);


ALTER TABLE public_auditoria.logs_departamento OWNER TO postgres;

--
-- Name: logs_designacion; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_designacion (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    id_docente integer,
    nro_cargo integer,
    anio_acad integer,
    desde date,
    hasta date,
    cat_mapuche character(4),
    cat_estat character(6),
    dedic integer,
    carac character(1),
    uni_acad character(5),
    id_departamento integer,
    id_area integer,
    id_orientacion integer,
    id_norma integer,
    id_expediente integer,
    tipo_incentivo integer,
    dedi_incen integer,
    cic_con character(3),
    cargo_gestion character(4),
    ord_gestion character(10),
    emite_cargo_gestion character(4),
    nro_gestion character(10),
    observaciones character varying,
    check_presup integer,
    nro_540 integer,
    concursado integer,
    check_academica integer,
    tipo_desig integer,
    id_reserva integer,
    estado character(1),
    id_norma_cs integer,
    por_permuta integer
);


ALTER TABLE public_auditoria.logs_designacion OWNER TO postgres;

--
-- Name: logs_designacionh; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_designacionh (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    id_docente integer,
    nro_cargo integer,
    anio_acad integer,
    desde date,
    hasta date,
    cat_mapuche character(4),
    cat_estat character(6),
    dedic integer,
    carac character(1),
    uni_acad character(5),
    id_departamento integer,
    id_area integer,
    id_orientacion integer,
    id_norma integer,
    id_expediente integer,
    tipo_incentivo integer,
    dedi_incen integer,
    cic_con character(3),
    cargo_gestion character(4),
    ord_gestion character(10),
    emite_cargo_gestion character(4),
    nro_gestion character(10),
    observaciones character varying,
    check_presup integer,
    nro_540 integer,
    concursado integer,
    check_academica integer,
    tipo_desig integer,
    id_reserva integer,
    estado character(1),
    id_norma_cs integer,
    por_permuta integer,
    id integer
);


ALTER TABLE public_auditoria.logs_designacionh OWNER TO postgres;

--
-- Name: logs_director_dpto; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_director_dpto (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_docente integer,
    iddepto integer,
    desde date,
    hasta date,
    resol character(9)
);


ALTER TABLE public_auditoria.logs_director_dpto OWNER TO postgres;

--
-- Name: logs_disciplina; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_disciplina (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_disc integer,
    descripcion character(30)
);


ALTER TABLE public_auditoria.logs_disciplina OWNER TO postgres;

--
-- Name: logs_docente; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_docente (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_docente integer,
    legajo integer,
    apellido character varying,
    nombre character varying,
    nro_tabla integer,
    tipo_docum character(4),
    nro_docum integer,
    fec_nacim date,
    nro_cuil1 integer,
    nro_cuil integer,
    nro_cuil2 integer,
    tipo_sexo character(1),
    pais_nacim character(2),
    porcdedicdocente double precision,
    porcdedicinvestig double precision,
    porcdedicagestion double precision,
    porcdedicaextens double precision,
    pcia_nacim integer,
    fec_ingreso date,
    correo_institucional character(60),
    correo_personal character(60)
);


ALTER TABLE public_auditoria.logs_docente OWNER TO postgres;

--
-- Name: logs_en_conjunto; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_en_conjunto (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_conjunto integer,
    ua character(5),
    id_materia integer
);


ALTER TABLE public_auditoria.logs_en_conjunto OWNER TO postgres;

--
-- Name: logs_entidad_otorgante; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_entidad_otorgante (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    cod_entidad character(6),
    nombre character varying,
    cod_ciudad integer
);


ALTER TABLE public_auditoria.logs_entidad_otorgante OWNER TO postgres;

--
-- Name: logs_escalafon; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_escalafon (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_escalafon character(1),
    descripcion character(15)
);


ALTER TABLE public_auditoria.logs_escalafon OWNER TO postgres;

--
-- Name: logs_estado_pi; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_estado_pi (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_estado character(1),
    descripcion character(30)
);


ALTER TABLE public_auditoria.logs_estado_pi OWNER TO postgres;

--
-- Name: logs_estado_pr; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_estado_pr (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_estado character(1),
    descripcion character(30)
);


ALTER TABLE public_auditoria.logs_estado_pr OWNER TO postgres;

--
-- Name: logs_estado_solicitud; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_estado_solicitud (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_estado_solicitud integer,
    descripcion character(20)
);


ALTER TABLE public_auditoria.logs_estado_solicitud OWNER TO postgres;

--
-- Name: logs_estado_vi; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_estado_vi (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_estado character(1),
    descripcion character(30)
);


ALTER TABLE public_auditoria.logs_estado_vi OWNER TO postgres;

--
-- Name: logs_estimulo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_estimulo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    resolucion character varying(10),
    expediente character varying(10),
    fecha_pagado date,
    anio integer
);


ALTER TABLE public_auditoria.logs_estimulo OWNER TO postgres;

--
-- Name: logs_expediente; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_expediente (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_exp integer,
    nro_exp character(1),
    tipo_exp character(5),
    emite_tipo character(4),
    fecha date
);


ALTER TABLE public_auditoria.logs_expediente OWNER TO postgres;

--
-- Name: logs_funcion_extension; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_funcion_extension (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_extension character(5),
    descripcion character varying(70)
);


ALTER TABLE public_auditoria.logs_funcion_extension OWNER TO postgres;

--
-- Name: logs_funcion_investigador; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_funcion_investigador (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_funcion character(4),
    descripcion character(70),
    orden integer
);


ALTER TABLE public_auditoria.logs_funcion_investigador OWNER TO postgres;

--
-- Name: logs_historial; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_historial (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_historial integer,
    fecha timestamp without time zone,
    id_estado integer,
    id_solicitud integer
);


ALTER TABLE public_auditoria.logs_historial OWNER TO postgres;

--
-- Name: logs_impresion_540; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_impresion_540 (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id integer,
    fecha_impresion date,
    expediente character(20),
    estado character(1),
    anio integer
);


ALTER TABLE public_auditoria.logs_impresion_540 OWNER TO postgres;

--
-- Name: logs_imputacion; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_imputacion (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    porc integer,
    id_programa integer
);


ALTER TABLE public_auditoria.logs_imputacion OWNER TO postgres;

--
-- Name: logs_incentivo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_incentivo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_inc integer,
    descripcion character(20)
);


ALTER TABLE public_auditoria.logs_incentivo OWNER TO postgres;

--
-- Name: logs_inscriptos; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_inscriptos (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    inscriptos integer,
    anio_acad integer,
    id_materia integer,
    id_periodo integer,
    id_comision integer
);


ALTER TABLE public_auditoria.logs_inscriptos OWNER TO postgres;

--
-- Name: logs_institucion; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_institucion (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_institucion integer,
    nombre_institucion character varying
);


ALTER TABLE public_auditoria.logs_institucion OWNER TO postgres;

--
-- Name: logs_integrante_externo_pe; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_integrante_externo_pe (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    tipo_docum character(4),
    nro_docum integer,
    id_pext integer,
    funcion_p character(5),
    carga_horaria integer,
    desde date,
    hasta date,
    rescd character(10),
    ad_honorem integer
);


ALTER TABLE public_auditoria.logs_integrante_externo_pe OWNER TO postgres;

--
-- Name: logs_integrante_externo_pi; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_integrante_externo_pi (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    tipo_docum character(4),
    nro_docum integer,
    pinvest integer,
    cat_invest integer,
    identificador_personal character(10),
    funcion_p character(4),
    carga_horaria integer,
    desde date,
    hasta date,
    rescd character(10),
    ad_honorem integer,
    cat_invest_conicet character(30),
    id_institucion integer,
    check_inv integer,
    rescd_bm character(10)
);


ALTER TABLE public_auditoria.logs_integrante_externo_pi OWNER TO postgres;

--
-- Name: logs_integrante_interno_pe; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_integrante_interno_pe (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_docente integer,
    id_pext integer,
    funcion_p character(5),
    carga_horaria integer,
    ua character(5),
    desde date,
    hasta date,
    rescd character(10),
    ad_honorem integer,
    id_designacion integer
);


ALTER TABLE public_auditoria.logs_integrante_interno_pe OWNER TO postgres;

--
-- Name: logs_integrante_interno_pi; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_integrante_interno_pi (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_docente integer,
    pinvest integer,
    funcion_p character(4),
    cat_investigador integer,
    identificador_personal character(10),
    carga_horaria integer,
    ua character(5),
    id_designacion integer,
    desde date,
    hasta date,
    rescd character(10),
    ad_honorem integer,
    cat_invest_conicet character(30),
    check_inv integer,
    resaval character(10),
    hs_finan_otrafuente integer,
    rescd_bm character(10)
);


ALTER TABLE public_auditoria.logs_integrante_interno_pi OWNER TO postgres;

--
-- Name: logs_localidad; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_localidad (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id integer,
    id_provincia integer,
    localidad character varying(255)
);


ALTER TABLE public_auditoria.logs_localidad OWNER TO postgres;

--
-- Name: logs_macheo_categ; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_macheo_categ (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    catsiu character(4),
    catest character(10),
    id_ded integer
);


ALTER TABLE public_auditoria.logs_macheo_categ OWNER TO postgres;

--
-- Name: logs_materia; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_materia (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_materia integer,
    id_plan integer,
    desc_materia character varying,
    orden_materia integer,
    anio_segunplan integer,
    horas_semanales integer,
    periodo_dictado integer,
    periodo_dictado_real integer,
    id_departamento integer,
    id_area integer,
    id_orientacion integer,
    cod_siu character(5)
);


ALTER TABLE public_auditoria.logs_materia OWNER TO postgres;

--
-- Name: logs_mocovi_costo_categoria; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_mocovi_costo_categoria (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_costo_categoria integer,
    id_periodo integer,
    codigo_siu character(4),
    costo_basico numeric,
    costo_diario numeric
);


ALTER TABLE public_auditoria.logs_mocovi_costo_categoria OWNER TO postgres;

--
-- Name: logs_mocovi_credito; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_mocovi_credito (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_credito integer,
    id_periodo integer,
    id_unidad character(4),
    id_escalafon character(1),
    id_tipo_credito integer,
    descripcion character varying,
    credito numeric,
    id_programa integer
);


ALTER TABLE public_auditoria.logs_mocovi_credito OWNER TO postgres;

--
-- Name: logs_mocovi_periodo_presupuestario; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_mocovi_periodo_presupuestario (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_periodo integer,
    anio integer,
    fecha_inicio date,
    fecha_fin date,
    fecha_ultima_liquidacion date,
    actual boolean,
    id_liqui_ini integer,
    id_liqui_fin integer,
    id_liqui_1sac integer,
    id_liqui_2sac integer,
    presupuestando boolean,
    activo_para_carga_presupuestando boolean
);


ALTER TABLE public_auditoria.logs_mocovi_periodo_presupuestario OWNER TO postgres;

--
-- Name: logs_mocovi_programa; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_mocovi_programa (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_programa integer,
    id_unidad character(4),
    id_tipo_programa integer,
    nombre character varying,
    area integer,
    sub_area integer,
    sub_sub_area integer,
    fuente integer,
    imputacion character varying,
    programa integer,
    sub_programa integer,
    actividad integer
);


ALTER TABLE public_auditoria.logs_mocovi_programa OWNER TO postgres;

--
-- Name: logs_mocovi_tipo_credito; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_mocovi_tipo_credito (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_tipo_credito integer,
    tipo character(1)
);


ALTER TABLE public_auditoria.logs_mocovi_tipo_credito OWNER TO postgres;

--
-- Name: logs_mocovi_tipo_dependencia; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_mocovi_tipo_dependencia (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_tipo_dependencia integer,
    tipo character(60)
);


ALTER TABLE public_auditoria.logs_mocovi_tipo_dependencia OWNER TO postgres;

--
-- Name: logs_mocovi_tipo_programa; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_mocovi_tipo_programa (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_tipo_programa integer,
    tipo character varying
);


ALTER TABLE public_auditoria.logs_mocovi_tipo_programa OWNER TO postgres;

--
-- Name: logs_modulo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_modulo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_modulo integer,
    descripcion character varying
);


ALTER TABLE public_auditoria.logs_modulo OWNER TO postgres;

--
-- Name: logs_montos_viatico; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_montos_viatico (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    fecha date,
    monto numeric
);


ALTER TABLE public_auditoria.logs_montos_viatico OWNER TO postgres;

--
-- Name: logs_norma; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_norma (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_norma integer,
    nro_norma integer,
    tipo_norma character(5),
    emite_norma character(4),
    fecha date,
    link character varying,
    palabras_clave text,
    uni_acad character(4)
);


ALTER TABLE public_auditoria.logs_norma OWNER TO postgres;

--
-- Name: logs_norma_desig; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_norma_desig (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_norma integer,
    id_designacion integer
);


ALTER TABLE public_auditoria.logs_norma_desig OWNER TO postgres;

--
-- Name: logs_novedad; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_novedad (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_novedad integer,
    tipo_nov integer,
    desde date,
    hasta date,
    id_designacion integer,
    tipo_norma character(5),
    tipo_emite character(4),
    norma_legal character(10),
    observaciones character varying,
    nro_tab10 integer,
    sub_tipo character(4),
    porcen numeric
);


ALTER TABLE public_auditoria.logs_novedad OWNER TO postgres;

--
-- Name: logs_objetivo_se; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_objetivo_se (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_obj integer,
    descripcion character(113)
);


ALTER TABLE public_auditoria.logs_objetivo_se OWNER TO postgres;

--
-- Name: logs_orientacion; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_orientacion (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    idorient integer,
    idarea integer,
    descripcion character(80)
);


ALTER TABLE public_auditoria.logs_orientacion OWNER TO postgres;

--
-- Name: logs_pais; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_pais (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    codigo_pais character(2),
    nombre character varying(40)
);


ALTER TABLE public_auditoria.logs_pais OWNER TO postgres;

--
-- Name: logs_periodo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_periodo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_periodo integer,
    descripcion character(8)
);


ALTER TABLE public_auditoria.logs_periodo OWNER TO postgres;

--
-- Name: logs_persona; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_persona (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    apellido character varying,
    nombre character varying,
    nro_tabla integer,
    tipo_docum character(4),
    nro_docum integer,
    tipo_sexo character(1),
    pais_nacim character(2),
    pcia_nacim integer,
    fec_nacim date,
    titulog character(4),
    titulop character(4),
    docum_extran character(15)
);


ALTER TABLE public_auditoria.logs_persona OWNER TO postgres;

--
-- Name: logs_pextension; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_pextension (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_pext integer,
    codigo character varying,
    denominacion character varying,
    nro_resol character(20),
    fecha_resol date,
    uni_acad character(5),
    fec_desde date,
    fec_hasta date,
    nro_ord_cs character(20),
    res_rect character(20),
    expediente character(12),
    duracion integer,
    palabras_clave character(120),
    objetivo character varying,
    estado character(1),
    financiacion boolean,
    monto numeric,
    fecha_rendicion date,
    rendicion_monto double precision,
    fecha_prorroga1 date,
    fecha_prorroga2 date,
    observacion character varying,
    estado_informe_a character(1),
    estado_informe_f character(1)
);


ALTER TABLE public_auditoria.logs_pextension OWNER TO postgres;

--
-- Name: logs_pinvestigacion; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_pinvestigacion (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_pinv integer,
    codigo character varying,
    denominacion character varying,
    nro_resol character(10),
    fec_resol date,
    uni_acad character(5),
    fec_desde date,
    fec_hasta date,
    duracion integer,
    objetivo character varying,
    nro_ord_cs character(10),
    fecha_ord_cs date,
    es_programa integer,
    tipo character(5),
    estado character(1),
    observacion character varying,
    disp_asent character(10),
    id_respon_sub integer,
    palabras_clave character(150),
    resumen character varying,
    nro_resol_baja character(10),
    fec_baja date,
    observacionscyt character varying,
    id_disciplina integer,
    id_obj integer,
    tdi integer
);


ALTER TABLE public_auditoria.logs_pinvestigacion OWNER TO postgres;

--
-- Name: logs_plan_estudio; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_plan_estudio (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_plan integer,
    cod_carrera character(11),
    desc_carrera character(120),
    titulo character(160),
    uni_acad character(5),
    ordenanza character(30)
);


ALTER TABLE public_auditoria.logs_plan_estudio OWNER TO postgres;

--
-- Name: logs_porcentaje_lsgh; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_porcentaje_lsgh (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    porcen numeric,
    descripcion character(25)
);


ALTER TABLE public_auditoria.logs_porcentaje_lsgh OWNER TO postgres;

--
-- Name: logs_programa; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_programa (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    id_materia integer,
    modulo integer,
    anio integer,
    id_estado character(1),
    fecha date,
    link text,
    observacion text
);


ALTER TABLE public_auditoria.logs_programa OWNER TO postgres;

--
-- Name: logs_provincia; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_provincia (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    descripcion_pcia character(40),
    cod_pais character(2),
    codigo_pcia integer
);


ALTER TABLE public_auditoria.logs_provincia OWNER TO postgres;

--
-- Name: logs_reserva; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_reserva (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_reserva integer,
    descripcion character varying
);


ALTER TABLE public_auditoria.logs_reserva OWNER TO postgres;

--
-- Name: logs_reserva_ocupada_por; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_reserva_ocupada_por (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_designacion integer,
    id_reserva integer
);


ALTER TABLE public_auditoria.logs_reserva_ocupada_por OWNER TO postgres;

--
-- Name: logs_solicitud; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_solicitud (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    observaciones character varying,
    id_orientacion integer,
    id_area integer,
    id_departamento integer,
    uni_acad character(5),
    carac character(1),
    dedic integer,
    cat_estat character(10),
    cat_mapuche character(4),
    hasta date,
    desde date,
    anio_acad integer,
    nro_cargo integer,
    id_docente integer,
    materias character varying,
    justificacion_depto character varying,
    justificacion_academica character varying,
    codigo_area character(8),
    codigo_orientacion character(8),
    id_solicitud integer,
    periodo integer,
    docente_nuevo character varying
);


ALTER TABLE public_auditoria.logs_solicitud OWNER TO postgres;

--
-- Name: logs_subproyecto; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_subproyecto (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_programa integer,
    id_proyecto integer
);


ALTER TABLE public_auditoria.logs_subproyecto OWNER TO postgres;

--
-- Name: logs_subsidio; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_subsidio (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    numero integer,
    id_proyecto integer,
    fecha_pago date,
    observaciones character varying(200),
    monto double precision,
    resolucion character varying(10),
    expediente character varying(10),
    fecha_rendicion date,
    estado character varying(1),
    nota character varying(20),
    memo character varying(20),
    id_respon_sub integer
);


ALTER TABLE public_auditoria.logs_subsidio OWNER TO postgres;

--
-- Name: logs_suplente; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_suplente (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_desig_suplente integer,
    id_desig integer
);


ALTER TABLE public_auditoria.logs_suplente OWNER TO postgres;

--
-- Name: logs_tiene_estimulo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_tiene_estimulo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_proyecto integer,
    resolucion character varying(10),
    expediente character varying(10),
    monto double precision,
    estado character varying(1),
    fecha_rendicion date,
    memo character varying(20),
    nota character varying(20),
    id_respon integer
);


ALTER TABLE public_auditoria.logs_tiene_estimulo OWNER TO postgres;

--
-- Name: logs_tipo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_tipo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    nro_tabla integer,
    desc_abrev character(4),
    desc_item character(30)
);


ALTER TABLE public_auditoria.logs_tipo OWNER TO postgres;

--
-- Name: logs_tipo_de_inv; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_tipo_de_inv (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id integer,
    descripcion character(30)
);


ALTER TABLE public_auditoria.logs_tipo_de_inv OWNER TO postgres;

--
-- Name: logs_tipo_designacion; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_tipo_designacion (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id integer,
    descripcion character varying
);


ALTER TABLE public_auditoria.logs_tipo_designacion OWNER TO postgres;

--
-- Name: logs_tipo_emite; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_tipo_emite (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    cod_emite character(4),
    quien_emite_norma character(20)
);


ALTER TABLE public_auditoria.logs_tipo_emite OWNER TO postgres;

--
-- Name: logs_tipo_norma_exp; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_tipo_norma_exp (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    cod_tipo character(5),
    nombre_tipo character(20)
);


ALTER TABLE public_auditoria.logs_tipo_norma_exp OWNER TO postgres;

--
-- Name: logs_tipo_novedad; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_tipo_novedad (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_tipo integer,
    desc_corta character(4),
    descripcion character(60)
);


ALTER TABLE public_auditoria.logs_tipo_novedad OWNER TO postgres;

--
-- Name: logs_titulo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_titulo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    codc_titul character(4),
    nro_tab3 integer,
    codc_nivel character(4),
    desc_titul character varying
);


ALTER TABLE public_auditoria.logs_titulo OWNER TO postgres;

--
-- Name: logs_titulos_docente; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_titulos_docente (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_docente integer,
    codc_titul character(4),
    fec_emisi date,
    fec_finalizacion date,
    codc_entot character(4)
);


ALTER TABLE public_auditoria.logs_titulos_docente OWNER TO postgres;

--
-- Name: logs_tutoria; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_tutoria (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_tutoria integer,
    descripcion character varying,
    uni_acad character(5)
);


ALTER TABLE public_auditoria.logs_tutoria OWNER TO postgres;

--
-- Name: logs_unidad_acad; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_unidad_acad (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    sigla character(5),
    descripcion character(60),
    nro_tab6 integer,
    cod_regional character(4),
    id_tipo_dependencia integer
);


ALTER TABLE public_auditoria.logs_unidad_acad OWNER TO postgres;

--
-- Name: logs_viatico; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_viatico (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    id_viatico integer,
    id_proyecto integer,
    nro_tab integer,
    tipo character(4),
    fecha_solicitud date,
    fecha_pago date,
    expediente_pago character varying(20),
    memo_solicitud character varying(20),
    memo_certificados character varying(20),
    es_nacional integer,
    cant_dias numeric,
    fecha_present_certif date,
    observaciones character varying(50),
    estado character(1),
    origen character(45),
    destino character(45),
    fecha_salida timestamp without time zone,
    fecha_regreso timestamp without time zone,
    nombre_actividad character varying(120),
    nro_tab2 integer,
    medio_transporte character(4),
    nro_docum_desti integer,
    monto numeric
);


ALTER TABLE public_auditoria.logs_viatico OWNER TO postgres;

--
-- Name: logs_vigentes; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_vigentes (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    apellido character(40),
    nombre character(40),
    legajo integer,
    fuente integer,
    ua character(4),
    cargo integer,
    categoria character(4),
    desde date,
    hasta date,
    continuidad integer,
    marcado integer,
    dias integer,
    categoria_max character(4),
    dias_cat_max integer
);


ALTER TABLE public_auditoria.logs_vigentes OWNER TO postgres;

--
-- Name: logs_vinculo; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_vinculo (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    desig integer,
    vinc integer
);


ALTER TABLE public_auditoria.logs_vinculo OWNER TO postgres;

--
-- Name: logs_winsip; Type: TABLE; Schema: public_auditoria; Owner: postgres
--

CREATE TABLE public_auditoria.logs_winsip (
    auditoria_usuario character varying(60),
    auditoria_fecha timestamp without time zone,
    auditoria_operacion character(1),
    auditoria_id_solicitud integer,
    periodo character varying(9),
    id_proyecto integer,
    fecha_presentacion date,
    resultado character varying(1),
    fecha_aprobacion date
);


ALTER TABLE public_auditoria.logs_winsip OWNER TO postgres;

--
-- Name: dedicacion_incentivo id_di; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dedicacion_incentivo ALTER COLUMN id_di SET DEFAULT nextval('public.dedicacion_incentivo_id_di_seq'::regclass);


--
-- Name: designacion id_designacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion ALTER COLUMN id_designacion SET DEFAULT nextval('public.designacion_id_designacion_seq'::regclass);


--
-- Name: incentivo id_inc; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentivo ALTER COLUMN id_inc SET DEFAULT nextval('public.incentivo_id_inc_seq'::regclass);


--
-- Name: norma id_norma; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma ALTER COLUMN id_norma SET DEFAULT nextval('public.norma_id_norma_seq'::regclass);


--
-- Name: organizaciones_participantes id_organizacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes ALTER COLUMN id_organizacion SET DEFAULT nextval('public.organizaciones_participantes_id_organizacion_seq'::regclass);


--
-- Name: pextension id_pext; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension ALTER COLUMN id_pext SET DEFAULT nextval('public.pextension_id_pext_seq'::regclass);


--
-- Name: tipo_designacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_designacion ALTER COLUMN id SET DEFAULT nextval('public.tipo_designacion_id_seq'::regclass);


--
-- Name: tipo_organizacion id_tipo_organizacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_organizacion ALTER COLUMN id_tipo_organizacion SET DEFAULT nextval('public.tipo_organizacion_id_organizacion_seq'::regclass);


--
-- Name: bases_convocatoria bases_convocatoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bases_convocatoria
    ADD CONSTRAINT bases_convocatoria_pkey PRIMARY KEY (id_bases);


--
-- Name: estado_pe estado_pe_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_pe
    ADD CONSTRAINT estado_pe_pkey PRIMARY KEY (id_estado);


--
-- Name: organizaciones_participantes organizaciones_participantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes
    ADD CONSTRAINT organizaciones_participantes_pkey PRIMARY KEY (id_organizacion);


--
-- Name: area pk_area; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area
    ADD CONSTRAINT pk_area PRIMARY KEY (idarea);


--
-- Name: caracter pk_caracter; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caracter
    ADD CONSTRAINT pk_caracter PRIMARY KEY (id_car);


--
-- Name: dedicacion pk_dedicacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dedicacion
    ADD CONSTRAINT pk_dedicacion PRIMARY KEY (id_ded);


--
-- Name: dedicacion_incentivo pk_dedicacion_incentivo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dedicacion_incentivo
    ADD CONSTRAINT pk_dedicacion_incentivo PRIMARY KEY (id_di);


--
-- Name: departamento pk_departamento; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT pk_departamento PRIMARY KEY (iddepto);


--
-- Name: designacion pk_designacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT pk_designacion PRIMARY KEY (id_designacion);


--
-- Name: director_dpto pk_director_dpto; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.director_dpto
    ADD CONSTRAINT pk_director_dpto PRIMARY KEY (id_docente, iddepto, desde);


--
-- Name: docente pk_docente; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT pk_docente PRIMARY KEY (id_docente);


--
-- Name: funcion_extension pk_funcion_extension; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcion_extension
    ADD CONSTRAINT pk_funcion_extension PRIMARY KEY (id_extension);


--
-- Name: incentivo pk_incentivo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentivo
    ADD CONSTRAINT pk_incentivo PRIMARY KEY (id_inc);


--
-- Name: integrante_externo_pe pk_integrante_externo_pe; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_externo_pe
    ADD CONSTRAINT pk_integrante_externo_pe PRIMARY KEY (tipo_docum, nro_docum, id_pext, desde);


--
-- Name: integrante_interno_pe pk_integrante_interno_pe; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_interno_pe
    ADD CONSTRAINT pk_integrante_interno_pe PRIMARY KEY (id_pext, id_designacion, desde);


--
-- Name: localidad pk_localidad; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.localidad
    ADD CONSTRAINT pk_localidad PRIMARY KEY (id);


--
-- Name: norma pk_norma; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma
    ADD CONSTRAINT pk_norma PRIMARY KEY (id_norma);


--
-- Name: norma_desig pk_norma_desig; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma_desig
    ADD CONSTRAINT pk_norma_desig PRIMARY KEY (id_norma, id_designacion);


--
-- Name: orientacion pk_orientacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orientacion
    ADD CONSTRAINT pk_orientacion PRIMARY KEY (idorient, idarea);


--
-- Name: pais pk_pais; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pais
    ADD CONSTRAINT pk_pais PRIMARY KEY (codigo_pais);


--
-- Name: persona pk_persona; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT pk_persona PRIMARY KEY (tipo_docum, nro_docum);


--
-- Name: pextension pk_pextension; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension
    ADD CONSTRAINT pk_pextension PRIMARY KEY (id_pext);


--
-- Name: provincia pk_provincia; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provincia
    ADD CONSTRAINT pk_provincia PRIMARY KEY (codigo_pcia);


--
-- Name: tipo pk_tipo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo
    ADD CONSTRAINT pk_tipo PRIMARY KEY (nro_tabla, desc_abrev);


--
-- Name: tipo_designacion pk_tipo_designacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_designacion
    ADD CONSTRAINT pk_tipo_designacion PRIMARY KEY (id);


--
-- Name: titulos_docente pk_tit_doce; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulos_docente
    ADD CONSTRAINT pk_tit_doce PRIMARY KEY (id_docente, codc_titul);


--
-- Name: titulo pk_titulo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulo
    ADD CONSTRAINT pk_titulo PRIMARY KEY (codc_titul);


--
-- Name: unidad_acad pk_ua; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unidad_acad
    ADD CONSTRAINT pk_ua PRIMARY KEY (sigla);


--
-- Name: presupuesto_extension presupuesto_extension_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_extension
    ADD CONSTRAINT presupuesto_extension_pkey PRIMARY KEY (id_presupuesto, id_pext, id_rubro_extension);


--
-- Name: rubro_presup_extension rubro_presup_extension_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rubro_presup_extension
    ADD CONSTRAINT rubro_presup_extension_pkey PRIMARY KEY (id_rubro_extension);


--
-- Name: tipo_convocatoria tipo_convocatoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_convocatoria
    ADD CONSTRAINT tipo_convocatoria_pkey PRIMARY KEY (id_conv);


--
-- Name: tipo_organizacion tipo_organizacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_organizacion
    ADD CONSTRAINT tipo_organizacion_pkey PRIMARY KEY (id_tipo_organizacion);


--
-- Name: designacion unico_nro_cargo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT unico_nro_cargo UNIQUE (nro_cargo);


--
-- Name: docente unico_nro_docum; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT unico_nro_docum UNIQUE (nro_docum);


--
-- Name: area tauditoria_area; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_area AFTER INSERT OR DELETE OR UPDATE ON public.area FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_area();


--
-- Name: caracter tauditoria_caracter; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_caracter AFTER INSERT OR DELETE OR UPDATE ON public.caracter FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_caracter();


--
-- Name: dedicacion tauditoria_dedicacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_dedicacion AFTER INSERT OR DELETE OR UPDATE ON public.dedicacion FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_dedicacion();


--
-- Name: dedicacion_incentivo tauditoria_dedicacion_incentivo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_dedicacion_incentivo AFTER INSERT OR DELETE OR UPDATE ON public.dedicacion_incentivo FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_dedicacion_incentivo();


--
-- Name: departamento tauditoria_departamento; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_departamento AFTER INSERT OR DELETE OR UPDATE ON public.departamento FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_departamento();


--
-- Name: designacion tauditoria_designacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_designacion AFTER INSERT OR DELETE OR UPDATE ON public.designacion FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_designacion();


--
-- Name: director_dpto tauditoria_director_dpto; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_director_dpto AFTER INSERT OR DELETE OR UPDATE ON public.director_dpto FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_director_dpto();


--
-- Name: docente tauditoria_docente; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_docente AFTER INSERT OR DELETE OR UPDATE ON public.docente FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_docente();


--
-- Name: funcion_extension tauditoria_funcion_extension; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_funcion_extension AFTER INSERT OR DELETE OR UPDATE ON public.funcion_extension FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_funcion_extension();


--
-- Name: incentivo tauditoria_incentivo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_incentivo AFTER INSERT OR DELETE OR UPDATE ON public.incentivo FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_incentivo();


--
-- Name: integrante_externo_pe tauditoria_integrante_externo_pe; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_integrante_externo_pe AFTER INSERT OR DELETE OR UPDATE ON public.integrante_externo_pe FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_integrante_externo_pe();


--
-- Name: integrante_interno_pe tauditoria_integrante_interno_pe; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_integrante_interno_pe AFTER INSERT OR DELETE OR UPDATE ON public.integrante_interno_pe FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_integrante_interno_pe();


--
-- Name: localidad tauditoria_localidad; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_localidad AFTER INSERT OR DELETE OR UPDATE ON public.localidad FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_localidad();


--
-- Name: norma tauditoria_norma; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_norma AFTER INSERT OR DELETE OR UPDATE ON public.norma FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_norma();


--
-- Name: norma_desig tauditoria_norma_desig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_norma_desig AFTER INSERT OR DELETE OR UPDATE ON public.norma_desig FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_norma_desig();


--
-- Name: orientacion tauditoria_orientacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_orientacion AFTER INSERT OR DELETE OR UPDATE ON public.orientacion FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_orientacion();


--
-- Name: pais tauditoria_pais; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_pais AFTER INSERT OR DELETE OR UPDATE ON public.pais FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_pais();


--
-- Name: persona tauditoria_persona; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_persona AFTER INSERT OR DELETE OR UPDATE ON public.persona FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_persona();


--
-- Name: pextension tauditoria_pextension; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_pextension AFTER INSERT OR DELETE OR UPDATE ON public.pextension FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_pextension();


--
-- Name: provincia tauditoria_provincia; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_provincia AFTER INSERT OR DELETE OR UPDATE ON public.provincia FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_provincia();


--
-- Name: tipo tauditoria_tipo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_tipo AFTER INSERT OR DELETE OR UPDATE ON public.tipo FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_tipo();


--
-- Name: tipo_designacion tauditoria_tipo_designacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_tipo_designacion AFTER INSERT OR DELETE OR UPDATE ON public.tipo_designacion FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_tipo_designacion();


--
-- Name: titulo tauditoria_titulo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_titulo AFTER INSERT OR DELETE OR UPDATE ON public.titulo FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_titulo();


--
-- Name: titulos_docente tauditoria_titulos_docente; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_titulos_docente AFTER INSERT OR DELETE OR UPDATE ON public.titulos_docente FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_titulos_docente();


--
-- Name: unidad_acad tauditoria_unidad_acad; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_unidad_acad AFTER INSERT OR DELETE OR UPDATE ON public.unidad_acad FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_unidad_acad();


--
-- Name: bases_convocatoria bases_convocatoria_tipo_convocatoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bases_convocatoria
    ADD CONSTRAINT bases_convocatoria_tipo_convocatoria_fkey FOREIGN KEY (tipo_convocatoria) REFERENCES public.tipo_convocatoria(id_conv);


--
-- Name: area fk_area_departamento; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area
    ADD CONSTRAINT fk_area_departamento FOREIGN KEY (iddepto) REFERENCES public.departamento(iddepto);


--
-- Name: departamento fk_departamento_ua; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT fk_departamento_ua FOREIGN KEY (idunidad_academica) REFERENCES public.unidad_acad(sigla);


--
-- Name: designacion fk_designacion_caracter; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_caracter FOREIGN KEY (carac) REFERENCES public.caracter(id_car);


--
-- Name: designacion fk_designacion_dedicacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_dedicacion FOREIGN KEY (dedic) REFERENCES public.dedicacion(id_ded);


--
-- Name: designacion fk_designacion_dedincent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_dedincent FOREIGN KEY (dedi_incen) REFERENCES public.dedicacion_incentivo(id_di);


--
-- Name: designacion fk_designacion_departamento; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_departamento FOREIGN KEY (id_departamento) REFERENCES public.departamento(iddepto);


--
-- Name: designacion fk_designacion_docente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_docente FOREIGN KEY (id_docente) REFERENCES public.docente(id_docente);


--
-- Name: designacion fk_designacion_incentivo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_incentivo FOREIGN KEY (tipo_incentivo) REFERENCES public.incentivo(id_inc);


--
-- Name: designacion fk_designacion_norma; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_norma FOREIGN KEY (id_norma) REFERENCES public.norma(id_norma) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: designacion fk_designacion_normacs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_normacs FOREIGN KEY (id_norma_cs) REFERENCES public.norma(id_norma) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: designacion fk_designacion_orientacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_orientacion FOREIGN KEY (id_orientacion, id_area) REFERENCES public.orientacion(idorient, idarea);


--
-- Name: designacion fk_designacion_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_tipo FOREIGN KEY (tipo_desig) REFERENCES public.tipo_designacion(id);


--
-- Name: designacion fk_designacion_ua; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_ua FOREIGN KEY (uni_acad) REFERENCES public.unidad_acad(sigla);


--
-- Name: director_dpto fk_director_dpto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.director_dpto
    ADD CONSTRAINT fk_director_dpto FOREIGN KEY (iddepto) REFERENCES public.departamento(iddepto);


--
-- Name: director_dpto fk_director_dpto_docente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.director_dpto
    ADD CONSTRAINT fk_director_dpto_docente FOREIGN KEY (id_docente) REFERENCES public.docente(id_docente);


--
-- Name: docente fk_docente_pais_nacim; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT fk_docente_pais_nacim FOREIGN KEY (pais_nacim) REFERENCES public.pais(codigo_pais);


--
-- Name: docente fk_docente_pcia_nacim; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT fk_docente_pcia_nacim FOREIGN KEY (pcia_nacim) REFERENCES public.provincia(codigo_pcia);


--
-- Name: docente fk_docente_tipodocum; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT fk_docente_tipodocum FOREIGN KEY (nro_tabla, tipo_docum) REFERENCES public.tipo(nro_tabla, desc_abrev);


--
-- Name: integrante_externo_pe fk_integrante_externo_pe_persona; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_externo_pe
    ADD CONSTRAINT fk_integrante_externo_pe_persona FOREIGN KEY (tipo_docum, nro_docum) REFERENCES public.persona(tipo_docum, nro_docum) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: integrante_interno_pe fk_integrante_oe_funcion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_interno_pe
    ADD CONSTRAINT fk_integrante_oe_funcion FOREIGN KEY (funcion_p) REFERENCES public.funcion_extension(id_extension);


--
-- Name: integrante_externo_pe fk_integrante_pe_funcion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_externo_pe
    ADD CONSTRAINT fk_integrante_pe_funcion FOREIGN KEY (funcion_p) REFERENCES public.funcion_extension(id_extension);


--
-- Name: integrante_externo_pe fk_integrante_pe_pinv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_externo_pe
    ADD CONSTRAINT fk_integrante_pe_pinv FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: integrante_interno_pe fk_integrante_pe_pinv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_interno_pe
    ADD CONSTRAINT fk_integrante_pe_pinv FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: integrante_interno_pe fk_integrante_pe_ua; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_interno_pe
    ADD CONSTRAINT fk_integrante_pe_ua FOREIGN KEY (ua) REFERENCES public.unidad_acad(sigla);


--
-- Name: localidad fk_localidad_pcia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.localidad
    ADD CONSTRAINT fk_localidad_pcia FOREIGN KEY (id_provincia) REFERENCES public.provincia(codigo_pcia);


--
-- Name: norma_desig fk_norma_desig_designacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma_desig
    ADD CONSTRAINT fk_norma_desig_designacion FOREIGN KEY (id_designacion) REFERENCES public.designacion(id_designacion) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: norma_desig fk_norma_desig_norma; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma_desig
    ADD CONSTRAINT fk_norma_desig_norma FOREIGN KEY (id_norma) REFERENCES public.norma(id_norma) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orientacion fk_orientacion_area; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orientacion
    ADD CONSTRAINT fk_orientacion_area FOREIGN KEY (idarea) REFERENCES public.area(idarea);


--
-- Name: persona fk_persona_pais; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_pais FOREIGN KEY (pais_nacim) REFERENCES public.pais(codigo_pais);


--
-- Name: persona fk_persona_pcia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_pcia FOREIGN KEY (pcia_nacim) REFERENCES public.provincia(codigo_pcia);


--
-- Name: persona fk_persona_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_tipo FOREIGN KEY (nro_tabla, tipo_docum) REFERENCES public.tipo(nro_tabla, desc_abrev);


--
-- Name: persona fk_persona_titulog; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_titulog FOREIGN KEY (titulog) REFERENCES public.titulo(codc_titul);


--
-- Name: persona fk_persona_titulop; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_titulop FOREIGN KEY (titulop) REFERENCES public.titulo(codc_titul);


--
-- Name: pextension fk_pextension_ua; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension
    ADD CONSTRAINT fk_pextension_ua FOREIGN KEY (uni_acad) REFERENCES public.unidad_acad(sigla);


--
-- Name: provincia fk_provincia_pais; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provincia
    ADD CONSTRAINT fk_provincia_pais FOREIGN KEY (cod_pais) REFERENCES public.pais(codigo_pais);


--
-- Name: titulos_docente fk_titdoce_leg; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulos_docente
    ADD CONSTRAINT fk_titdoce_leg FOREIGN KEY (id_docente) REFERENCES public.docente(id_docente);


--
-- Name: titulos_docente fk_titdoce_tit; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulos_docente
    ADD CONSTRAINT fk_titdoce_tit FOREIGN KEY (codc_titul) REFERENCES public.titulo(codc_titul);


--
-- Name: titulo fk_titulo_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulo
    ADD CONSTRAINT fk_titulo_tipo FOREIGN KEY (nro_tab3, codc_nivel) REFERENCES public.tipo(nro_tabla, desc_abrev);


--
-- Name: unidad_acad fk_ua_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unidad_acad
    ADD CONSTRAINT fk_ua_tipo FOREIGN KEY (nro_tab6, cod_regional) REFERENCES public.tipo(nro_tabla, desc_abrev);


--
-- Name: organizaciones_participantes organizaciones_participantes_id_localidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes
    ADD CONSTRAINT organizaciones_participantes_id_localidad_fkey FOREIGN KEY (id_localidad) REFERENCES public.localidad(id);


--
-- Name: organizaciones_participantes organizaciones_participantes_id_pext_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes
    ADD CONSTRAINT organizaciones_participantes_id_pext_fkey FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: organizaciones_participantes organizaciones_participantes_id_tipo_organizacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes
    ADD CONSTRAINT organizaciones_participantes_id_tipo_organizacion_fkey FOREIGN KEY (id_tipo_organizacion) REFERENCES public.tipo_organizacion(id_tipo_organizacion);


--
-- Name: pextension pextension_estado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension
    ADD CONSTRAINT pextension_estado_fkey FOREIGN KEY (estado) REFERENCES public.estado_pe(id_estado);


--
-- Name: pextension pextension_id_bases_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension
    ADD CONSTRAINT pextension_id_bases_fkey FOREIGN KEY (id_bases) REFERENCES public.bases_convocatoria(id_bases);


--
-- Name: presupuesto_extension presupuesto_extension_id_pext_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_extension
    ADD CONSTRAINT presupuesto_extension_id_pext_fkey FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: presupuesto_extension presupuesto_extension_id_rubro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_extension
    ADD CONSTRAINT presupuesto_extension_id_rubro_fkey FOREIGN KEY (id_rubro_extension) REFERENCES public.rubro_presup_extension(id_rubro_extension);


--
-- PostgreSQL database dump complete
--

