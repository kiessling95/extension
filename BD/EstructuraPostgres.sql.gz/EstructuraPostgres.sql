--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Ubuntu 11.5-3.pgdg18.04+1)
-- Dumped by pg_dump version 12.0 (Ubuntu 12.0-2.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: crosstab6; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.crosstab6 AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text,
	category_4 text,
	category_5 text,
	category_6 text
);


ALTER TYPE public.crosstab6 OWNER TO postgres;

--
-- Name: my_crosstab_float8_5_cols; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.my_crosstab_float8_5_cols AS (
	my_row_name text,
	my_category_1 double precision,
	my_category_2 double precision,
	my_category_3 double precision,
	my_category_4 double precision,
	my_category_5 double precision
);


ALTER TYPE public.my_crosstab_float8_5_cols OWNER TO postgres;

--
-- Name: tablefunc_crosstab_2; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_2 AS (
	row_name text,
	category_1 text,
	category_2 text
);


ALTER TYPE public.tablefunc_crosstab_2 OWNER TO postgres;

--
-- Name: tablefunc_crosstab_3; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_3 AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text
);


ALTER TYPE public.tablefunc_crosstab_3 OWNER TO postgres;

--
-- Name: tablefunc_crosstab_4; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_4 AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text,
	category_4 text
);


ALTER TYPE public.tablefunc_crosstab_4 OWNER TO postgres;

--
-- Name: tablefunc_crosstab_6; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_6 AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text,
	category_4 text,
	category_5 text,
	category_6 text
);


ALTER TYPE public.tablefunc_crosstab_6 OWNER TO postgres;

--
-- Name: tablefunc_crosstab_n; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tablefunc_crosstab_n AS (
	row_name text,
	category_1 text,
	category_2 text,
	category_3 text,
	category_4 text,
	category_5 text,
	category_6 text
);


ALTER TYPE public.tablefunc_crosstab_n OWNER TO postgres;

--
-- Name: anexo1(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.anexo1(integer, character) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      	character(4);
  annio		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  reg2 		record;
  detalle	text;
  segundo	integer;
  tercero	integer;
  

BEGIN
annio:=$1;
uni:=$2;


--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

CREATE LOCAL TEMP TABLE auxiliar
(
  agente		character(40),
  legajo		integer,
  id_designacion      	integer,
  id_departamento	integer,
  id_area		integer,
  id_orientacion	integer,
  cat_mapu		character(4),
  cat_estat		character(8),
  carac			character(1),
  desde			date,
  hasta			date,
  estado		character(1),
  investig		text,
  extens		text,
  gestion		text,
  postgrado		text,
  tutorias		text,
  otros			text
  
  );
CREATE LOCAL TEMP TABLE vincu(
  dato		integer
);

--primero recupero todas las designaciones que no se han dado de baja, correspondientes a la ua y anio que ingresa como argumento
insert into auxiliar

                        select distinct c.agente,c.legajo,c.id_designacion,c.id_departamento,c.id_area,c.id_orientacion,c.cat_mapuche,c.cat_estat,c.carac,c.desde,c.hasta, case when id_novedad is not null then 'L' else estado end,null,null,c.cargo_gestion,null,null,null from     
                       (select distinct t_pe.anio,t_pe.fecha_inicio,t_pe.fecha_fin,t_d.id_designacion,trim(t_d.cat_estat)||t_d.dedic as cat_estat,t_d.cargo_gestion,t_d.uni_acad,t_d.id_departamento,t_d.id_area,t_d.id_orientacion,t_do.apellido||', '||t_do.nombre as agente,t_do.legajo,t_d.carac,t_d.cat_mapuche,t_d.dedic,t_d.desde,t_d.hasta,t_d.estado   
                            from designacion t_d , docente t_do, mocovi_periodo_presupuestario t_pe
                            where t_d.id_docente=t_do.id_docente
                            and (t_d.desde <=t_pe.fecha_fin and (t_d.hasta>=t_pe.fecha_inicio or t_d.hasta is null))
                            and t_pe.anio=annio
                            and uni_acad=uni
                            and (hasta is null or (desde<hasta))
                            and not exists (select * from novedad t_n
                                            where t_d.id_designacion=t_n.id_designacion
                                            and t_n.tipo_nov in (1,4)))c
             	      LEFT OUTER JOIN novedad t_n ON (c.id_designacion=t_n.id_designacion and t_n.tipo_nov in (2,3,5)
                                             and t_n.desde <=c.fecha_fin and (t_n.hasta>=c.fecha_inicio or t_n.hasta is null))            ;
  
  	--para cada designacion veo si tiene proyectos de investigacion vigentes en el anio que ingresa
  	--toma el ultimo movimiento
  	--no importa de que facultad es el proyecto
  	FOR reg IN
 		select * from auxiliar
	LOOP
	  --nuevo busco los 3 vinculos para atras de la designacion
         	  
	     insert into vincu (dato) values(reg.id_designacion);--inserta el primero
	     select vinc into segundo from vinculo where desig=reg.id_designacion;--
	     if segundo is not null then
 		insert into vincu(dato) values(segundo); 
 		select vinc into tercero from vinculo where desig=segundo;
 		if tercero is not null then
 			insert into vincu(dato) values(tercero); 
 		end if;
             end if;
         
	  --
	     detalle:='';
	     FOR reg2 IN --por si participara de mas de un proyecto de investigacion
	        select  case when c.codigo is null then 'S/C' else c.codigo end ||'-'||b.funcion_p||'-'||b.carga_horaria||'hs' as det
 		from integrante_interno_pi b,pinvestigacion c
 		where c.id_pinv=b.pinvest 
 		and b.hasta=c.fec_hasta
 		and b.desde<=udiames and b.hasta >=pdiames
 		and c.fec_desde <=udiames and (c.fec_hasta>=pdiames or c.fec_hasta is null)
 		and b.id_designacion in(select dato from vincu) --=reg.id_designacion --
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set investig=detalle where id_designacion=reg.id_designacion;
 	     -- veo si tiene proyectos de extension vigentes en el anio que ingresa
 	     --toma el ultimo movimiento
 	     --no importa de que facultad es el proyecto
 	     detalle:='';                                                                   
             FOR reg2 IN                                                                    
                select  c.nro_resol ||' ('||b.funcion_p||') '||b.carga_horaria||'hs' as det 
                 from integrante_interno_pe b,pextension c                                     
                 where c.id_pext=b.id_pext                                                     
                 and b.hasta=c.fec_hasta                                                       
                 and b.desde<=udiames and b.hasta >=pdiames                                    
                 and c.fec_desde <=udiames and (c.fec_hasta>=pdiames or c.fec_hasta is null)   
                 and b.id_designacion in(select dato from vincu) --=reg.id_designacion                                       
             LOOP                                                                           
                 detalle:=detalle||reg2.det;                                                   
                 detalle:=detalle||chr(13);                                                    
             END  LOOP;                                                                     
             update auxiliar set extens=detalle where id_designacion=reg.id_designacion;    
	    ---postgrados
	    detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and t_a.rol='POST'
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set postgrado=detalle where id_designacion=reg.id_designacion;
 	     --tutorias la carga horaria no es obligatoria Uso el concat para no anular cuando no tiene carga horaria
 	     detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and (t_a.rol='TUTO' or t_a.rol='COOR')
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set tutorias=detalle where id_designacion=reg.id_designacion;
 	     --otros
 	      detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end  as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and (t_a.rol='OTRO')
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set otros=detalle where id_designacion=reg.id_designacion;
 	     delete from vincu;
            
	END LOOP;
	
return 1;
END; 
$_$;


ALTER FUNCTION public.anexo1(integer, character) OWNER TO postgres;

--
-- Name: anexo2(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.anexo2(integer, character) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      	character(4);
  annio		integer;
  i		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  reg2		record;
  detalle       text;  

BEGIN
annio:=$1;
uni:=$2;
--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

CREATE LOCAL TEMP TABLE auxiliar
(
  agente		character(40),
  id_docente		integer,
  legajo		integer,
  titulos		text,
  id_designacion      	integer,
  nro_540		integer,
  cat_mapu		character(4),
  cat_estat		character(8),
  carac			character(1),
  estado		character(1),
  id_departamento	integer,
  id_area		integer,
  id_orientacion	integer,
  mat0			text,
  mat1			text,
  mat2			text,
  mat3			text,
  mat4			text,
  mat5			text
  
  );

--primero recupero todas las designaciones que no se han dado de baja, correspondientes a la ua y anio que ingresa como argumento
insert into auxiliar

                        select distinct c.agente,c.id_docente,c.legajo,null,c.id_designacion,c.nro_540,c.cat_mapuche,c.cat_estat,c.carac,case when id_novedad is not null then 'L' else estado end,id_departamento,id_area,id_orientacion,null,null,null,null,null,null from     
                       (select distinct t_pe.anio,t_pe.fecha_inicio,t_pe.fecha_fin,t_d.id_docente,t_d.id_designacion,t_d.nro_540,t_d.cargo_gestion,t_d.uni_acad,t_d.id_departamento,t_d.id_area,t_d.id_orientacion,t_do.apellido||', '||t_do.nombre as agente,t_do.legajo,t_d.carac,t_d.cat_mapuche,trim(t_d.cat_estat)||t_d.dedic as cat_estat,t_d.desde,t_d.hasta,t_d.estado   
                            from designacion t_d , docente t_do, mocovi_periodo_presupuestario t_pe
                            where t_d.id_docente=t_do.id_docente
                            and (t_d.desde <=t_pe.fecha_fin and (t_d.hasta>=t_pe.fecha_inicio or t_d.hasta is null))
                            and t_pe.anio=annio
                            and uni_acad=uni
                            and (hasta is null or (desde<hasta))
                            and not exists (select * from novedad t_n
                                            where t_d.id_designacion=t_n.id_designacion
                                            and t_n.tipo_nov in (1,4)))c
             	      LEFT OUTER JOIN novedad t_n ON (c.id_designacion=t_n.id_designacion and t_n.tipo_nov in (2,3,5)
                                             and t_n.desde <=c.fecha_fin and (t_n.hasta>=c.fecha_inicio or t_n.hasta is null))            ;
  

  	FOR reg IN--para cada designacion
 		select * from auxiliar
	LOOP
	     i:=1;
	     
	     FOR reg2 IN --busco todas las materias que tenga en ese anio
	        select  d.cod_carrera||'-'||trim(c.desc_materia)||'-'||e.descripcion||'-'||case when b.rol='EC' then 'Res' else 'Aux' end ||'-'||case when b.modulo in (1,2,3,4,5,6) then 'mod'||b.modulo else case when b.modulo=7 then 'c1m1'else case when b.modulo=8 then 'c1m2' else case when b.modulo=9 then 'c2m1' else 'c2m2' end end end end as det
 		from asignacion_materia b,materia c,plan_estudio d,periodo e
 		where b.id_materia=c.id_materia
 		and c.id_plan=d.id_plan
 		and b.id_periodo=e.id_periodo
 		and b.id_designacion=reg.id_designacion
 		and b.anio=annio
 		order by e.descripcion,b.modulo
 		
 	     LOOP
 	       if i<=6 then --solo muestra las 6 primeras
 		CASE i
 			WHEN 1 THEN update auxiliar set mat0=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 2 THEN update auxiliar set mat1=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 3 THEN update auxiliar set mat2=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 4 THEN update auxiliar set mat3=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 5 THEN update auxiliar set mat4=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 6 THEN update auxiliar set mat5=reg2.det where id_designacion=reg.id_designacion;
 			
 		END CASE;
 		end if;
 		i:=i+1;
 	     END LOOP;
 	     
	END LOOP;
	
  	FOR reg IN--para cada designacion veo que titulos tiene
 		select * from auxiliar
	LOOP
	 detalle:='';
	   FOR reg2 IN --busco todos los titulos
	       select desc_titul 
	       from titulos_docente t_d, titulo t_t 
                 where t_d.id_docente=reg.id_docente
                 and t_d.codc_titul=t_t.codc_titul
 		
 	     LOOP
 	     detalle:=detalle||reg2.desc_titul;
 	     detalle=detalle||'/';
 	    END LOOP;
 	    update auxiliar set titulos=detalle where id_designacion=reg.id_designacion;
	END LOOP;

return 1;
END; 
$_$;


ALTER FUNCTION public.anexo2(integer, character) OWNER TO postgres;

--
-- Name: arma_link(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.arma_link(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	iddesig		integer;
  	salida		text;
  	pdia		date;
  	udia		date;

BEGIN
iddesig=$1;


salida='';

select into salida case when a.id_norma is null then '' else case when b.link is not null or b.link <>'' then '<a href='||chr(39)||b.link||chr(39)|| ' target='||chr(39)||'_blank'||chr(39)||'>'||b.nro_norma||'</a>' else cast(nro_norma as text) end end
from designacion a
LEFT OUTER JOIN norma b ON (a.id_norma=b.id_norma)
where a.id_designacion=iddesig;



return salida;
END; 
$_$;


ALTER FUNCTION public.arma_link(integer) OWNER TO postgres;

--
-- Name: busca_norma(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.busca_norma(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	idnove		integer;
  	cadena		text;
  	subcadena	text;
  	subcadena_anio	text;
  	pdia		date;
  	udia		date;
  	i		integer;
  	long		integer;
  	band 		boolean;
  	num_norma	integer;
  	tipo		character(5);
	emite		character(4);  	
	uni		character(4);
	anio		integer;
	enlace		text;
	enlace2		text;
	prueba		integer;
	

BEGIN
idnove=$1;
i=1;
enlace='';
cadena='';
subcadena='';
subcadena_anio='';
band=true;


select into cadena,tipo,emite,uni trim(norma_legal), tipo_norma,tipo_emite,b.uni_acad
from novedad a
left outer join designacion b on (a.id_designacion=b.id_designacion)
where a.id_novedad=idnove;

long=length(cadena);


--corta cuando encuentra un caracter que no es digito, extrae los primero 4 que son el numero de norma
WHILE i<=long and band LOOP--cuando encuentra un caracter que no es digito entonces corta
  if textregexeq(substring(cadena,i,1),'^[[:digit:]]+?$') then--si el caracter es un digito
    subcadena=subcadena||substring(cadena,i,1);                      
  else                              
     band=false;                    
  end if;                           
  i=i+1;       
END LOOP;	                    

--prueba=length(subcadena);
if band then 
end if;

--si la band es true es porque no encontro caracteres (solo encontro digitos)
if(length(subcadena)=4 and not band)then
        band=true;
 	num_norma=cast(subcadena as integer);                                    --esto le saca los ceros de adelante
        band=true;
 	WHILE i<=long and band LOOP --recupera el anio de la norma
 		if textregexeq(substring(cadena,i,1),'^[[:digit:]]+?$') then--si el caracter es un digito
    			subcadena_anio=subcadena_anio||substring(cadena,i,1);
  		else                              
     			band=false;                    
  		end if;                           
 		i=i+1;
 	END LOOP;
 	if (band) then
    		anio=cast(subcadena_anio as integer);                                    --esto le saca los ceros de adelante
    		select into enlace2 case when link is not null then link else '' end  from norma t_n--si el select no trae nada entonces enlace2 es nulo
    		where nro_norma=num_norma 
    		and tipo_norma =tipo
    		and emite_norma=emite 
    		and extract(year from fecha)=anio 
    		and uni_acad=uni;
        	if enlace2 is not null then
        		enlace=enlace2;
        	end if;
	
        end if;	     


end if;


return enlace;                        

END;                                
$_$;


ALTER FUNCTION public.busca_norma(integer) OWNER TO postgres;

--
-- Name: calculo_conjunto(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculo_conjunto(integer, integer, integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  
  mat		integer;
  per		integer;
  annio		integer;
  reg		record;
  conj		integer;
  salida          text;
  

BEGIN

  mat=$1;
  per=$2;
  annio=$3;
  conj=0;
  salida='';
  
    --si esa materia para ese anio y ese periodo esta en un conjunto entonces muestro todo lo que tiene
    --FOR reg IN  
	select  a.id_conjunto into conj from en_conjunto a, conjunto b, mocovi_periodo_presupuestario c
	where a.id_materia=mat
	and a.id_conjunto=b.id_conjunto
	and b.id_periodo=per
	and b.id_periodo_pres=c.id_periodo
	and c.anio=annio;
	if(conj is not null) then
		FOR reg IN select t_p.cod_carrera||'-'||t_m.desc_materia||'('||cod_siu||')' as desc 
			from en_conjunto t_e, materia t_m, plan_estudio t_p
			where t_e.id_conjunto=conj
			and t_e.id_materia=t_m.id_materia
			and t_m.id_plan=t_p.id_plan
			LOOP
			salida=salida||reg.desc;
			salida=salida||chr(13);
		END LOOP;		
	end if;


  return salida;
  
END;
$_$;


ALTER FUNCTION public.calculo_conjunto(integer, integer, integer) OWNER TO postgres;

--
-- Name: calculo_cuil(character, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculo_cuil(character, integer) RETURNS character
    LANGUAGE plpgsql
    AS $_$
DECLARE
  str           character(11);
  doc2          character(11);
  i             integer;
  len           integer;
  z             integer;
  m             integer;
  sexo          character(1);
  sum           integer;
  xy            integer;
  k             integer;
  doc 		integer;
  arreglo       integer[10];
  

BEGIN

  sexo=$1;
  doc=$2;
  arreglo=array[5,4,3,2,7,6,5,4,3,2];
  
  if sexo='M' then --masculino
     xy:=20;
  else 
     xy=27;
  end if;
     
  
  
  doc2:=doc;
  
  if length(doc::text)<8 then  --si el docum tiene menos de 8 digitos entonces lo rellena con ceros
     i := 1;
     WHILE i <= (8-length(doc::text)) LOOP
     	doc2:='0'||doc2;
     	i := i + 1;
     END LOOP;
	
  end if;  
    
  str:= cast(xy as text)||cast(doc2 as text);
 
  len := length(str);
  
  sum:=0;
  i := 1;
   
  WHILE i <= len LOOP
  	--select into m a from auxi where indic=i;
  	--sum:=sum+ (cast (substr(str, i, 1) as numeric (1,0)) * m);
  	sum:=sum+ (cast (substr(str, i, 1) as numeric (1,0)) * arreglo[i]);
  	i := i + 1;
  END LOOP;
	
  select into k mod (sum,11);
  
  if k =0 then
    z:=0;
  else
    if k<>1 then
      z:=11-k;
    else 
        if sexo='M' then 
           z:=9;
           xy:=23;
        else 
          z:=4;
          xy:=23;  
        end if;
    end if; 
  end if;  
  
  
  return xy||'-'||doc2||'-'||z;
  
END;
$_$;


ALTER FUNCTION public.calculo_cuil(character, integer) OWNER TO postgres;

--
-- Name: control_actividad(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.control_actividad(integer, integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
DECLARE
  annio		integer;
  pdiames	date;      
  udiames	date;
  id_desig	integer;
  tipo		integer;
  band		boolean;
  baja		integer;
  mate		integer;
  otro		integer;
  inv		integer;
  ext		integer;
  segundo	integer;
  tercero	integer;
  id_doc	integer;
  dire		integer;

BEGIN
band:=true;
id_desig:=$1;
annio:=$2;
mate:=0;
otro:=0;
dire:=0;

CREATE LOCAL TEMP TABLE vincu(
  dato		integer
);

--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

select into tipo,baja,id_doc d.tipo_desig,case when id_novedad is null then 0 else 1 end as b,d.id_docente 
 from designacion d
 left outer join novedad n on (d.id_designacion=n.id_designacion and n.tipo_nov in (1,4) and n.desde<=udiames and n.desde>=pdiames) 
 where d.id_designacion=id_desig; 
if tipo=1 then--es una designacion 
   if baja=0 then --no tiene baja
   	select into mate case when a.id_materia is not null then 1 else 0 end as mat from asignacion_materia a where a.id_designacion=id_desig and anio=annio ;
   	if mate=0 or mate is null then --sino tiene materia se fija si tiene otras actividades. Se hace null cuando no encuentra ningun registro en el select anterior
   	
   		select into otro case when a.id_tutoria is not null then 1 else 0 end as ot from asignacion_tutoria a where a.id_designacion=id_desig and anio=annio ;
   		if otro=0 or otro is null then--sino tiene otras actividades se fija si es director departamento
   		     select into dire iddepto from director_dpto a where a.id_docente=id_doc and desde<=udiames and hasta>=pdiames ;
   		     if dire=0 or dire is null then--sino es director de departamento dentro del periodo
   		     
   			--busco los vinculos de la designacion 
   		     	insert into vincu (dato) values(id_desig);--inserta el primero
	     	     	select vinc into segundo from vinculo where desig=id_desig;--
	     	     	if segundo is not null then
 		     		insert into vincu(dato) values(segundo); 
 		     		select vinc into tercero from vinculo where desig=segundo;
 		     		if tercero is not null then 
 		   			insert into vincu(dato) values(tercero); 
 		     		end if;
             	     	end if;
   		     	select into inv c.id_pinv
 				from integrante_interno_pi b,pinvestigacion c
 				where c.id_pinv=b.pinvest 
 				--and b.hasta=c.fec_hasta --si esta hasta el fin del proyecto lo coloco y sino no
 				and b.desde<=udiames and b.hasta >=pdiames --la participacion en el proyecto entra en el periodo
 				and b.id_designacion in(select dato from vincu) ;
   		    	if inv=0 or inv is null then--sino tiene investigacion me fijo en extension
   		        	select into ext c.id_pext
 				from integrante_interno_pe b,pextension c
 				where c.id_pext=b.id_pext 
 				--and b.hasta=c.fec_hasta --si esta hasta el fin del proyecto lo coloco y sino no
 				and b.desde<=udiames and b.hasta >=pdiames --la participacion en el proyecto entra en el periodo
 				and b.id_designacion in(select dato from vincu) ;
 				if ext=0 or ext is null then
 			  		band=false;
 				end if;
   		    	
   		    	end if;
   		   end if;--director    
   		end if;--otras
   	end if;--materias
   	
   end if;--tiene baja
end if;--tipo<>1

return band;
END; 
$_$;


ALTER FUNCTION public.control_actividad(integer, integer) OWNER TO postgres;

--
-- Name: costo_reserva(integer, numeric, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.costo_reserva(integer, numeric, integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	costo		numeric;
  	costoreserva	numeric;
  	salida		numeric;
  	idreserva	integer;
  	annio		integer;
  	pdia		date;
  	udia		date;
  	
BEGIN
idreserva=$1;
costoreserva=$2;
annio=$3;
salida=0;

--primer dia del periodo correspondiente al año que ingresa
pdia:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udia:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

--hay que enviarle el año para que calcule el costo en ese año

select into costo sum(case when (dias_des-dias_lic)>=0 then (dias_des-dias_lic)*costo_diario*porc/100 else 0 end )  from 
(SELECT distinct t_d.id_designacion,porc, costo_diario,
                         sum(case when t_no.id_novedad is null then 0 else (case when (t_no.desde>udia or (t_no.hasta is not null and t_no.hasta<pdia)) then 0 else (case when t_no.desde<=pdia then ( case when (t_no.hasta is null or t_no.hasta>=udia ) then (((cast(udia as date)-cast(udia as date))+1)) else ((t_no.hasta-pdia)+1) end ) else (case when (t_no.hasta is null or t_no.hasta>=udia ) then (((udia)-t_no.desde+1)) else ((t_no.hasta-t_no.desde+1)) end ) end )end)*t_no.porcen end) as dias_lic,
                        case when t_d.desde<=pdia then ( case when (t_d.hasta>=udia or t_d.hasta is null ) then (((cast(udia as date)-cast(pdia as date))+1)) else ((t_d.hasta-pdia)+1) end ) else (case when (t_d.hasta>=udia or t_d.hasta is null) then (((udia)-t_d.desde+1)) else ((t_d.hasta-t_d.desde+1)) end ) end as dias_des 
                            FROM designacion as t_d 
                            LEFT OUTER JOIN novedad t_no ON (t_d.id_designacion=t_no.id_designacion and t_no.tipo_nov in (2,5) and t_no.tipo_norma is not null 
                           					and t_no.tipo_emite is not null 
                           					and t_no.norma_legal is not null 
                           					and t_no.desde<=udia and t_no.hasta>=pdia)
                            LEFT OUTER JOIN mocovi_periodo_presupuestario m_e ON (m_e.anio=annio)
 			    LEFT OUTER JOIN mocovi_costo_categoria as m_c ON (t_d.cat_mapuche = m_c.codigo_siu and m_c.id_periodo=m_e.id_periodo) 
 			    LEFT OUTER JOIN imputacion as t_t ON (t_d.id_designacion = t_t.id_designacion) 
 			    LEFT OUTER JOIN mocovi_programa as m_p ON (t_t.id_programa = m_p.id_programa)                        					
                            
                        WHERE  t_d.tipo_desig=1
                        and t_d.id_designacion in (select id_designacion from reserva_ocupada_por 
                                                   where id_reserva=idreserva) 
                                                  
                        GROUP BY t_d.id_designacion,t_d.desde,t_d.hasta,costo_diario,porc) sub;
 if costo is null then--la reserva no tiene designaciones asociadas 
    salida=costoreserva;
 else
   if costoreserva>=costo then
    	salida=costoreserva-costo;   
   else
   	salida=0;
   end if; 
 end if;

return salida;
END; 
$_$;


ALTER FUNCTION public.costo_reserva(integer, numeric, integer) OWNER TO postgres;

--
-- Name: dedicacion_horas(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dedicacion_horas(integer, character) RETURNS date
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      character(4);
  annio		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  segundo	integer;
  tercero	integer;
  canti		integer;
  semanas_desig integer;

BEGIN
annio:=$1;
uni:=$2;


--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);



CREATE LOCAL TEMP TABLE auxiliar
(
  id_docente		integer,
  agente		character(40),
  legajo		integer,
  id_designacion      	integer,
  desde			date,
  hasta			date,
  dias_trab		integer,--dias trabajados
  hs_mat 		integer,
  hs_desig		integer,--cantidad de hs correspondiente a la dedicacion
  hs_pe			integer,
  hs_pi			integer,
  hs_post		integer,
  hs_tut		integer,
  hs_otros		integer
  
  );
  
CREATE LOCAL TEMP TABLE vincu(
  dato		integer
);
insert into auxiliar

                        --select a.agente,a.legajo,a.id_designacion,desde,hasta,sum(t_a.carga_horaria*case when (t_a.id_periodo=1 or t_a.id_periodo=2) then 16 else case when (t_a.id_periodo=3 or t_a.id_periodo=4) then 32 else case when (t_a.id_periodo=5) then 8 else case when (t_a.id_periodo=6) then 4 else case when (t_a.id_periodo=8 or t_a.id_periodo=9) then 24 end end end end end )/case when (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365)=0 then 1 else (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365) end as hs_mat, case when dedic=1 then 40 else case when dedic=2 then 20 else case when dedic=3 then 10 else 0 end end end  as hs_desig
                        select a.id_docente,a.agente,a.legajo,a.id_designacion,desde,hasta,case when (dias_des-dias_lic)<0 then 0 else dias_des-dias_lic end as dias_trab,sum(t_a.carga_horaria*case when (t_a.id_periodo=1 or t_a.id_periodo=2) then 16 else case when (t_a.id_periodo=3 or t_a.id_periodo=4) then 32 else case when (t_a.id_periodo=10 or t_a.id_periodo=11 or t_a.id_periodo=12 or t_a.id_periodo=13) then 5 else case when (t_a.id_periodo=6) then 2 else case when (t_a.id_periodo=8 or t_a.id_periodo=9) then 16 end end end end end )/case when (((case when hasta is null then fecha_fin else case when hasta>fecha_fin then fecha_fin else hasta end end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365)=0 then 1 else (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365) end as hs_mat
                        , (case when dedic=1 then 40 else case when dedic=2 then 20 else case when dedic=3 then 10 else 0 end end end)*(dias_des-dias_lic)/365  as hs_desig
                        from
                        (   select b.*,(case when b.hasta is null then fecha_fin else case when b.hasta>fecha_fin then fecha_fin else b.hasta end end) -(case when b.desde<fecha_inicio then fecha_inicio else b.desde end )+1 as dias_des 
                            ,case when sum((n.hasta-n.desde)+1) is null then 0 else sum((n.hasta-n.desde)+1) end as dias_lic
                            from (
                            select t_pe.anio,t_pe.fecha_inicio,t_pe.fecha_fin,t_d.id_designacion,t_d.uni_acad,t_d.id_departamento,t_d.id_area,t_d.id_orientacion,t_do.id_docente,t_do.apellido||', '||t_do.nombre as agente,t_do.legajo,t_d.carac,t_d.cat_mapuche,t_d.dedic,t_d.desde,t_d.hasta  
                            from designacion t_d , docente t_do, mocovi_periodo_presupuestario t_pe
                            where t_d.id_docente=t_do.id_docente
                            and (t_d.desde <=t_pe.fecha_fin and (t_d.hasta>=t_pe.fecha_inicio or t_d.hasta is null))
                            and t_d.tipo_desig=1
                            and not(t_d.hasta is not null and t_d.desde>t_d.hasta)--descarto si la anularon
                            )b 
                            LEFT OUTER JOIN novedad n ON (b.id_designacion=n.id_designacion and n.tipo_nov in(2,3,5) and n.desde <=udiames and n.hasta>=pdiames)
                            where b.uni_acad=uni and b.anio=annio
                          group by anio,fecha_inicio,fecha_fin,b.id_designacion,uni_acad,id_departamento,id_area,id_orientacion,id_docente,agente,legajo,carac,cat_mapuche,dedic,b.desde,b.hasta
                        )a 
                        LEFT OUTER JOIN asignacion_materia t_a ON (a.id_designacion=t_a.id_designacion and t_a.anio=a.anio)
                        group by a.id_docente,a.agente,a.legajo,a.id_designacion,hasta,desde,fecha_fin,fecha_inicio,dedic,dias_des,dias_lic;
                         
--proyectos de investigacion                        
FOR reg IN
    select * from auxiliar --para cada designacion calculo la cantidad de horas en investigacion dentro de ese periodo
    LOOP
   insert into vincu (dato) values(reg.id_designacion);--inserta el primero
   select vinc into segundo from vinculo where desig=reg.id_designacion;--
   if segundo is not null then
	insert into vincu(dato) values(segundo); 
	select vinc into tercero from vinculo where desig=segundo;
	if tercero is not null then
		insert into vincu(dato) values(tercero); 
	end if;
   end if;

--saca un promedio cuando tiene periodos entrecortados con cantidad de horas distintas 
 --calcula las semanas correspondientes a los dias trabajados
 --semanas_desig=reg.dias_trab*32/365;
 --if semanas_desig=0 then
   --  semanas_desig=1;
 --end if; 
 --cantidad de dias de la designacion pasado a semanas (no considero aqui los dias de licencia porque en investigacion no importaria)
 if reg.desde<pdiames then
    if reg.hasta is null or reg.hasta>udiames then 
       semanas_desig=(udiames-pdiames)*32/365;                                 
    else
       semanas_desig=(reg.hasta-pdiames)*32/365;
    end if;
 else    
    if reg.hasta is null or reg.hasta>udiames then 
       semanas_desig=(udiames-reg.desde)*32/365;
    else
       semanas_desig=(reg.hasta-reg.desde)*32/365;
    end if;
 end if;
 
 select sum((((case when b.hasta is null then udiames else case when b.hasta>udiames then udiames else hasta end end )-(case when b.desde<pdiames then pdiames else b.desde end))*32/365)*carga_horaria)/semanas_desig into canti 
 from  integrante_interno_pi b 
 where b.id_designacion in(select dato from vincu) 
 and b.desde<=udiames and b.hasta >=pdiames
  ;
 
 update auxiliar set hs_pi=canti where id_designacion=reg.id_designacion;	
 delete from vincu;
END LOOP;

----proyectos de extension
FOR reg IN
 select a.id_designacion,(sum((b.hasta-b.desde)/7*carga_horaria))/sum((b.hasta-b.desde)/7) as cant 
 from auxiliar a, integrante_interno_pe b 
 where a.id_designacion=b.id_designacion 
 and b.desde<=udiames and b.hasta >=pdiames 
 group by a.id_designacion
LOOP
update auxiliar set hs_pe=reg.cant where id_designacion=reg.id_designacion;	
END LOOP;
--postgrados
FOR reg IN
  select a.id_designacion,sum(t_a.carga_horaria*case when (t_a.periodo=1 or t_a.periodo=2) then 16 else case when (t_a.periodo=3 or t_a.periodo=4) then 32 else case when (t_a.periodo=5) then 8 else case when (t_a.periodo=6) then 4 else case when (t_a.periodo=8 or t_a.periodo=9) then 24 end end end end end )
/case when (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365)=0 then 1 else (((case when hasta is null then fecha_fin else hasta end )-(case when desde<fecha_inicio then fecha_inicio else desde end))*32/365) end as cant
 from auxiliar a, asignacion_tutoria t_a, mocovi_periodo_presupuestario t_pe where 
  a.id_designacion=t_a.id_designacion and t_a.anio=annio and t_a.rol='POST' and (a.desde <=t_pe.fecha_fin and (a.hasta>=t_pe.fecha_inicio or a.hasta is null))
  and t_pe.anio=annio
group by a.id_designacion ,hasta,desde,fecha_fin,fecha_inicio
LOOP
update auxiliar set hs_post=reg.cant where id_designacion=reg.id_designacion;	
END LOOP;
         
----tutorias
FOR reg IN
  select a.id_designacion,sum(t_a.carga_horaria*case when (t_a.periodo=1 or t_a.periodo=2) then 16 else case when (t_a.periodo=3 or t_a.periodo=4) then 32 else case when (t_a.periodo=10 or t_a.periodo=11 or t_a.periodo=12 or t_a.periodo=13) then 5 else case when (t_a.periodo=6) then 2 else case when (t_a.periodo=8 or t_a.periodo=9) then 16 end end end end end )
/case when (a.dias_trab*32/365)=0 then 1 else a.dias_trab*32/365 end  as cant
 from auxiliar a, asignacion_tutoria t_a
 where 
  a.id_designacion=t_a.id_designacion and t_a.anio=annio and (t_a.rol='COOR' or t_a.rol='TUTO')
  
group by a.id_designacion, a.dias_trab
LOOP
update auxiliar set hs_tut=reg.cant where id_designacion=reg.id_designacion;	
END LOOP;
         
----otros
FOR reg IN
   
  select a.id_designacion,
    sum(t_a.carga_horaria*case when (t_a.periodo=1 or t_a.periodo=2) then 16 else case when (t_a.periodo=3 or t_a.periodo=4) then 32 else case when (t_a.periodo=10 or t_a.periodo=11 or t_a.periodo=12 or t_a.periodo=13) then 5 else case when (t_a.periodo=6) then 2 else case when (t_a.periodo=8 or t_a.periodo=9) then 16 end end end end end  )
     /case when (a.dias_trab*32/365)=0 then 1 else a.dias_trab*32/365 end as cant
   from auxiliar a, asignacion_tutoria t_a 
   where  a.id_designacion=t_a.id_designacion and t_a.anio=annio and t_a.rol='OTRO' 
  group by a.id_designacion, a.dias_trab
LOOP
update auxiliar set hs_otros=reg.cant where id_designacion=reg.id_designacion;	
END LOOP;                        
return udiames;
END; 
$_$;


ALTER FUNCTION public.dedicacion_horas(integer, character) OWNER TO postgres;

--
-- Name: estado_desig(integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.estado_desig(integer, date, date) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	iddesig		integer;
  	salida		text;
  	pdia		date;
  	udia		date;

BEGIN
iddesig=$1;
pdia=$2;
udia=$3;

salida='';

select into salida case when b.id_novedad is not null then 'B' else case when c.id_novedad is not null then 'L' else a.estado end end 
from designacion a
LEFT OUTER JOIN novedad b ON (a.id_designacion=b.id_designacion and b.tipo_nov in (1,4))
LEFT OUTER JOIN novedad c ON (a.id_designacion=c.id_designacion and c.tipo_nov in (2,5) and c.desde <= udia and (c.hasta >= pdia or c.hasta is null))
where a.id_designacion=iddesig;



return salida;
END; 
$_$;


ALTER FUNCTION public.estado_desig(integer, date, date) OWNER TO postgres;

--
-- Name: excepcion_area(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.excepcion_area(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  id_desig	integer;
  reg		record;
  primera	boolean;
  areaa		text;
  textoa	text;
 

BEGIN
id_desig=$1;
textoa='';
primera=true;


FOR reg IN select distinct * from
	(select de.descripcion as dpto,ar.descripcion as are,ori.descripcion as orient from designacion d
           left outer join departamento de on (d.id_departamento=de.iddepto)
           left outer join area ar on (d.id_area=ar.idarea  ) 
           left outer join orientacion ori on ( ori.idorient=d.id_orientacion and ori.idarea=ar.idarea) 
           where d.id_designacion=id_desig   
            UNION
           select d.descripcion as dpto,ar.descripcion as are,ori.descripcion as orient from dao_designa a 
	   left outer join departamento d on (a.id_departamento=d.iddepto )
	   left outer join area ar on (a.id_area=ar.idarea  ) 
	   left outer join orientacion ori on ( ori.idorient=a.id_orientacion and ori.idarea=a.id_area) 
	   where a.id_designacion=id_desig
	   )sub
	   order by dpto,are,orient
	
 	LOOP
 	if primera then 
 		areaa=reg.are;
 		textoa=reg.are;
 		primera=false;
 	end if;
 	if not primera then
 		if reg.are<>areaa then 
 		        areaa=reg.are;
 			textoa=textoa||'/'||reg.are;
 		end if;
 	end if;
END LOOP;


return textoa;
END; 
$_$;


ALTER FUNCTION public.excepcion_area(integer) OWNER TO postgres;

--
-- Name: excepcion_departamento(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.excepcion_departamento(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  id_desig	integer;
  reg		record;
  primera	boolean;
--  arr 		text[];
  
  dep		text;
  textod	text;
  
BEGIN
id_desig:=$1;
textod:='';
primera:=true;


FOR reg IN select distinct * from
	(select de.descripcion as dpto,ar.descripcion as desc_are,ori.descripcion as desc_orien from designacion d
           left outer join departamento de on (d.id_departamento=de.iddepto)
           left outer join area ar on (d.id_area=ar.idarea  ) 
           left outer join orientacion ori on ( ori.idorient=d.id_orientacion and ori.idarea=d.id_area) 
           where d.id_designacion=id_desig   
            UNION
           select d.descripcion as dpto,ar.descripcion as are,ori.descripcion as orienta from dao_designa a 
	   left outer join departamento d on (a.id_departamento=d.iddepto )
	   left outer join area ar on (a.id_area=ar.idarea ) 
	   left outer join orientacion ori on ( ori.idorient=a.id_orientacion and ori.idarea=a.id_area) 
	   where a.id_designacion=id_desig
	   )sub
	   order by dpto,desc_are,desc_orien
	LOOP
 	if primera then 
 		dep=reg.dpto;
 		textod=reg.dpto;
 		primera=false;
 	end if;
 	if not primera then
 		if reg.dpto<>dep then 
 			textod=textod||'/'||reg.dpto;
 		end if;
 	end if;
END LOOP;

--arr[0]=textod;
--arr[1]=textoa;
--arr[2]=textoo;
return textod;
END; 
$_$;


ALTER FUNCTION public.excepcion_departamento(integer) OWNER TO postgres;

--
-- Name: excepcion_orientacion(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.excepcion_orientacion(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  id_desig	integer;
  reg		record;
  primera	boolean;
  orienta	text;
  textoo	text;
 

BEGIN
id_desig=$1;
textoo='';
primera=true;


FOR reg IN select distinct * from
	(select de.descripcion as dpto,ar.descripcion as are,ori.descripcion as orient from designacion d
           left outer join departamento de on (d.id_departamento=de.iddepto)
           left outer join area ar on (ar.idarea=d.id_area ) 
           left outer join orientacion ori on ( ori.idorient=d.id_orientacion and ori.idarea=d.id_area) 
           where d.id_designacion=id_desig   
            UNION
           select d.descripcion as dpto,ar.descripcion as are,ori.descripcion as orient from dao_designa a 
	   left outer join departamento d on (a.id_departamento=d.iddepto )
	   left outer join area ar on (ar.idarea=a.id_area  ) 
	   left outer join orientacion ori on ( ori.idorient=a.id_orientacion and ori.idarea=a.id_area) 
	   where a.id_designacion=id_desig
	   )sub
	   order by dpto,are,orient
	
 	LOOP
 	if primera then 
 		orienta=reg.orient;
 		textoo=reg.orient;
 		primera=false;
 	end if;
 	if not primera then
 		if reg.orient<>orienta then 
 		        orienta=reg.orient;
 			textoo=textoo||'/'||reg.orient;
 		end if;
 	end if;
END LOOP;


return textoo;
END; 
$_$;


ALTER FUNCTION public.excepcion_orientacion(integer) OWNER TO postgres;

--
-- Name: informe_actividad(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.informe_actividad(integer, character) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      	character(4);
  annio		integer;
  i		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  reg2		record;
  detalle       text;  
  segundo	integer;
  tercero	integer;
  auxi		text;

BEGIN
annio:=$1;
uni:=$2;
--primer dia del periodo correspondiente al año que ingresa
pdiames:=  CAST ('01'  || '/' || '02' || '/' ||annio AS DATE);
--ultimo dia del periodo correspondiente al año que ingresa
udiames:=  CAST ( '31' || '/' || '01' || '/' ||(annio+1) AS DATE);

CREATE LOCAL TEMP TABLE auxiliar
(
  agente		character(40),
  id_docente		integer,
  legajo		integer,
  id_designacion      	integer,
  desde			date,
  hasta			date,
  nro_540		integer,
  cat_mapu		character(4),
  cat_estat		character(8),
  carac			character(1),
  id_departamento	integer,
  id_area		integer,
  id_orientacion	integer,
  estado		character(1),
  desc_estado		text,--esto para colocar el periodo de la licencia/cese
  mat0			text,
  mat1			text,
  mat2			text,
  mat3			text,
  mat4			text,
  mat5			text,
  gestion		text,
  investig		text,
  extens		text,
  postgrado		text,
  tutorias		text,
  otros			text
  
  );

CREATE LOCAL TEMP TABLE vincu(
  dato		integer
);


--primero recupero todas las designaciones correspondientes a la ua y anio que ingresa como argumento
insert into auxiliar
			select d.agente,d.id_docente,d.legajo,d.id_designacion,d.desde,d.hasta,d.nro_540,cat_mapuche,cat_estat,carac,id_departamento,id_area,id_orientacion, case when t_nov.tipo_nov in (1,4) then 'B' else case when t_nov.tipo_nov in (2,5) then 'L' else d.estado end end as estado,null,null,null,null,null,null,null,gest,null,null,null,null,null from 
                        (select distinct anio,fecha_inicio,fecha_fin,id_docente,c.id_designacion,nro_540,cargo_gestion,uni_acad,id_departamento,id_area,id_orientacion,agente,legajo,carac,cat_mapuche, cat_estat,c.desde,c.hasta,estado,gest,max(t_no.id_novedad) as id_novedad from    
                       (select distinct t_pe.anio,t_pe.fecha_inicio,t_pe.fecha_fin,t_d.id_docente,t_d.id_designacion,t_d.nro_540,t_d.cargo_gestion,t_d.uni_acad,t_d.id_departamento,t_d.id_area,t_d.id_orientacion,t_do.apellido||', '||t_do.nombre as agente,t_do.legajo,t_d.carac,t_d.cat_mapuche,trim(t_d.cat_estat)||t_d.dedic as cat_estat,t_d.desde,t_d.hasta,t_d.estado,cargo_gestion||'('||emite_cargo_gestion||case when ord_gestion is not null then ord_gestion else '' end||')' as gest
                            from designacion t_d 
                            LEFT OUTER JOIN docente t_do ON (t_d.id_docente=t_do.id_docente)
                            LEFT OUTER JOIN  mocovi_periodo_presupuestario t_pe ON (t_pe.anio=annio )
                            where  (t_d.desde <=t_pe.fecha_fin and (t_d.hasta>=t_pe.fecha_inicio or t_d.hasta is null))
                            and t_d.tipo_desig=1
                            and t_pe.anio=annio
                            and uni_acad=uni
                            and (t_d.hasta is null or (t_d.desde<t_d.hasta))--no esta anulada
                            )c
                             LEFT OUTER JOIN novedad t_no ON (c.id_designacion=t_no.id_designacion and t_no.desde<=udiames and t_no.desde>=pdiames)--solo fecha desde porque las bajas no tienen hasta
                             group by anio,fecha_inicio,fecha_fin,id_docente,c.id_designacion,nro_540,cargo_gestion,uni_acad,id_departamento,id_area,id_orientacion,agente,legajo,carac,cat_mapuche, cat_estat,c.desde,c.hasta,estado,gest
                             )d
                              LEFT OUTER JOIN novedad t_nov ON (t_nov.id_novedad=d.id_novedad)
             	        order by agente           ;
  

  	FOR reg IN--para cada designacion
 		select * from auxiliar
	LOOP
	     if reg.estado='L' then 
	        auxi=' Licencia ';
	     	FOR reg2 IN select to_char(desde, 'DD/MM/YYYY') as desde,to_char(hasta, 'DD/MM/YYYY') as hasta from novedad 
	     		    where id_designacion=reg.id_designacion
	     		    and tipo_nov in (2,3,5) and desde <=udiames and hasta>=pdiames
	     	LOOP
	          auxi:=auxi||' desde:'||reg2.desde||' hasta:'||reg2.hasta||' ' ;
	     
	     	END LOOP;
	     	update auxiliar set desc_estado=auxi where id_designacion=reg.id_designacion;
	     end if;
	     
	     i:=1;
	     
	     FOR reg2 IN --busco todas las materias que tenga en ese anio
	        --select  trim(c.desc_materia)||'-'||d.cod_carrera||'-'||case when b.rol='EC' then 'Res' else 'Aux' end ||'-'||e.descripcion||'('||case when b.carga_horaria is not null then b.carga_horaria else 0 end||'hs)'||case when b.modulo in (1,2,3,4,5,6) then 'mod'||b.modulo else case when b.modulo=7 then 'c1m1'else case when b.modulo=8 then 'c1m2' else case when b.modulo=9 then 'c2m1' else 'c2m2' end end end end as det
	        select  materias_conjunto(b.anio,b.id_periodo,uni,b.id_materia)||'-'||case when b.rol='EC' then 'Res' else 'Aux' end ||'-'||e.descripcion||'('||case when b.carga_horaria is not null then b.carga_horaria else 0 end||'hs)'||case when b.modulo in (1,2,3,4,5,6) then 'mod'||b.modulo else case when b.modulo=7 then 'c1m1'else case when b.modulo=8 then 'c1m2' else case when b.modulo=9 then 'c2m1' else 'c2m2' end end end end as det
 		from asignacion_materia b,materia c,plan_estudio d,periodo e
 		where b.id_materia=c.id_materia
 		and c.id_plan=d.id_plan
 		and b.id_periodo=e.id_periodo
 		and b.id_designacion=reg.id_designacion
 		and b.anio=annio
 		order by e.descripcion,b.modulo
 		
 	     LOOP
 	       if i<=6 then --solo muestra las 6 primeras
 		CASE i
 			WHEN 1 THEN update auxiliar set mat0=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 2 THEN update auxiliar set mat1=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 3 THEN update auxiliar set mat2=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 4 THEN update auxiliar set mat3=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 5 THEN update auxiliar set mat4=reg2.det where id_designacion=reg.id_designacion;
 			WHEN 6 THEN update auxiliar set mat5=reg2.det where id_designacion=reg.id_designacion;
 			
 		END CASE;
 		end if;
 		i:=i+1;
 	     END LOOP;
 	     
	END LOOP;
	
  	--para cada designacion veo si tiene proyectos de investigacion vigentes en el anio que ingresa
  	--toma el ultimo movimiento
  	--no importa de que facultad es el proyecto
  	FOR reg IN
 		select * from auxiliar
	LOOP
	  --nuevo busco los 3 vinculos para atras de la designacion
         	  
	     insert into vincu (dato) values(reg.id_designacion);--inserta el primero
	     select vinc into segundo from vinculo where desig=reg.id_designacion;--
	     if segundo is not null then
 		insert into vincu(dato) values(segundo); 
 		select vinc into tercero from vinculo where desig=segundo;
 		if tercero is not null then 
 		   insert into vincu(dato) values(tercero); 
 		end if;
             end if;
         
	  --
	     detalle:='';
	     FOR reg2 IN --por si participara de mas de un proyecto de investigacion
	        select case when c.codigo is null then 'S/C' else c.codigo end||'-'||b.funcion_p||'-'||b.carga_horaria||'hs' as det
 		from integrante_interno_pi b,pinvestigacion c
 		where c.id_pinv=b.pinvest 
 		and b.hasta=c.fec_hasta --si esta hasta el fin del proyecto lo coloco y sino no
 		and b.desde<=udiames and b.hasta >=pdiames --la participacion en el proyecto entra en el periodo
 		and b.id_designacion in(select dato from vincu) 
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set investig=detalle where id_designacion=reg.id_designacion;
 	     -- veo si tiene proyectos de extension vigentes en el anio que ingresa
 	     --toma el ultimo movimiento
 	     --no importa de que facultad es el proyecto
 	     detalle:='';                                                                   
             FOR reg2 IN                                                                    
                select  c.nro_resol ||' ('||b.funcion_p||') '||b.carga_horaria||'hs' as det 
                 from integrante_interno_pe b,pextension c                                     
                 where c.id_pext=b.id_pext                                                     
                 and b.hasta=c.fec_hasta                                                       
                 and b.desde<=udiames and b.hasta >=pdiames                                    
                 and c.fec_desde <=udiames and (c.fec_hasta>=pdiames or c.fec_hasta is null)   
                 and b.id_designacion in(select dato from vincu) --=reg.id_designacion                                       
             LOOP                                                                           
                 detalle:=detalle||reg2.det;                                                   
                 detalle:=detalle||chr(13);                                                    
             END  LOOP;                                                                     
             update auxiliar set extens=detalle where id_designacion=reg.id_designacion;    
	    ---postgrados
	    detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)
                and t_a.id_tutoria=t_t.id_tutoria
                and t_a.rol='POST'
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set postgrado=detalle where id_designacion=reg.id_designacion;
 	     --tutorias la carga horaria no es obligatoria Uso el concat para no anular cuando no tiene carga horaria
 	     detalle:='';
	     FOR reg2 IN
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end as det from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and (t_a.rol='TUTO' or t_a.rol='COOR')
                and t_a.anio=annio
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set tutorias=detalle where id_designacion=reg.id_designacion;
 	     --otros
 	     detalle:='';
	     FOR reg2 IN
	     	select 'DIRECTOR DEPARTAMENTO: '||trim(c.descripcion) as det from director_dpto a, departamento c
		where a.id_docente=reg.id_docente
		and a.iddepto=c.iddepto 
    		and a.hasta >= pdiames and a.desde <=udiames  
    		UNION
	        select t_t.descripcion||case when t_a.carga_horaria is not null then t_a.carga_horaria||'hs' else '' end  as det 
	        from asignacion_tutoria t_a, tutoria t_t
                where t_a.id_designacion in(select dato from vincu)--=reg.id_designacion
                and t_a.id_tutoria=t_t.id_tutoria
                and (t_a.rol='OTRO')
                and t_a.anio=annio
                
		
 	     LOOP
 		detalle:=detalle||reg2.det;
 		detalle:=detalle||chr(13);
 	     END LOOP;
 	     update auxiliar set otros=detalle where id_designacion=reg.id_designacion;
 	     delete from vincu;
            
	END LOOP;

return 1;
END; 
$_$;


ALTER FUNCTION public.informe_actividad(integer, character) OWNER TO postgres;

--
-- Name: inscriptos_designa(integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.inscriptos_designa(integer, character) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      character(4);
  annio		integer;
  pdiames	date;      
  udiames	date;
  reg		record;
  

BEGIN
annio:=$1;
uni:=$2;

CREATE LOCAL TEMP TABLE auxiliar
(
  id_materia		integer,
  anio		      	integer,
  id_periodo		integer,
  id_comision		integer,
  id_conjunto		integer,
  cant_inscriptos	integer,
  cant_desig		integer
  
  
  );
insert into auxiliar
select id_materia,anio_acad,id_periodo,id_comision,null,inscriptos,0 from inscriptos
where anio_acad = annio;

FOR reg IN
--a las materias que estan en algun conjunto para ese año y ese periodo
--les coloco el id_conjunto
 select a.id_materia,a.anio,a.id_periodo,t_o.id_conjunto from auxiliar a
  	   LEFT OUTER JOIN en_conjunto t_co ON (t_co.id_materia=a.id_materia)
           LEFT OUTER JOIN conjunto t_o ON (t_o.id_conjunto=t_co.id_conjunto and t_o.id_periodo=a.id_periodo)
           LEFT OUTER JOIN mocovi_periodo_presupuestario t_an ON (t_an.id_periodo=t_o.id_periodo_pres and t_an.anio=a.anio)
           where t_o.id_conjunto is not null
 
LOOP
update auxiliar b set id_conjunto=reg.id_conjunto where b.id_materia=reg.id_materia and b.anio=reg.anio and b.id_periodo=reg.id_periodo  ;	
END LOOP;

FOR reg IN
--para las materias que no estan dentro de un conjunto
--cuantas designaciones estan asociadas a esa materia, periodo y ano
 select a.id_materia,a.anio,a.id_periodo,count(distinct id_designacion)as cant 
           from auxiliar a
  	   LEFT OUTER JOIN asignacion_materia t_a ON (t_a.id_materia=a.id_materia and t_a.id_periodo=a.id_periodo and t_a.anio=a.anio)       
  	   where a.id_conjunto is null
  	   group by a.id_materia,a.anio,a.id_periodo
 
LOOP
update auxiliar b set cant_desig=reg.cant where b.id_materia=reg.id_materia and b.anio=reg.anio and b.id_periodo=reg.id_periodo  ;	
END LOOP;

FOR reg IN
--para las materias que estan dentro de un conjunto
--cuantas designaciones estan a materias que estan dentro de ese conjunto
 select a.id_conjunto,a.anio,a.id_periodo,count(distinct id_designacion)as cant 
           from auxiliar a
           LEFT OUTER JOIN en_conjunto t_e ON ( t_e.id_conjunto=a.id_conjunto)
           LEFT OUTER JOIN asignacion_materia t_a ON (t_a.id_materia=t_e.id_materia and t_a.id_periodo=a.id_periodo and a.anio=t_a.anio)
  	   
  	   where a.id_conjunto is not null
  	   group by a.id_conjunto,a.anio,a.id_periodo
 
LOOP
update auxiliar b set cant_desig=reg.cant where b.id_conjunto=reg.id_conjunto and b.anio=reg.anio and b.id_periodo=reg.id_periodo  ;	
END LOOP;
  
return 1;
END; 
$_$;


ALTER FUNCTION public.inscriptos_designa(integer, character) OWNER TO postgres;

--
-- Name: materias_conjunto(integer, integer, character, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.materias_conjunto(integer, integer, character, integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
  annio		integer;
  periodo	integer;
  uacad		text;
  mat		integer;
  conj		integer;
  detalle	text;
  nombre	text;
  reg		record;
  band		boolean;
  primera	text;
  mater	text;
  carrera	text;

BEGIN
annio:=$1;
periodo:=$2;
uacad:=$3;
mat:=$4;
detalle:='';
band:=true;
 select into nombre trim(m.desc_materia)||'('||p.cod_carrera||')' from materia m, plan_estudio p where m.id_plan=p.id_plan and m.id_materia=mat;
--si la materia esta dentro de un conjunto para ese periodo, anio y ua entonces recorro el conjunto
 select into conj c.id_conjunto from conjunto c, en_conjunto e,mocovi_periodo_presupuestario p
 where c.id_conjunto=e.id_conjunto
	and p.anio=annio
	and p.id_periodo=c.id_periodo_pres
	and c.ua=trim(uacad)
	and c.id_periodo=periodo
	and e.id_materia=mat;
 if conj is not null then--si encuentra el conjunto
 	FOR reg IN select trim(regexp_replace(regexp_replace( regexp_replace(regexp_replace(regexp_replace(m.desc_materia, 'Á', 'A','g'),'É', 'E','g'),'Í', 'I','g'),'Ó', 'O','g'),'Ú', 'U','g')) as desc_materia,trim(p.cod_carrera) as cod_carrera 
 	           from en_conjunto e, materia m, plan_estudio p 
 	           where e.id_conjunto=conj 
 	           and e.id_materia=m.id_materia 
 	           and m.id_plan=p.id_plan 
 	           order by m.desc_materia
 	LOOP
 	  if band then--solo la primera vez recupera el 1er nombre
 	  	mater:=trim(regexp_replace(regexp_replace( regexp_replace(regexp_replace(regexp_replace(reg.desc_materia, 'Á', 'A','g'),'É', 'E','g'),'Í', 'I','g'),'Ó', 'O','g'),'Ú', 'U','g'));
 	  	carrera:=reg.cod_carrera;
 	  	detalle:=reg.desc_materia||'(';
 	  	band:=false;
 	  else
 	  	if trim(reg.desc_materia)=trim(mater) then 
 	  		detalle:=detalle||''||carrera||',' ;
 	  		carrera:=reg.cod_carrera;
 	  	else
 	        	detalle:=detalle||carrera||')'||reg.desc_materia||'(';
 	        	carrera:=reg.cod_carrera;
 	        	mater:=reg.desc_materia;
 	  	end if;		
 	  end if;
 	  
 	  
   
 	END LOOP;
 	detalle=detalle||carrera||')';
 else--la materia no esta en ningun conjunto
 	detalle:=nombre;
 end if;
 

return detalle;
END; 
$_$;


ALTER FUNCTION public.materias_conjunto(integer, integer, character, integer) OWNER TO postgres;

--
-- Name: minimo_docentes(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.minimo_docentes(integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	idproy		integer;
  	salida		text;
  	pdia		date;
  	udia		date;
  	cantidad	integer;
  	cantidadi	integer;
  	reg		record;
  	reg1		record;
  	band		boolean;
  	fh		date;
  	fin		date;
  	
BEGIN
idproy=$1;
cantidad=0;
cantidadi=0;

CREATE LOCAL TEMP TABLE auxiliar
(
  codigo		character varying,
  uni_acad		character(4),
  denominacion		character varying
  
);
--solo controlo proyectos que aun no han terminado
--FOR reg1 IN select * from pinvestigacion
            -- where fec_hasta>current_date 
     --LOOP
      --  cantidad=0;
	--cantidadi=0;
	select into fin case when fec_hasta>current_date then current_date else fec_hasta end  from pinvestigacion where id_pinv=idproy;
--separo porque a los regulares los cuento sin tener que analizar nada
      --cantidad de docentes regulares que estan en el proyecto o que se asocio al proyecto como interino pero lo regularizo
	select into cantidad count(id_docente) as cant from integrante_interno_pi i, pinvestigacion p, designacion d
	where pinvest=idproy
	and i.pinvest=p.id_pinv
	and i.id_designacion=d.id_designacion
	and i.hasta=p.fec_hasta --busco la cantidad de docentes que estan hasta el final
	and ((d.carac='R' and d.hasta is null) or (d.carac='I' and exists(select * from designacion dd where dd.id_docente=d.id_docente and dd.cat_estat=d.cat_estat and dd.dedic=d.dedic and dd.carac='R' and dd.hasta is null and dd.desde=d.hasta+1 )))
	and i.funcion_p<>'AS' and i.funcion_p<>'CO' and i.funcion_p<>'IA' and i.funcion_p<>'IAp' and i.funcion_p<>'AT';
--los regulares con fecha de fin no los cuento
--designaciones interinas que no estan dentro del grupo anterior
	FOR reg IN --analizo cada designacion interina para ver sino se cayo
	     select d.id_designacion,d.id_docente,d.desde,d.hasta,p.fec_hasta,d.cat_estat ,d.dedic from integrante_interno_pi i, designacion d ,pinvestigacion p
	     where pinvest=idproy
	     and i.pinvest=p.id_pinv
	     and i.id_designacion=d.id_designacion
	     and i.hasta=p.fec_hasta
	     and d.carac='I' 
	     and d.hasta is not null and d.desde<d.hasta 
	     and i.funcion_p<>'AS' and i.funcion_p<>'CO' and i.funcion_p<>'IA' and i.funcion_p<>'IAp' and i.funcion_p<>'AT'
	     and not exists (select * from designacion dd 
	     			where dd.id_docente=d.id_docente 
	     			and dd.cat_estat=d.cat_estat and dd.dedic=d.dedic and dd.carac='R' and dd.hasta is null and dd.desde=d.hasta+1 )--interino que no regularizo
 	     LOOP
 	   
 	     band=true;
 	     fh=reg.hasta;  
 	    
 	     WHILE (fh<fin and band) LOOP
 	       
 	        
 	     	if not exists(select * from designacion
 	     		where id_docente=reg.id_docente
 	     		and cat_estat=reg.cat_estat
 	     		and dedic=reg.dedic
 	     		and carac='I'
 	     		and hasta is not null and desde<hasta 
 	     		and desde=fh+1) then 
			band=false;
 	     	 else
 	     	 	select into fh hasta from designacion
 	     		where id_docente=reg.id_docente
 	     		and cat_estat=reg.cat_estat
 	     		and dedic=reg.dedic
 	     		and hasta is not null and desde<hasta 
 	     		and carac='I'
 	     		and desde=fh+1;  
 	     	  end if;
 	     --	--if fh is null then --no existe una designacion interina continua
 	     --	  --band=false;
 	     --	--end if;--si encuentra fh tendra la fecha hasta de la proxima designacion interina y asi repite hasta
 	     END LOOP;
 	     if band then--si sale true entonces la cuento
 	     	cantidadi=cantidadi+1;
 	     end if;
 	       
	END LOOP;
	--if (cantidad + cantidadi)<3 then
	--	insert into auxiliar(codigo,uni_acad,denominacion) values(reg1.codigo,reg1.uni_acad,reg1.denominacion) ;
	--end if;

--END LOOP;

return cantidad+cantidadi;
END; 
$_$;


ALTER FUNCTION public.minimo_docentes(integer) OWNER TO postgres;

--
-- Name: norma_baja(integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.norma_baja(integer, date, date) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	iddesig		integer;
  	salida		text;
  	pdia		date;
  	udia		date;

BEGIN
iddesig=$1;
pdia=$2;
udia=$3;

salida='';

select into salida case when b.id_novedad is not null then 'B('||b.tipo_norma||':'||b.norma_legal||')' else case when c.id_novedad is not null then 'L ('||c.tipo_norma||':'||c.norma_legal||')' else a.estado end end 
from designacion a
LEFT OUTER JOIN novedad b ON (a.id_designacion=b.id_designacion and b.tipo_nov in (1,4))
LEFT OUTER JOIN novedad c ON (a.id_designacion=c.id_designacion and c.tipo_nov in (2,5) and c.desde <= udia and (c.hasta >= pdia or c.hasta is null))
where a.id_designacion=iddesig;



return salida;
END; 
$_$;


ALTER FUNCTION public.norma_baja(integer, date, date) OWNER TO postgres;

--
-- Name: norma_baja_bl(integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.norma_baja_bl(integer, date, date) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
	
  	iddesig		integer;
  	salida		text;
  	pdia		date;
  	udia		date;
  	enlace_baja	text;
  	enlace_lic	text;

BEGIN
iddesig=$1;
pdia=$2;
udia=$3;

salida='';
--recupero el id de la novedad si es Baja o Lic
select into enlace_baja,enlace_lic case when b.id_novedad is not null then busca_norma(b.id_novedad) else '' end ,case when c.id_novedad is not null then busca_norma(c.id_novedad) else '' end
from designacion a
LEFT OUTER JOIN novedad b ON (a.id_designacion=b.id_designacion and b.tipo_nov in (1,4))
LEFT OUTER JOIN novedad c ON (a.id_designacion=c.id_designacion and c.tipo_nov in (2,5) and c.desde <= udia and (c.hasta >= pdia or c.hasta is null))
where a.id_designacion=iddesig;



select into salida case when b.id_novedad is not null then case when enlace_baja='' then 'B('||b.tipo_norma||':'||b.norma_legal||')' else '<a href='||chr(39)||enlace_baja||chr(39)|| ' target='||chr(39)||'_blank'||chr(39)||'>'||'B('||b.tipo_norma||':'||b.norma_legal||')'||'</a>' end else case when c.id_novedad is not null then case when enlace_lic='' then 'L ('||c.tipo_norma||':'||c.norma_legal||')' else   '<a href='||chr(39)||enlace_lic||chr(39)|| ' target='||chr(39)||'_blank'||chr(39)||'>'||'L ('||c.tipo_norma||':'||c.norma_legal||')'||'</a>' end else a.estado end end 
from designacion a
LEFT OUTER JOIN novedad b ON (a.id_designacion=b.id_designacion and b.tipo_nov in (1,4))
LEFT OUTER JOIN novedad c ON (a.id_designacion=c.id_designacion and c.tipo_nov in (2,5) and c.desde <= udia and (c.hasta >= pdia or c.hasta is null))
where a.id_designacion=iddesig;



return salida;
END; 
$_$;


ALTER FUNCTION public.norma_baja_bl(integer, date, date) OWNER TO postgres;

--
-- Name: pre_liquidacion_incentivos(integer, integer, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.pre_liquidacion_incentivos(integer, integer, character) RETURNS date
    LANGUAGE plpgsql
    AS $_$
DECLARE
  uni      character(4);
  anio		integer;
  m		integer;
  mesdesde	integer;
  meshasta	integer;
  arreglo       integer[10];
  pdiames	date;
  pdiames2	date;
  pdiames3	date;
  pdiames4	date;
      
  udiames	date;
  udiames2	date;
  udiames3	date;
  udiames4	date;
  reg		record;

BEGIN
anio:=$1;
mesdesde:=$2;
meshasta:=$2+3;--siempre calculo por 4 meses
uni:=$3;


--primer dia de mes
pdiames:=  CAST ('01'  || '/' || mesdesde || '/' ||anio AS DATE);
pdiames2:=  CAST ('01'  || '/' || mesdesde+1 || '/' ||anio AS DATE);
pdiames3:=  CAST ('01'  || '/' || mesdesde+2 || '/' ||anio AS DATE);
pdiames4:=  CAST ('01'  || '/' || mesdesde+3 || '/' ||anio AS DATE);
--ultimo dia del primer mes que ingresa como parametro
  IF mesdesde=1 or mesdesde=3 or mesdesde=5 or mesdesde=7 or mesdesde=8 or mesdesde=10 or mesdesde=12  THEN
	udiames:=  CAST ( '31' || '/' || mesdesde || '/' ||anio AS DATE);		
   ELSE   IF mesdesde=4 or mesdesde=6 or mesdesde=9 or mesdesde=11  THEN
		udiames:=  CAST ( '30' || '/' || mesdesde || '/' ||anio AS DATE);
	  ELSE   udiames:=  CAST ( '28' || '/' || mesdesde || '/' ||anio AS DATE);
          END IF; 
   END IF; 
m=mesdesde+1;
  IF m=1 or m=3 or m=5 or m=7 or m=8 or m=10 or m=12  THEN
	udiames2:=  CAST ( '31' || '/' || m || '/' ||anio AS DATE);		
   ELSE   IF m=4 or m=6 or m=9 or m=11  THEN
		udiames2:=  CAST ( '30' || '/' || m || '/' ||anio AS DATE);
	  ELSE   udiames2:=  CAST ( '28' || '/' || m || '/' ||anio AS DATE);
          END IF; 
   END IF; 

m=mesdesde+1;
  IF m=1 or m=3 or m=5 or m=7 or m=8 or m=10 or m=12  THEN
	udiames3:=  CAST ( '31' || '/' || m || '/' ||anio AS DATE);		
   ELSE   IF m=4 or m=6 or m=9 or m=11  THEN
		udiames3:=  CAST ( '30' || '/' || m || '/' ||anio AS DATE);
	  ELSE   udiames3:=  CAST ( '28' || '/' || m || '/' ||anio AS DATE);
          END IF; 
   END IF; 
m=mesdesde+1;
  IF m=1 or m=3 or m=5 or m=7 or m=8 or m=10 or m=12  THEN
	udiames4:=  CAST ( '31' || '/' || m || '/' ||anio AS DATE);		
   ELSE   IF m=4 or m=6 or m=9 or m=11  THEN
		udiames4:=  CAST ( '30' || '/' || m || '/' ||anio AS DATE);
	  ELSE   udiames4:=  CAST ( '28' || '/' || m || '/' ||anio AS DATE);
          END IF; 
   END IF; 

CREATE LOCAL TEMP TABLE auxiliar
(
  id_docente      	integer,
  id_proy 		integer,
  categoria		integer,
  dedic_doc1		integer,
  dedic_inv1		integer,
  dedic_doc2		integer,
  dedic_inv2		integer,
  dedic_doc3		integer,
  dedic_inv3		integer,
  dedic_doc4		integer,
  dedic_inv4		integer
    
  );
  
--ingreso todos los docentes que son integrantes de proyectos de investigacion de la ua que ingresa como argumento
--calculo la dedicacion docente del primer mes 
insert into auxiliar
select a.id_docente,a.pinvest,a.cat_investigador,a.dedic_doc1,0,b.dedic_doc2,0,c.dedic_doc3,0,d.dedic_doc4,0 from
(select d.id_docente,pinvest,i.cat_investigador,min(case when t_d.dedic is not null then t_d.dedic else d.dedic end ) as dedic_doc1 
from 
	integrante_interno_pi i
 		LEFT OUTER JOIN designacion d ON (d.id_designacion=i.id_designacion)
 		LEFT OUTER JOIN designacion t_d ON (d.id_docente=t_d.id_docente and t_d.uni_acad=uni and t_d.desde <= udiames and (t_d.hasta >= pdiames or t_d.hasta is null))
 		where ua=uni
 		and cat_investigador<>6
 		and exists(select * from pinvestigacion p_i where p_i.id_pinv=i.pinvest and p_i.uni_acad=ua)--el proyecto es de la facultad
 		and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 		and i.hasta>=pdiames and i.desde<=udiames
 group by d.id_docente,pinvest,i.cat_investigador)a
 LEFT OUTER JOIN (
 		select d.id_docente,pinvest,cat_investigador,min(case when t_d.dedic is not null then t_d.dedic else d.dedic end )as dedic_doc2
 		from integrante_interno_pi i
 		LEFT OUTER JOIN designacion d ON (d.id_designacion=i.id_designacion)
 		LEFT OUTER JOIN designacion t_d ON (d.id_docente=t_d.id_docente and t_d.uni_acad=uni and t_d.desde <= udiames2 and (t_d.hasta >= pdiames2 or t_d.hasta is null))
 		where ua=uni
 		and cat_investigador<>6
 		and exists(select * from pinvestigacion p_i where p_i.id_pinv=i.pinvest and p_i.uni_acad=ua)--el proyecto es de la facultad
 		and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 		and i.hasta>=pdiames2 and i.desde<=udiames2
 		group by d.id_docente,pinvest,cat_investigador)b ON (a.id_docente=b.id_docente and a.pinvest=b.pinvest and a.cat_investigador=b.cat_investigador)
LEFT OUTER JOIN (
 		select d.id_docente,pinvest,cat_investigador,min(case when t_d.dedic is not null then t_d.dedic else d.dedic end )as dedic_doc3
 		from integrante_interno_pi i
 		LEFT OUTER JOIN designacion d ON (d.id_designacion=i.id_designacion)
 		LEFT OUTER JOIN designacion t_d ON (d.id_docente=t_d.id_docente and t_d.uni_acad=uni and t_d.desde <= udiames3 and (t_d.hasta >= pdiames3 or t_d.hasta is null))
 		where ua=uni
 		and cat_investigador<>6
 		and exists(select * from pinvestigacion p_i where p_i.id_pinv=i.pinvest and p_i.uni_acad=ua)--el proyecto es de la facultad
 		and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 		and i.hasta>=pdiames3 and i.desde<=udiames3
 		group by d.id_docente,pinvest,cat_investigador)c ON (c.id_docente=b.id_docente and c.pinvest=b.pinvest and c.cat_investigador=b.cat_investigador)
LEFT OUTER JOIN (
 		select d.id_docente,pinvest,cat_investigador,min(case when t_d.dedic is not null then t_d.dedic else d.dedic end )as dedic_doc4
 		from integrante_interno_pi i
 		LEFT OUTER JOIN designacion d ON (d.id_designacion=i.id_designacion)
 		LEFT OUTER JOIN designacion t_d ON (d.id_docente=t_d.id_docente and t_d.uni_acad=uni and t_d.desde <= udiames4 and (t_d.hasta >= pdiames4 or t_d.hasta is null))
 		where ua=uni
 		and cat_investigador<>6
 		and exists(select * from pinvestigacion p_i where p_i.id_pinv=i.pinvest and p_i.uni_acad=ua)--el proyecto es de la facultad
 		and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 		and i.hasta>=pdiames4 and i.desde<=udiames4
 		group by d.id_docente,pinvest,cat_investigador)d ON (c.id_docente=d.id_docente and c.pinvest=d.pinvest and c.cat_investigador=d.cat_investigador);
 
--calculo dedicacion en la investigacion del primer mes
FOR reg IN
--busco la carga horaria y la funcion en el primer mes para ese docente en ese proyecto y en ese periodo
 select b.carga_horaria,b.funcion_p,b.cat_invest_conicet,a.id_docente,a.id_proy,a.categoria,a.dedic_doc1 from auxiliar a, integrante_interno_pi b, designacion c 
 where a.id_proy=b.pinvest and a.categoria=b.cat_investigador and b.id_designacion=c.id_designacion and c.id_docente=a.id_docente
 and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 and b.hasta>=pdiames and b.desde<=udiames
LOOP

IF (reg.funcion_p='BC' or reg.cat_invest_conicet is not null) THEN --si es becario conicet o tiene categ conicet entonces corresponde 1
   update auxiliar set dedic_inv1=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
ELSE 
   IF reg.dedic_doc1=1 THEN --si tiene una dedicacion docente 1 (exclusiva)
     IF reg.carga_horaria>=20 THEN --y >=20 hs
         update auxiliar set dedic_inv1=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     		update auxiliar set dedic_inv1=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     	  ELSE --tiene menos de 10 hs	
     	  	update auxiliar set dedic_inv1=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
          END IF;    
     END IF;
   ELSE IF reg.dedic_doc1=2 THEN--si tiene una parcial 
   		IF reg.carga_horaria>=20 THEN --y >=20 hs
         		update auxiliar set dedic_inv1=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     		ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     			update auxiliar set dedic_inv1=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     	  	     ELSE --tiene menos de 10 hs	
     	  		update auxiliar set dedic_inv1=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
          	     END IF;    
     		END IF;
     	ELSE --es simple en docente	
     	  IF reg.carga_horaria<10 THEN
     	  	update auxiliar set dedic_inv1=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     	  ELSE	
     	  	update auxiliar set dedic_inv1=0 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc1=reg.dedic_doc1;
     	  END IF;	
        END IF;  
   END IF;
END IF;

END LOOP ;
 ---recorrido para calcular la dedicacion en investigacion en el segundo mes
 FOR reg IN
--busco la carga horaria y la funcion que ese docente tuvo en ese proyecto y en ese periodo
 select b.carga_horaria,b.funcion_p,b.cat_invest_conicet,a.id_docente,a.id_proy,a.categoria,a.dedic_doc2 from auxiliar a, integrante_interno_pi b, designacion c 
 where a.id_proy=b.pinvest and a.categoria=b.cat_investigador and b.id_designacion=c.id_designacion and c.id_docente=a.id_docente
 and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 and b.hasta>=pdiames2 and b.desde<=udiames2
LOOP

IF (reg.funcion_p='BC' or reg.cat_invest_conicet is not null) THEN --si es becario conicet o tiene categ conicet entonces corresponde 1
   update auxiliar set dedic_inv2=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
ELSE 
   IF reg.dedic_doc2=1 THEN --si tiene una dedicacion docente 1 (exclusiva)
     IF reg.carga_horaria>=20 THEN --y >=20 hs
         update auxiliar set dedic_inv2=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     		update auxiliar set dedic_inv2=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     	  ELSE --tiene menos de 10 hs	
     	  	update auxiliar set dedic_inv2=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
          END IF;    
     END IF;
   ELSE IF reg.dedic_doc2=2 THEN--si tiene una parcial 
   		IF reg.carga_horaria>=20 THEN --y >=20 hs
         		update auxiliar set dedic_inv2=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     		ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     			update auxiliar set dedic_inv2=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     	  	     ELSE --tiene menos de 10 hs	
     	  		update auxiliar set dedic_inv2=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
          	     END IF;    
     		END IF;
     	ELSE --es simple en docente	
     	  IF reg.carga_horaria<10 THEN
     	  	update auxiliar set dedic_inv2=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     	  ELSE
     	  	update auxiliar set dedic_inv2=0 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc2=reg.dedic_doc2;
     	  END IF;	
        END IF;  
   END IF;
END IF;

END LOOP ;

--3er recorrido
FOR reg IN
--busco la carga horaria y la funcion que ese docente tuvo en ese proyecto y en ese periodo
 select b.carga_horaria,b.funcion_p,b.cat_invest_conicet,a.id_docente,a.id_proy,a.categoria,a.dedic_doc3 from auxiliar a, integrante_interno_pi b, designacion c 
 where a.id_proy=b.pinvest and a.categoria=b.cat_investigador and b.id_designacion=c.id_designacion and c.id_docente=a.id_docente
 and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 and b.hasta>=pdiames3 and b.desde<=udiames3
LOOP

IF (reg.funcion_p='BC' or reg.cat_invest_conicet is not null) THEN --si es becario conicet o tiene categ conicet entonces corresponde 1
   update auxiliar set dedic_inv3=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
ELSE 
   IF reg.dedic_doc3=1 THEN --si tiene una dedicacion docente 1 (exclusiva)
     IF reg.carga_horaria>=20 THEN --y >=20 hs
         update auxiliar set dedic_inv3=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     		update auxiliar set dedic_inv3=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     	  ELSE --tiene menos de 10 hs	
     	  	update auxiliar set dedic_inv3=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
          END IF;    
     END IF;
   ELSE IF reg.dedic_doc3=2 THEN--si tiene una parcial 
   		IF reg.carga_horaria>=20 THEN --y >=20 hs
         		update auxiliar set dedic_inv3=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     		ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     			update auxiliar set dedic_inv3=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     	  	     ELSE --tiene menos de 10 hs	
     	  		update auxiliar set dedic_inv3=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
          	     END IF;    
     		END IF;
     	ELSE --es simple en docente	
     	  IF reg.carga_horaria<10 THEN
     	  	update auxiliar set dedic_inv3=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     	  ELSE	
     	  	update auxiliar set dedic_inv3=0 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc3=reg.dedic_doc3;
     	  END IF;	
        END IF;  
   END IF;
END IF;

END LOOP ;

--4to recorrido
FOR reg IN
--busco la carga horaria y la funcion en el primer mes para ese docente en ese proyecto y en ese periodo
 select b.carga_horaria,b.funcion_p,b.cat_invest_conicet,a.id_docente,a.id_proy,a.categoria,a.dedic_doc4 from auxiliar a, integrante_interno_pi b, designacion c 
 where a.id_proy=b.pinvest and a.categoria=b.cat_investigador and b.id_designacion=c.id_designacion and c.id_docente=a.id_docente
 and  (trim(funcion_p)='ID' or trim(funcion_p)='DP' or trim(funcion_p)='D' or trim(funcion_p)='C' or trim(funcion_p)='ID' or trim(funcion_p)='DpP' or trim(funcion_p)='BC')
 and b.hasta>=pdiames4 and b.desde<=udiames4
LOOP

IF (reg.funcion_p='BC' or reg.cat_invest_conicet is not null) THEN --si es becario conicet o tiene categ conicet entonces corresponde 1
   update auxiliar set dedic_inv4=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
ELSE 
   IF reg.dedic_doc4=1 THEN --si tiene una dedicacion docente 1 (exclusiva)
     IF reg.carga_horaria>=20 THEN --y >=20 hs
         update auxiliar set dedic_inv4=1 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     		update auxiliar set dedic_inv4=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     	  ELSE --tiene menos de 10 hs	
     	  	update auxiliar set dedic_inv4=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
          END IF;    
     END IF;
   ELSE IF reg.dedic_doc4=2 THEN--si tiene una parcial 
   		IF reg.carga_horaria>=20 THEN --y >=20 hs
         		update auxiliar set dedic_inv4=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     		ELSE IF reg.carga_horaria<20 and reg.carga_horaria>=10 THEN
     			update auxiliar set dedic_inv4=2 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     	  	     ELSE --tiene menos de 10 hs	
     	  		update auxiliar set dedic_inv4=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
          	     END IF;    
     		END IF;
     	ELSE --es simple en docente	
     	  IF reg.carga_horaria<10 THEN
     	  	update auxiliar set dedic_inv4=3 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;
     	  ELSE
     	  	update auxiliar set dedic_inv4=0 where id_docente=reg.id_docente and id_proy=reg.id_proy and categoria=reg.categoria and dedic_doc4=reg.dedic_doc4;	
     	  END IF;	
        END IF;  
   END IF;
END IF;

END LOOP ;
 return udiames;
  
END;
$_$;


ALTER FUNCTION public.pre_liquidacion_incentivos(integer, integer, character) OWNER TO postgres;

--
-- Name: recuperar_schema_temp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.recuperar_schema_temp() RETURNS character varying
    LANGUAGE plpgsql
    AS $$
			DECLARE
			   schemas varchar;
			   pos_inicial int4;
			   pos_final int4;
			   schema_temp varchar;
			BEGIN
			   schema_temp := '';
			   SELECT INTO schemas current_schemas(true);
			   SELECT INTO pos_inicial strpos(schemas, 'pg_temp');
			   IF (pos_inicial > 0) THEN
			      SELECT INTO pos_final strpos(schemas, ',');
			      SELECT INTO schema_temp substr(schemas, pos_inicial, pos_final - pos_inicial);
			   END IF;
			   RETURN schema_temp;
			END;
			$$;


ALTER FUNCTION public.recuperar_schema_temp() OWNER TO postgres;

--
-- Name: area_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.area_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.area_id_seq OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: area; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.area (
    idarea integer DEFAULT nextval('public.area_id_seq'::regclass) NOT NULL,
    iddepto integer NOT NULL,
    descripcion character varying DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.area OWNER TO postgres;

--
-- Name: bases_convocatoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bases_convocatoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bases_convocatoria_seq OWNER TO postgres;

--
-- Name: bases_convocatoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bases_convocatoria (
    id_bases integer DEFAULT nextval('public.bases_convocatoria_seq'::regclass) NOT NULL,
    convocatoria character varying NOT NULL,
    objetivo character varying NOT NULL,
    eje_tematico character varying NOT NULL,
    destinatarios character varying NOT NULL,
    integrantes character varying NOT NULL,
    monto character varying NOT NULL,
    duracion character varying NOT NULL,
    fecha character varying NOT NULL,
    evaluacion character varying NOT NULL,
    adjudicacion character varying NOT NULL,
    consulta character varying NOT NULL,
    bases_titulo character varying NOT NULL,
    ordenanza character varying NOT NULL,
    tipo_convocatoria character(1)
);


ALTER TABLE public.bases_convocatoria OWNER TO postgres;

--
-- Name: caracter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.caracter (
    id_car character(1) NOT NULL,
    descripcion character(20) DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.caracter OWNER TO postgres;

--
-- Name: dedicacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dedicacion (
    id_ded integer NOT NULL,
    descripcion character(20) DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.dedicacion OWNER TO postgres;

--
-- Name: dedicacion_incentivo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dedicacion_incentivo (
    id_di integer NOT NULL,
    descripcion character(30) DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.dedicacion_incentivo OWNER TO postgres;

--
-- Name: dedicacion_incentivo_id_di_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dedicacion_incentivo_id_di_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dedicacion_incentivo_id_di_seq OWNER TO postgres;

--
-- Name: dedicacion_incentivo_id_di_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dedicacion_incentivo_id_di_seq OWNED BY public.dedicacion_incentivo.id_di;


--
-- Name: departamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departamento_id_seq OWNER TO postgres;

--
-- Name: departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamento (
    iddepto integer DEFAULT nextval('public.departamento_id_seq'::regclass) NOT NULL,
    idunidad_academica character(5) NOT NULL,
    descripcion character varying DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.departamento OWNER TO postgres;

--
-- Name: designacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.designacion (
    id_designacion integer NOT NULL,
    id_docente integer,
    nro_cargo integer,
    anio_acad integer,
    desde date NOT NULL,
    hasta date,
    cat_mapuche character(4),
    cat_estat character(6),
    dedic integer NOT NULL,
    carac character(1) NOT NULL,
    uni_acad character(5) NOT NULL,
    id_departamento integer,
    id_area integer,
    id_orientacion integer,
    id_norma integer,
    id_expediente integer,
    tipo_incentivo integer,
    dedi_incen integer,
    cic_con character(3),
    cargo_gestion character(4),
    ord_gestion character(10),
    emite_cargo_gestion character(4),
    nro_gestion character(10),
    observaciones character varying,
    check_presup integer,
    nro_540 integer,
    concursado integer,
    check_academica integer,
    tipo_desig integer,
    id_reserva integer,
    estado character(1),
    id_norma_cs integer,
    por_permuta integer
);


ALTER TABLE public.designacion OWNER TO postgres;

--
-- Name: COLUMN designacion.id_norma; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.id_norma IS 'Norma del Consejo Directivo';


--
-- Name: COLUMN designacion.tipo_incentivo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.tipo_incentivo IS 'Tipo de incentivo';


--
-- Name: COLUMN designacion.dedi_incen; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.dedi_incen IS 'Dedicación de incentivo';


--
-- Name: COLUMN designacion.cic_con; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.cic_con IS 'CIC / CONICET';


--
-- Name: COLUMN designacion.id_norma_cs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.designacion.id_norma_cs IS 'Norma del Consejo Superior';


--
-- Name: designacion_id_designacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.designacion_id_designacion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.designacion_id_designacion_seq OWNER TO postgres;

--
-- Name: designacion_id_designacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.designacion_id_designacion_seq OWNED BY public.designacion.id_designacion;


--
-- Name: director_dpto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.director_dpto (
    id_docente integer NOT NULL,
    iddepto integer NOT NULL,
    desde date NOT NULL,
    hasta date,
    resol character(9)
);


ALTER TABLE public.director_dpto OWNER TO postgres;

--
-- Name: docente_id_docente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.docente_id_docente_seq
    START WITH 295
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.docente_id_docente_seq OWNER TO postgres;

--
-- Name: docente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.docente (
    id_docente integer DEFAULT nextval('public.docente_id_docente_seq'::regclass) NOT NULL,
    legajo integer,
    apellido character varying,
    nombre character varying,
    nro_tabla integer,
    tipo_docum character(4),
    nro_docum integer,
    fec_nacim date,
    nro_cuil1 integer,
    nro_cuil integer,
    nro_cuil2 integer,
    tipo_sexo character(1),
    pais_nacim character(2),
    porcdedicdocente double precision,
    porcdedicinvestig double precision,
    porcdedicagestion double precision,
    porcdedicaextens double precision,
    pcia_nacim integer,
    fec_ingreso date,
    correo_institucional character(60),
    correo_personal character(60),
    situacion_docente character varying,
    telefono integer
);


ALTER TABLE public.docente OWNER TO postgres;

--
-- Name: estado_pe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado_pe (
    id_estado character(1) NOT NULL,
    descripcion character(30)
);


ALTER TABLE public.estado_pe OWNER TO postgres;

--
-- Name: estado_pe_descripcion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_pe_descripcion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estado_pe_descripcion_seq OWNER TO postgres;

--
-- Name: estado_pe_descripcion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_pe_descripcion_seq OWNED BY public.estado_pe.descripcion;


--
-- Name: funcion_extension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcion_extension (
    id_extension character(5) NOT NULL,
    descripcion character varying(70)
);


ALTER TABLE public.funcion_extension OWNER TO postgres;

--
-- Name: incentivo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incentivo (
    id_inc integer NOT NULL,
    descripcion character(20) DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.incentivo OWNER TO postgres;

--
-- Name: incentivo_id_inc_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.incentivo_id_inc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.incentivo_id_inc_seq OWNER TO postgres;

--
-- Name: incentivo_id_inc_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.incentivo_id_inc_seq OWNED BY public.incentivo.id_inc;


--
-- Name: integrante_externo_pe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrante_externo_pe (
    tipo_docum character(4) NOT NULL,
    nro_docum integer NOT NULL,
    id_pext integer NOT NULL,
    funcion_p character(5),
    carga_horaria integer,
    desde date NOT NULL,
    hasta date,
    rescd character(10),
    ad_honorem integer,
    tipo character varying
);


ALTER TABLE public.integrante_externo_pe OWNER TO postgres;

--
-- Name: integrante_interno_pe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrante_interno_pe (
    id_designacion integer NOT NULL,
    id_pext integer NOT NULL,
    funcion_p character(5),
    carga_horaria integer,
    ua character(5),
    desde date NOT NULL,
    hasta date,
    rescd character(10),
    ad_honorem integer,
    tipo character varying
);


ALTER TABLE public.integrante_interno_pe OWNER TO postgres;

--
-- Name: localidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.localidad (
    id integer NOT NULL,
    id_provincia integer NOT NULL,
    localidad character varying(255) NOT NULL
);


ALTER TABLE public.localidad OWNER TO postgres;

--
-- Name: norma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.norma (
    id_norma integer NOT NULL,
    nro_norma integer,
    tipo_norma character(5),
    emite_norma character(4),
    fecha date,
    pdf bytea,
    link character varying,
    palabras_clave text,
    uni_acad character(4)
);


ALTER TABLE public.norma OWNER TO postgres;

--
-- Name: norma_desig; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.norma_desig (
    id_norma integer NOT NULL,
    id_designacion integer NOT NULL
);


ALTER TABLE public.norma_desig OWNER TO postgres;

--
-- Name: norma_id_norma_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.norma_id_norma_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.norma_id_norma_seq OWNER TO postgres;

--
-- Name: norma_id_norma_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.norma_id_norma_seq OWNED BY public.norma.id_norma;


--
-- Name: novedad_id_norma_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.novedad_id_norma_seq
    START WITH 234
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.novedad_id_norma_seq OWNER TO postgres;

--
-- Name: objetivo_especifico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.objetivo_especifico (
    id_objetivo integer NOT NULL,
    descripcion character varying,
    id_pext integer,
    meta character varying
);


ALTER TABLE public.objetivo_especifico OWNER TO postgres;

--
-- Name: objetivo_especifico_id_objetivo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.objetivo_especifico_id_objetivo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.objetivo_especifico_id_objetivo_seq OWNER TO postgres;

--
-- Name: objetivo_especifico_id_objetivo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.objetivo_especifico_id_objetivo_seq OWNED BY public.objetivo_especifico.id_objetivo;


--
-- Name: organizaciones_participantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizaciones_participantes (
    nombre character varying,
    telefono integer,
    email character varying,
    referencia_vinculacion_inst character varying,
    id_pext integer NOT NULL,
    id_tipo_organizacion integer NOT NULL,
    id_organizacion integer NOT NULL,
    id_localidad integer
);


ALTER TABLE public.organizaciones_participantes OWNER TO postgres;

--
-- Name: organizaciones_participantes_email_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizaciones_participantes_email_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizaciones_participantes_email_seq OWNER TO postgres;

--
-- Name: organizaciones_participantes_email_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizaciones_participantes_email_seq OWNED BY public.organizaciones_participantes.email;


--
-- Name: organizaciones_participantes_id_organizacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizaciones_participantes_id_organizacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizaciones_participantes_id_organizacion_seq OWNER TO postgres;

--
-- Name: organizaciones_participantes_id_organizacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizaciones_participantes_id_organizacion_seq OWNED BY public.organizaciones_participantes.id_organizacion;


--
-- Name: organizaciones_participantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizaciones_participantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizaciones_participantes_id_seq OWNER TO postgres;

--
-- Name: organizaciones_participantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizaciones_participantes_id_seq OWNED BY public.organizaciones_participantes.id_pext;


--
-- Name: orientacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orientacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orientacion_id_seq OWNER TO postgres;

--
-- Name: orientacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orientacion (
    idorient integer DEFAULT nextval('public.orientacion_id_seq'::regclass) NOT NULL,
    idarea integer NOT NULL,
    descripcion character varying DEFAULT ''::bpchar NOT NULL
);


ALTER TABLE public.orientacion OWNER TO postgres;

--
-- Name: pais; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pais (
    codigo_pais character(2) NOT NULL,
    nombre character varying(40)
);


ALTER TABLE public.pais OWNER TO postgres;

--
-- Name: persona; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persona (
    apellido character varying,
    nombre character varying,
    nro_tabla integer,
    tipo_docum character(4) NOT NULL,
    nro_docum integer NOT NULL,
    tipo_sexo character(1),
    pais_nacim character(2),
    pcia_nacim integer,
    fec_nacim date,
    titulog character(4),
    titulop character(4),
    docum_extran character(15),
    telefono integer,
    mail character varying
);


ALTER TABLE public.persona OWNER TO postgres;

--
-- Name: pextension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pextension (
    id_pext integer NOT NULL,
    codigo character varying,
    denominacion character varying,
    nro_resol character(20),
    fecha_resol date,
    uni_acad character(5),
    fec_desde date,
    fec_hasta date,
    nro_ord_cs character(20),
    res_rect character(20),
    expediente character(12),
    duracion integer,
    palabras_clave character(120),
    objetivo character varying,
    estado character(1),
    financiacion boolean,
    monto numeric,
    fecha_rendicion date,
    rendicion_monto double precision,
    fecha_prorroga1 date,
    fecha_prorroga2 date,
    observacion character varying,
    estado_informe_a character(1),
    estado_informe_f character(1),
    eje_tematico character(20),
    descripcion_situacion character(200),
    caracterizacion_poblacion character(150),
    localizacion_geo character(20),
    antecedente_participacion character(200),
    importancia_necesidad character(200),
    id_bases integer,
    responsable_carga character varying(30)
);


ALTER TABLE public.pextension OWNER TO postgres;

--
-- Name: pextension_id_pext_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pextension_id_pext_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pextension_id_pext_seq OWNER TO postgres;

--
-- Name: pextension_id_pext_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pextension_id_pext_seq OWNED BY public.pextension.id_pext;


--
-- Name: plan_actividades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plan_actividades (
    id_plan integer NOT NULL,
    detalle character varying,
    fecha date,
    localizacion character varying,
    destinatarios character varying,
    meta character varying,
    id_rubro_extension integer,
    id_obj_especifico integer
);


ALTER TABLE public.plan_actividades OWNER TO postgres;

--
-- Name: plan_actividades_id_plan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plan_actividades_id_plan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plan_actividades_id_plan_seq OWNER TO postgres;

--
-- Name: plan_actividades_id_plan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plan_actividades_id_plan_seq OWNED BY public.plan_actividades.id_plan;


--
-- Name: presupuesto_extension_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_extension_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_extension_seq OWNER TO postgres;

--
-- Name: presupuesto_extension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presupuesto_extension (
    id_presupuesto integer DEFAULT nextval('public.presupuesto_extension_seq'::regclass) NOT NULL,
    id_pext integer NOT NULL,
    id_rubro_extension integer NOT NULL,
    concepto character varying,
    cantidad integer,
    monto real
);


ALTER TABLE public.presupuesto_extension OWNER TO postgres;

--
-- Name: presupuesto_extension_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presupuesto_extension_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presupuesto_extension_id_seq OWNER TO postgres;

--
-- Name: presupuesto_extension_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presupuesto_extension_id_seq OWNED BY public.presupuesto_extension.id_pext;


--
-- Name: provincia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provincia (
    descripcion_pcia character(40),
    cod_pais character(2),
    codigo_pcia integer NOT NULL
);


ALTER TABLE public.provincia OWNER TO postgres;

--
-- Name: rubro_presup_extension_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rubro_presup_extension_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rubro_presup_extension_seq OWNER TO postgres;

--
-- Name: rubro_presup_extension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rubro_presup_extension (
    id_rubro_extension integer DEFAULT nextval('public.rubro_presup_extension_seq'::regclass) NOT NULL,
    tipo character varying NOT NULL
);


ALTER TABLE public.rubro_presup_extension OWNER TO postgres;

--
-- Name: tipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo (
    nro_tabla integer NOT NULL,
    desc_abrev character(4) NOT NULL,
    desc_item character(30)
);


ALTER TABLE public.tipo OWNER TO postgres;

--
-- Name: tipo_convocatoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_convocatoria (
    id_conv character(1) NOT NULL,
    descripcion character(30)
);


ALTER TABLE public.tipo_convocatoria OWNER TO postgres;

--
-- Name: tipo_convocatoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_convocatoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_convocatoria_seq OWNER TO postgres;

--
-- Name: tipo_designacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_designacion (
    id integer NOT NULL,
    descripcion character varying
);


ALTER TABLE public.tipo_designacion OWNER TO postgres;

--
-- Name: tipo_designacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_designacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_designacion_id_seq OWNER TO postgres;

--
-- Name: tipo_designacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_designacion_id_seq OWNED BY public.tipo_designacion.id;


--
-- Name: tipo_organizacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_organizacion (
    descripcion character varying,
    id_tipo_organizacion integer NOT NULL
);


ALTER TABLE public.tipo_organizacion OWNER TO postgres;

--
-- Name: tipo_organizacion_id_organizacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_organizacion_id_organizacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_organizacion_id_organizacion_seq OWNER TO postgres;

--
-- Name: tipo_organizacion_id_organizacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_organizacion_id_organizacion_seq OWNED BY public.tipo_organizacion.id_tipo_organizacion;


--
-- Name: titulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.titulo (
    codc_titul character(4) NOT NULL,
    nro_tab3 integer,
    codc_nivel character(4),
    desc_titul character varying
);


ALTER TABLE public.titulo OWNER TO postgres;

--
-- Name: titulos_docente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.titulos_docente (
    id_docente integer NOT NULL,
    codc_titul character(4) NOT NULL,
    fec_emisi date,
    fec_finalizacion date,
    codc_entot character(4)
);


ALTER TABLE public.titulos_docente OWNER TO postgres;

--
-- Name: unidad_acad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unidad_acad (
    sigla character(5) NOT NULL,
    descripcion character(60) NOT NULL,
    nro_tab6 integer,
    cod_regional character(4),
    id_tipo_dependencia integer
);


ALTER TABLE public.unidad_acad OWNER TO postgres;

--
-- Name: dedicacion_incentivo id_di; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dedicacion_incentivo ALTER COLUMN id_di SET DEFAULT nextval('public.dedicacion_incentivo_id_di_seq'::regclass);


--
-- Name: designacion id_designacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion ALTER COLUMN id_designacion SET DEFAULT nextval('public.designacion_id_designacion_seq'::regclass);


--
-- Name: incentivo id_inc; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentivo ALTER COLUMN id_inc SET DEFAULT nextval('public.incentivo_id_inc_seq'::regclass);


--
-- Name: norma id_norma; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma ALTER COLUMN id_norma SET DEFAULT nextval('public.norma_id_norma_seq'::regclass);


--
-- Name: objetivo_especifico id_objetivo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objetivo_especifico ALTER COLUMN id_objetivo SET DEFAULT nextval('public.objetivo_especifico_id_objetivo_seq'::regclass);


--
-- Name: organizaciones_participantes id_organizacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes ALTER COLUMN id_organizacion SET DEFAULT nextval('public.organizaciones_participantes_id_organizacion_seq'::regclass);


--
-- Name: pextension id_pext; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension ALTER COLUMN id_pext SET DEFAULT nextval('public.pextension_id_pext_seq'::regclass);


--
-- Name: plan_actividades id_plan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_actividades ALTER COLUMN id_plan SET DEFAULT nextval('public.plan_actividades_id_plan_seq'::regclass);


--
-- Name: tipo_designacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_designacion ALTER COLUMN id SET DEFAULT nextval('public.tipo_designacion_id_seq'::regclass);


--
-- Name: tipo_organizacion id_tipo_organizacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_organizacion ALTER COLUMN id_tipo_organizacion SET DEFAULT nextval('public.tipo_organizacion_id_organizacion_seq'::regclass);


--
-- Name: bases_convocatoria bases_convocatoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bases_convocatoria
    ADD CONSTRAINT bases_convocatoria_pkey PRIMARY KEY (id_bases);


--
-- Name: estado_pe estado_pe_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_pe
    ADD CONSTRAINT estado_pe_pkey PRIMARY KEY (id_estado);


--
-- Name: objetivo_especifico objetivo_especifico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objetivo_especifico
    ADD CONSTRAINT objetivo_especifico_pkey PRIMARY KEY (id_objetivo);


--
-- Name: organizaciones_participantes organizaciones_participantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes
    ADD CONSTRAINT organizaciones_participantes_pkey PRIMARY KEY (id_organizacion);


--
-- Name: area pk_area; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area
    ADD CONSTRAINT pk_area PRIMARY KEY (idarea);


--
-- Name: caracter pk_caracter; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caracter
    ADD CONSTRAINT pk_caracter PRIMARY KEY (id_car);


--
-- Name: dedicacion pk_dedicacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dedicacion
    ADD CONSTRAINT pk_dedicacion PRIMARY KEY (id_ded);


--
-- Name: dedicacion_incentivo pk_dedicacion_incentivo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dedicacion_incentivo
    ADD CONSTRAINT pk_dedicacion_incentivo PRIMARY KEY (id_di);


--
-- Name: departamento pk_departamento; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT pk_departamento PRIMARY KEY (iddepto);


--
-- Name: designacion pk_designacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT pk_designacion PRIMARY KEY (id_designacion);


--
-- Name: director_dpto pk_director_dpto; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.director_dpto
    ADD CONSTRAINT pk_director_dpto PRIMARY KEY (id_docente, iddepto, desde);


--
-- Name: docente pk_docente; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT pk_docente PRIMARY KEY (id_docente);


--
-- Name: funcion_extension pk_funcion_extension; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcion_extension
    ADD CONSTRAINT pk_funcion_extension PRIMARY KEY (id_extension);


--
-- Name: incentivo pk_incentivo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentivo
    ADD CONSTRAINT pk_incentivo PRIMARY KEY (id_inc);


--
-- Name: integrante_externo_pe pk_integrante_externo_pe; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_externo_pe
    ADD CONSTRAINT pk_integrante_externo_pe PRIMARY KEY (tipo_docum, nro_docum, id_pext, desde);


--
-- Name: integrante_interno_pe pk_integrante_interno_pe; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_interno_pe
    ADD CONSTRAINT pk_integrante_interno_pe PRIMARY KEY (id_pext, id_designacion, desde);


--
-- Name: localidad pk_localidad; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.localidad
    ADD CONSTRAINT pk_localidad PRIMARY KEY (id);


--
-- Name: norma pk_norma; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma
    ADD CONSTRAINT pk_norma PRIMARY KEY (id_norma);


--
-- Name: norma_desig pk_norma_desig; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma_desig
    ADD CONSTRAINT pk_norma_desig PRIMARY KEY (id_norma, id_designacion);


--
-- Name: orientacion pk_orientacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orientacion
    ADD CONSTRAINT pk_orientacion PRIMARY KEY (idorient, idarea);


--
-- Name: pais pk_pais; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pais
    ADD CONSTRAINT pk_pais PRIMARY KEY (codigo_pais);


--
-- Name: persona pk_persona; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT pk_persona PRIMARY KEY (tipo_docum, nro_docum);


--
-- Name: pextension pk_pextension; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension
    ADD CONSTRAINT pk_pextension PRIMARY KEY (id_pext);


--
-- Name: provincia pk_provincia; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provincia
    ADD CONSTRAINT pk_provincia PRIMARY KEY (codigo_pcia);


--
-- Name: tipo pk_tipo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo
    ADD CONSTRAINT pk_tipo PRIMARY KEY (nro_tabla, desc_abrev);


--
-- Name: tipo_designacion pk_tipo_designacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_designacion
    ADD CONSTRAINT pk_tipo_designacion PRIMARY KEY (id);


--
-- Name: titulos_docente pk_tit_doce; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulos_docente
    ADD CONSTRAINT pk_tit_doce PRIMARY KEY (id_docente, codc_titul);


--
-- Name: titulo pk_titulo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulo
    ADD CONSTRAINT pk_titulo PRIMARY KEY (codc_titul);


--
-- Name: unidad_acad pk_ua; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unidad_acad
    ADD CONSTRAINT pk_ua PRIMARY KEY (sigla);


--
-- Name: plan_actividades plan_actividades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_actividades
    ADD CONSTRAINT plan_actividades_pkey PRIMARY KEY (id_plan);


--
-- Name: presupuesto_extension presupuesto_extension_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_extension
    ADD CONSTRAINT presupuesto_extension_pkey PRIMARY KEY (id_presupuesto, id_pext, id_rubro_extension);


--
-- Name: rubro_presup_extension rubro_presup_extension_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rubro_presup_extension
    ADD CONSTRAINT rubro_presup_extension_pkey PRIMARY KEY (id_rubro_extension);


--
-- Name: tipo_convocatoria tipo_convocatoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_convocatoria
    ADD CONSTRAINT tipo_convocatoria_pkey PRIMARY KEY (id_conv);


--
-- Name: tipo_organizacion tipo_organizacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_organizacion
    ADD CONSTRAINT tipo_organizacion_pkey PRIMARY KEY (id_tipo_organizacion);


--
-- Name: designacion unico_nro_cargo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT unico_nro_cargo UNIQUE (nro_cargo);


--
-- Name: docente unico_nro_docum; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT unico_nro_docum UNIQUE (nro_docum);


--
-- Name: area tauditoria_area; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_area AFTER INSERT OR DELETE OR UPDATE ON public.area FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_area();


--
-- Name: caracter tauditoria_caracter; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_caracter AFTER INSERT OR DELETE OR UPDATE ON public.caracter FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_caracter();


--
-- Name: dedicacion tauditoria_dedicacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_dedicacion AFTER INSERT OR DELETE OR UPDATE ON public.dedicacion FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_dedicacion();


--
-- Name: dedicacion_incentivo tauditoria_dedicacion_incentivo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_dedicacion_incentivo AFTER INSERT OR DELETE OR UPDATE ON public.dedicacion_incentivo FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_dedicacion_incentivo();


--
-- Name: departamento tauditoria_departamento; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_departamento AFTER INSERT OR DELETE OR UPDATE ON public.departamento FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_departamento();


--
-- Name: designacion tauditoria_designacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_designacion AFTER INSERT OR DELETE OR UPDATE ON public.designacion FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_designacion();


--
-- Name: director_dpto tauditoria_director_dpto; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_director_dpto AFTER INSERT OR DELETE OR UPDATE ON public.director_dpto FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_director_dpto();


--
-- Name: docente tauditoria_docente; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_docente AFTER INSERT OR DELETE OR UPDATE ON public.docente FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_docente();


--
-- Name: funcion_extension tauditoria_funcion_extension; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_funcion_extension AFTER INSERT OR DELETE OR UPDATE ON public.funcion_extension FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_funcion_extension();


--
-- Name: incentivo tauditoria_incentivo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_incentivo AFTER INSERT OR DELETE OR UPDATE ON public.incentivo FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_incentivo();


--
-- Name: integrante_externo_pe tauditoria_integrante_externo_pe; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_integrante_externo_pe AFTER INSERT OR DELETE OR UPDATE ON public.integrante_externo_pe FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_integrante_externo_pe();


--
-- Name: integrante_interno_pe tauditoria_integrante_interno_pe; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_integrante_interno_pe AFTER INSERT OR DELETE OR UPDATE ON public.integrante_interno_pe FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_integrante_interno_pe();


--
-- Name: localidad tauditoria_localidad; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_localidad AFTER INSERT OR DELETE OR UPDATE ON public.localidad FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_localidad();


--
-- Name: norma tauditoria_norma; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_norma AFTER INSERT OR DELETE OR UPDATE ON public.norma FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_norma();


--
-- Name: norma_desig tauditoria_norma_desig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_norma_desig AFTER INSERT OR DELETE OR UPDATE ON public.norma_desig FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_norma_desig();


--
-- Name: orientacion tauditoria_orientacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_orientacion AFTER INSERT OR DELETE OR UPDATE ON public.orientacion FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_orientacion();


--
-- Name: pais tauditoria_pais; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_pais AFTER INSERT OR DELETE OR UPDATE ON public.pais FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_pais();


--
-- Name: persona tauditoria_persona; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_persona AFTER INSERT OR DELETE OR UPDATE ON public.persona FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_persona();


--
-- Name: pextension tauditoria_pextension; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_pextension AFTER INSERT OR DELETE OR UPDATE ON public.pextension FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_pextension();


--
-- Name: provincia tauditoria_provincia; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_provincia AFTER INSERT OR DELETE OR UPDATE ON public.provincia FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_provincia();


--
-- Name: tipo tauditoria_tipo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_tipo AFTER INSERT OR DELETE OR UPDATE ON public.tipo FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_tipo();


--
-- Name: tipo_designacion tauditoria_tipo_designacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_tipo_designacion AFTER INSERT OR DELETE OR UPDATE ON public.tipo_designacion FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_tipo_designacion();


--
-- Name: titulo tauditoria_titulo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_titulo AFTER INSERT OR DELETE OR UPDATE ON public.titulo FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_titulo();


--
-- Name: titulos_docente tauditoria_titulos_docente; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_titulos_docente AFTER INSERT OR DELETE OR UPDATE ON public.titulos_docente FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_titulos_docente();


--
-- Name: unidad_acad tauditoria_unidad_acad; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tauditoria_unidad_acad AFTER INSERT OR DELETE OR UPDATE ON public.unidad_acad FOR EACH ROW EXECUTE PROCEDURE public_auditoria.sp_unidad_acad();


--
-- Name: bases_convocatoria bases_convocatoria_tipo_convocatoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bases_convocatoria
    ADD CONSTRAINT bases_convocatoria_tipo_convocatoria_fkey FOREIGN KEY (tipo_convocatoria) REFERENCES public.tipo_convocatoria(id_conv);


--
-- Name: area fk_area_departamento; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area
    ADD CONSTRAINT fk_area_departamento FOREIGN KEY (iddepto) REFERENCES public.departamento(iddepto);


--
-- Name: departamento fk_departamento_ua; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT fk_departamento_ua FOREIGN KEY (idunidad_academica) REFERENCES public.unidad_acad(sigla);


--
-- Name: designacion fk_designacion_caracter; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_caracter FOREIGN KEY (carac) REFERENCES public.caracter(id_car);


--
-- Name: designacion fk_designacion_dedicacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_dedicacion FOREIGN KEY (dedic) REFERENCES public.dedicacion(id_ded);


--
-- Name: designacion fk_designacion_dedincent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_dedincent FOREIGN KEY (dedi_incen) REFERENCES public.dedicacion_incentivo(id_di);


--
-- Name: designacion fk_designacion_departamento; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_departamento FOREIGN KEY (id_departamento) REFERENCES public.departamento(iddepto);


--
-- Name: designacion fk_designacion_docente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_docente FOREIGN KEY (id_docente) REFERENCES public.docente(id_docente);


--
-- Name: designacion fk_designacion_incentivo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_incentivo FOREIGN KEY (tipo_incentivo) REFERENCES public.incentivo(id_inc);


--
-- Name: designacion fk_designacion_norma; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_norma FOREIGN KEY (id_norma) REFERENCES public.norma(id_norma) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: designacion fk_designacion_normacs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_normacs FOREIGN KEY (id_norma_cs) REFERENCES public.norma(id_norma) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: designacion fk_designacion_orientacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_orientacion FOREIGN KEY (id_orientacion, id_area) REFERENCES public.orientacion(idorient, idarea);


--
-- Name: designacion fk_designacion_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_tipo FOREIGN KEY (tipo_desig) REFERENCES public.tipo_designacion(id);


--
-- Name: designacion fk_designacion_ua; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.designacion
    ADD CONSTRAINT fk_designacion_ua FOREIGN KEY (uni_acad) REFERENCES public.unidad_acad(sigla);


--
-- Name: director_dpto fk_director_dpto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.director_dpto
    ADD CONSTRAINT fk_director_dpto FOREIGN KEY (iddepto) REFERENCES public.departamento(iddepto);


--
-- Name: director_dpto fk_director_dpto_docente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.director_dpto
    ADD CONSTRAINT fk_director_dpto_docente FOREIGN KEY (id_docente) REFERENCES public.docente(id_docente);


--
-- Name: docente fk_docente_pais_nacim; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT fk_docente_pais_nacim FOREIGN KEY (pais_nacim) REFERENCES public.pais(codigo_pais);


--
-- Name: docente fk_docente_pcia_nacim; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT fk_docente_pcia_nacim FOREIGN KEY (pcia_nacim) REFERENCES public.provincia(codigo_pcia);


--
-- Name: docente fk_docente_tipodocum; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT fk_docente_tipodocum FOREIGN KEY (nro_tabla, tipo_docum) REFERENCES public.tipo(nro_tabla, desc_abrev);


--
-- Name: integrante_externo_pe fk_integrante_externo_pe_persona; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_externo_pe
    ADD CONSTRAINT fk_integrante_externo_pe_persona FOREIGN KEY (tipo_docum, nro_docum) REFERENCES public.persona(tipo_docum, nro_docum) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: integrante_interno_pe fk_integrante_oe_funcion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_interno_pe
    ADD CONSTRAINT fk_integrante_oe_funcion FOREIGN KEY (funcion_p) REFERENCES public.funcion_extension(id_extension);


--
-- Name: integrante_externo_pe fk_integrante_pe_funcion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_externo_pe
    ADD CONSTRAINT fk_integrante_pe_funcion FOREIGN KEY (funcion_p) REFERENCES public.funcion_extension(id_extension);


--
-- Name: integrante_externo_pe fk_integrante_pe_pinv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_externo_pe
    ADD CONSTRAINT fk_integrante_pe_pinv FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: integrante_interno_pe fk_integrante_pe_pinv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_interno_pe
    ADD CONSTRAINT fk_integrante_pe_pinv FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: integrante_interno_pe fk_integrante_pe_ua; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrante_interno_pe
    ADD CONSTRAINT fk_integrante_pe_ua FOREIGN KEY (ua) REFERENCES public.unidad_acad(sigla);


--
-- Name: localidad fk_localidad_pcia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.localidad
    ADD CONSTRAINT fk_localidad_pcia FOREIGN KEY (id_provincia) REFERENCES public.provincia(codigo_pcia);


--
-- Name: norma_desig fk_norma_desig_designacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma_desig
    ADD CONSTRAINT fk_norma_desig_designacion FOREIGN KEY (id_designacion) REFERENCES public.designacion(id_designacion) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: norma_desig fk_norma_desig_norma; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.norma_desig
    ADD CONSTRAINT fk_norma_desig_norma FOREIGN KEY (id_norma) REFERENCES public.norma(id_norma) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orientacion fk_orientacion_area; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orientacion
    ADD CONSTRAINT fk_orientacion_area FOREIGN KEY (idarea) REFERENCES public.area(idarea);


--
-- Name: persona fk_persona_pais; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_pais FOREIGN KEY (pais_nacim) REFERENCES public.pais(codigo_pais);


--
-- Name: persona fk_persona_pcia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_pcia FOREIGN KEY (pcia_nacim) REFERENCES public.provincia(codigo_pcia);


--
-- Name: persona fk_persona_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_tipo FOREIGN KEY (nro_tabla, tipo_docum) REFERENCES public.tipo(nro_tabla, desc_abrev);


--
-- Name: persona fk_persona_titulog; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_titulog FOREIGN KEY (titulog) REFERENCES public.titulo(codc_titul);


--
-- Name: persona fk_persona_titulop; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT fk_persona_titulop FOREIGN KEY (titulop) REFERENCES public.titulo(codc_titul);


--
-- Name: pextension fk_pextension_ua; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension
    ADD CONSTRAINT fk_pextension_ua FOREIGN KEY (uni_acad) REFERENCES public.unidad_acad(sigla);


--
-- Name: provincia fk_provincia_pais; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provincia
    ADD CONSTRAINT fk_provincia_pais FOREIGN KEY (cod_pais) REFERENCES public.pais(codigo_pais);


--
-- Name: titulos_docente fk_titdoce_leg; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulos_docente
    ADD CONSTRAINT fk_titdoce_leg FOREIGN KEY (id_docente) REFERENCES public.docente(id_docente);


--
-- Name: titulos_docente fk_titdoce_tit; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulos_docente
    ADD CONSTRAINT fk_titdoce_tit FOREIGN KEY (codc_titul) REFERENCES public.titulo(codc_titul);


--
-- Name: titulo fk_titulo_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.titulo
    ADD CONSTRAINT fk_titulo_tipo FOREIGN KEY (nro_tab3, codc_nivel) REFERENCES public.tipo(nro_tabla, desc_abrev);


--
-- Name: unidad_acad fk_ua_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unidad_acad
    ADD CONSTRAINT fk_ua_tipo FOREIGN KEY (nro_tab6, cod_regional) REFERENCES public.tipo(nro_tabla, desc_abrev);


--
-- Name: objetivo_especifico objetivo_especifico_id_pext_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objetivo_especifico
    ADD CONSTRAINT objetivo_especifico_id_pext_fkey FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: organizaciones_participantes organizaciones_participantes_id_localidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes
    ADD CONSTRAINT organizaciones_participantes_id_localidad_fkey FOREIGN KEY (id_localidad) REFERENCES public.localidad(id);


--
-- Name: organizaciones_participantes organizaciones_participantes_id_pext_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes
    ADD CONSTRAINT organizaciones_participantes_id_pext_fkey FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: organizaciones_participantes organizaciones_participantes_id_tipo_organizacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizaciones_participantes
    ADD CONSTRAINT organizaciones_participantes_id_tipo_organizacion_fkey FOREIGN KEY (id_tipo_organizacion) REFERENCES public.tipo_organizacion(id_tipo_organizacion);


--
-- Name: pextension pextension_estado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension
    ADD CONSTRAINT pextension_estado_fkey FOREIGN KEY (estado) REFERENCES public.estado_pe(id_estado);


--
-- Name: pextension pextension_id_bases_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pextension
    ADD CONSTRAINT pextension_id_bases_fkey FOREIGN KEY (id_bases) REFERENCES public.bases_convocatoria(id_bases);


--
-- Name: plan_actividades plan_actividades_id_obj_especifico_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plan_actividades
    ADD CONSTRAINT plan_actividades_id_obj_especifico_fkey FOREIGN KEY (id_obj_especifico) REFERENCES public.objetivo_especifico(id_objetivo);


--
-- Name: presupuesto_extension presupuesto_extension_id_pext_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_extension
    ADD CONSTRAINT presupuesto_extension_id_pext_fkey FOREIGN KEY (id_pext) REFERENCES public.pextension(id_pext);


--
-- Name: presupuesto_extension presupuesto_extension_id_rubro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presupuesto_extension
    ADD CONSTRAINT presupuesto_extension_id_rubro_fkey FOREIGN KEY (id_rubro_extension) REFERENCES public.rubro_presup_extension(id_rubro_extension);


--
-- PostgreSQL database dump complete
--

